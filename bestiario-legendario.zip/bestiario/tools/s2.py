# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math

def P(**k):
    return k

# ---------------------------------------------------------------- 11 Acechador Nocturno
def night_stalker(m=None, pal=None):
    m = m or Model()
    biped(m, tw=6, th=10, td=4, lh=16, lw=2, aw=2, ah=18, head_s=(7, 7, 7), mat="base", pat="fur", hmat="base", hpat="fur", fist=False, arm_x=5)
    m.parts = [p for p in m.parts if p["name"] != "head"]; m.names.discard("head")
    top = 26
    head(m, "body", "head", 0, top - 1, 0, 7, 7, 7, snout=(4, 3, 2), jaw=True, fangs=True, mat="base", pat="fur", pivot=(0, top + 1, 0))
    for i in range(4):
        m.pair("spike%d" % i, "body", (2.5, 17 + i * 2.5, -2.5), (1, 3, 2), rot=(0.5, 0, 0.3), mat="accent")
    m.pair("claw", "arm_l", (5, 0, 0), (2, 3, 2), mat="accent") if False else None
    for s_ in ("l", "r"):
        sx = 5 if s_ == "l" else -5
        m.add("hand_" + s_, "arm_" + s_, (sx, -3, 0), (3, 3, 3), mat="accent", pat="")
    return m
reg(11, "acechador_nocturno", "Acechador Nocturno", "Night Stalker", "B", night_stalker, 3.0, P(base="#171019", dark="#07050a", light="#2e2238", accent="#9b30ff", accent2="#d9a0ff", belly="#241a2c", eye="#ff40ff"),
    hp=62, dmg=9, spd=0.32, arm=2, kb=0.3, det=32, ride=1.5, foods=["carne_podrida"], fx="darkness", abil="Mirada aterradora: ciega y oscurece la visión",
    modes=("surface", "cave"), time="night", w=8, desc="Criatura alta y oscura de largos brazos y detalles morados. Acecha en silencio.", biome="Cualquier bioma, de noche")

# ---------------------------------------------------------------- 12 Devorador de Sombras
def shadow_devourer(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 9, 9, 18, 10
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="vein", foot=(5, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 5, bd / 2.0 + 3, 8, 7, 7, snout=(6, 4, 5), jaw=True, fangs=True, ears=(2, 3, 2, 3, -1, "accent"),
         mat="base", pat="vein", pivot=(0, top - 1, bd / 2.0))
    for i in range(6):
        m.add("spk%d" % i, "body", (0, top, 7 - i * 3), (2, 4 - (i % 2), 2), mat="accent", pat="glow")
    t = chain(m, "body", "tail", (0, top - 2, -bd / 2.0), 3, 4, 4, 4, axis="z", sign=-1, step=3, taper=0.8, mat="base", pat="vein", role="tail", rot=(0.1, 0, 0))
    saddle(m, "body", top, 0, 7, 7)
    return m
reg(12, "devorador_sombras", "Devorador de Sombras", "Shadow Devourer", "B", shadow_devourer, 2.0, P(base="#1c1126", dark="#08040c", light="#36204c", accent="#8a30e0", accent2="#c070ff", belly="#2a1838", eye="#d050ff"),
    hp=76, dmg=10, spd=0.30, arm=3, kb=0.3, det=30, ride=1.5, foods=["redstone", "carne_podrida"], fx="darkness", abil="Mordisco oscuro: drena la luz",
    modes=("surface", "cave"), biomes=B_FOREST + B_DARK + B_PLAINS, time="night", w=7, desc="Monstruo cuadrúpedo de aspecto oscuro con energía morada recorriendo su piel.", biome="Bosques y cuevas, de noche")

# ---------------------------------------------------------------- 13 Reptador Pálido
def pale_crawler(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 5, 6, 26, 7
    quad_base(m, bw, bh, bd, lh, 2, mat="base", pat="stripe", lx=5, zf=9, zb=-9, foot=(4, 1, 4), ld=3)
    top = lh + bh
    head(m, "body", "head", 0, lh, bd / 2.0 + 3, 6, 5, 6, snout=(4, 3, 7), jaw=True, fangs=True, mat="base", pat="fur", pivot=(0, lh + 3, bd / 2.0))
    for i in range(5):
        m.pair("rib%d" % i, "body", (3.8, lh + 1, 9 - i * 4), (1, 4, 2), mat="bone", pat="bone")
        m.add("ridge%d" % i, "body", (0, top, 9 - i * 4), (2, 2, 2), mat="bone", pat="bone")
    t = chain(m, "body", "tail", (0, lh + 3, -bd / 2.0), 5, 5, 4, 4, axis="z", sign=-1, step=4, taper=0.82, mat="base", pat="fur", role="tail", rot=(0, 0, 0), ph=0.6)
    saddle(m, "body", top, 0, 5, 8)
    return m
reg(13, "reptador_palido", "Reptador Pálido", "Pale Crawler", "B", pale_crawler, 1.2, P(base="#d2d2d8", dark="#8c8c98", light="#f0f0f4", accent="#a8a8b4", accent2="#e6e6ee", belly="#e0e0e6", eye="#e03232"),
    hp=52, dmg=8, spd=0.31, arm=1, kb=0.0, det=28, ride=1.6, ovi=True, foods=["carne_podrida"], fx="weak", abil="Garras gélidas: debilitan",
    modes=("cave", "surface"), time="night", w=9, desc="Criatura de cuerpo alargado y piel pálida que repta de forma inquietante.", biome="Cuevas y cualquier bioma de noche")

# ---------------------------------------------------------------- 14 Dama de la Niebla
def mist_lady(m=None, pal=None):
    m = m or Model()
    m.add("body", None, (0, 12, 0), (7, 9, 4), role="body", mat="light", pat="mist")
    m.add("skirt0", "body", (0, 7, 0), (9, 6, 6), mat="base", pat="mist", role="tentacle", idx=0)
    m.add("skirt1", "skirt0", (0, 2, 0), (11, 5, 8), mat="base", pat="mist", role="tentacle", idx=1, pivot=(0, 7, 0))
    for i in range(4):
        a = i * math.pi / 2 + 0.6
        m.add("wisp%d" % i, "skirt1", (math.cos(a) * 5.5, 0, math.sin(a) * 4.5), (3, 4, 3), mat="accent", pat="mist", role="tentacle", idx=i + 2, pivot=(math.cos(a) * 5.5, 4, math.sin(a) * 4.5))
    m.add("arm_l", "body", (4.5, 7, 0), (2, 9, 2), pivot=(4.5, 17.5, 0), role="arm", idx=1, mat="light", pat="mist")
    m.add("arm_r", "body", (-4.5, 7, 0), (2, 9, 2), pivot=(-4.5, 17.5, 0), role="arm", idx=0, mat="light", pat="mist")
    head(m, "body", "head", 0, 20, 0, 6, 6, 6, mat="light", pat="mist", pivot=(0, 21, 0))
    m.add("hair", "head", (0, 12, -3.5), (8, 14, 2), mat="base", pat="mist", role="tail", pivot=(0, 25, -3), rot=(0.08, 0, 0))
    m.add("hairtop", "head", (0, 25, 0), (7, 2, 7), mat="base", pat="mist")
    saddle(m, "body", 21, 0, 6, 5)
    return m
reg(14, "dama_niebla", "Dama de la Niebla", "Lady of the Mist", "B", mist_lady, 2.3, P(base="#6cb2ec", dark="#3a78c8", light="#d5f0ff", accent="#a8e0ff", accent2="#ffffff", belly="#b8dcf8", eye="#ffffff"),
    hp=44, dmg=6, spd=0.25, arm=0, kb=0.0, det=26, ride=1.2, foods=["amatista"], fx="blind", abil="Niebla espesa: ciega a quien la toca",
    modes=("surface",), biomes=B_SWAMP + B_PLAINS + B_FOREST + ["river"], time="night", w=6, desc="Entidad espectral femenina de apariencia azulada, rodeada de niebla.", biome="Pantanos, ríos y bosques, de noche")

# ---------------------------------------------------------------- 15 Hombre Polilla
def mothman(m=None, pal=None):
    m = m or Model()
    biped(m, tw=6, th=9, td=4, lh=9, lw=3, aw=3, ah=9, head_s=(6, 6, 5), mat="base", pat="fur", fist=False)
    m.parts = [p for p in m.parts if p["name"] != "head"]; m.names.discard("head")
    top = 18
    head(m, "body", "head", 0, top - 1, 0, 6, 6, 5, mat="base", pat="fur", face="face", pivot=(0, top + 2, 0))
    m.pair("bigeye", "head", (2.5, top + 1, 2.6), (3, 3, 1), mat="eye")
    m.pair("antenna", "head", (1.5, top + 5, 0), (1, 6, 1), rot=(0.2, 0, 0.35), mat="accent2")
    m.add("chest", "body", (0, 13, 2), (8, 5, 2), mat="light", pat="fur")
    wing(m, "body", "wing", 3, top - 3, -1, [(5, 2, 7), (12, 1, 13), (8, 1, 10)], ["accent2", "accent", "accent"], pat="spot", fold=1.25)
    return m
reg(15, "hombre_polilla", "Hombre Polilla", "Mothman", "B", mothman, 2.4, P(base="#5e4a34", dark="#34281a", light="#b89868", accent="#d09a50", accent2="#8c6a3c", belly="#7a644a", eye="#ff9a20"),
    move="fly", hp=54, dmg=7, spd=0.28, arm=1, kb=0.0, det=34, fs=0.75, ride=1.3, foods=["redstone"], fx="nausea", abil="Mirada hipnótica: provoca náuseas",
    modes=("air",), biomes=B_FOREST + B_PLAINS + B_SWAMP, time="night", w=6, desc="Humanoide volador de grandes alas y ojos luminosos que observa desde la oscuridad.", biome="Bosques y praderas, de noche")

# ---------------------------------------------------------------- 16 Espectro Carmesí
def crimson_specter(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 7, 10, 13, 10
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="glow", foot=(4, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 6, bd / 2.0 + 2, 7, 7, 6, snout=(5, 3, 2), jaw=True, fangs=True, mat="base", pat="glow", pivot=(0, top - 2, bd / 2.0))
    m.pair("hornc", "head", (2.5, top + 1, bd / 2.0 + 1), (2, 4, 2), rot=(-0.3, 0, 0.3), mat="light")
    t = chain(m, "body", "tail", (0, top - 4, -bd / 2.0), 4, 5, 5, 4, axis="z", sign=-1, step=3, taper=0.75, mat="light", pat="glow", role="tail", rot=(0.1, 0, 0), ph=0.6)
    for i in range(3):
        m.pair("flame%d" % i, "body", (5.5, top - 2 + i, 3 - i * 4), (1, 4, 1), mat="accent", pat="glow", role="tentacle", idx=i)
    saddle(m, "body", top, 0, 7, 7)
    return m
reg(16, "espectro_carmesi", "Espectro Carmesí", "Crimson Specter", "B", crimson_specter, 2.0, P(base="#b01818", dark="#600a0a", light="#ff5a5a", accent="#ff9a9a", accent2="#ffd0d0", belly="#8a1010", eye="#ffffff"),
    hp=60, dmg=9, spd=0.30, arm=0, kb=0.0, det=30, ride=1.5, foods=["redstone", "lagrima"], fx="wither", abil="Toque carmesí: marchita a sus víctimas",
    dims=("nether",), modes=("cave",), biomes=ANY, w=8, desc="Monstruo espectral rojo envuelto en energía carmesí. Ronda los yermos del Nether.", biome="Nether")

# ---------------------------------------------------------------- 17 Cazador de Medianoche
def midnight_hunter(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 8, 7, 17, 7
    quad_base(m, bw, bh, bd, lh, 3, mat="base", pat="vein", foot=(3, 1, 4))
    top = lh + bh
    head(m, "body", "head", 0, top - 4, bd / 2.0 + 2, 6, 5, 5, snout=(3, 2, 3), jaw=True, fangs=True, ears=(2, 3, 1, 2, -1, "accent"),
         mat="base", pat="vein", pivot=(0, top - 1, bd / 2.0))
    t = chain(m, "body", "tail", (0, top - 2, -bd / 2.0), 5, 2, 2, 2, axis="z", sign=-1, step=3, taper=1.0, mat="base", pat="vein", role="tail", rot=(0.12, 0, 0), ph=0.5)
    for i in range(3):
        m.pair("stripe%d" % i, "body", (3.8, top - 3, 5 - i * 4), (1, 3, 2), mat="accent", pat="glow")
    saddle(m, "body", top, 0, 5, 7)
    return m
reg(17, "cazador_medianoche", "Cazador de Medianoche", "Midnight Hunter", "B", midnight_hunter, 1.6, P(base="#15101f", dark="#08050e", light="#2f2244", accent="#9a3cf0", accent2="#e090ff", belly="#241a34", eye="#ff50ff"),
    hp=56, dmg=9, spd=0.44, arm=1, kb=0.0, det=34, ride=2.0, foods=["cerdo"], fx="bleed", abil="Zarpazo veloz: causa hemorragia",
    modes=("surface",), time="night", w=8, desc="Depredador oscuro de ojos brillantes y gran velocidad.", biome="Cualquier bioma, de noche")

# ---------------------------------------------------------------- 18 Araña de Sangre
def blood_spider(m=None, pal=None):
    m = m or Model()
    spider(m, bw=9, bh=6, bd=10, lh=7, abd=(11, 8, 13), up=9, low=9, mat="base", pat="chitin", abmat="accent", abpat="spot", leg_mat="dark")
    return m
reg(18, "arana_sangre", "Araña de Sangre", "Blood Spider", "B", blood_spider, 1.6, P(base="#1c1218", dark="#0a0608", light="#3a2430", accent="#c01c28", accent2="#ff4040", belly="#2a1820", eye="#ff2020"),
    hp=46, dmg=7, spd=0.34, arm=2, kb=0.0, det=30, ride=1.5, ovi=True, foods=["ojo_arana"], fx="poison", abil="Veneno sanguíneo",
    modes=("surface", "cave"), time="night", w=8, desc="Araña gigante negra y roja con ojos incandescentes.", biome="Cualquier bioma, cuevas y de noche")

# ---------------------------------------------------------------- 19 Carroñero Nocturno
def night_scavenger(m=None, pal=None):
    m = m or Model()
    bird(m, bw=8, bh=7, bd=12, lh=6, mat="base", hmat="accent", bmat="bone", tailmat="dark", wmats=("base", "accent2", "accent2"),
         wings=((6, 2, 7), (11, 1, 12), (8, 1, 9)), tail=(6, 1, 7), legmat="accent2", neck=True, head_s=(4, 5, 5), beak=(2, 3, 4))
    top = 13
    m.add("ruff", "body", (0, top - 3, 5), (9, 4, 5), mat="light", pat="feather")
    return m
reg(19, "carronero_nocturno", "Carroñero Nocturno", "Night Scavenger", "B", night_scavenger, 1.7, P(base="#2a2430", dark="#14101a", light="#e8e4f0", accent="#b878b0", accent2="#4a3c5a", belly="#3a3040", eye="#ffd040"),
    move="fly", hp=40, dmg=6, spd=0.28, arm=0, kb=0.0, det=34, fs=0.8, ride=1.5, ovi=True, foods=["carne_podrida"], fx="hunger", abil="Picotazo carroñero: provoca hambre",
    modes=("air",), biomes=B_DESERT + B_PLAINS + ["savanna"], time="night", w=7, desc="Criatura alada con aspecto de buitre y plumaje oscuro. Sobrevuela el desierto de noche.", biome="Desiertos y sabanas, de noche")

# ---------------------------------------------------------------- 20 Bestia del Bosque Oscuro
def dark_beast(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 11, 11, 20, 12
    quad_base(m, bw, bh, bd, lh, 5, mat="base", pat="fur", foot=(5, 1, 3), lx=4)
    top = lh + bh
    head(m, "body", "head", 0, top - 7, bd / 2.0 + 3, 9, 8, 8, snout=(6, 4, 6), jaw=True, fangs=True, ears=(3, 4, 2, 3.5, -1, "dark", (0, 0, 0.3)),
         mat="base", pat="fur", pivot=(0, top - 2, bd / 2.0))
    for i in range(5):
        m.add("mane%d" % i, "body", (0, top, 7 - i * 3.5), (3, 4 + (i % 2), 3), mat="dark", pat="fur")
    m.add("tongue", "head_jaw", (0, top - 7 + 2.5, bd / 2.0 + 3 + 5), (2, 1, 3), mat="accent")
    t = chain(m, "body", "tail", (0, top - 3, -bd / 2.0), 3, 4, 4, 4, axis="z", sign=-1, step=3, taper=0.8, mat="base", pat="fur", role="tail", rot=(0.15, 0, 0))
    saddle(m, "body", top, 0, 8, 8)
    return m
reg(20, "bestia_bosque_oscuro", "Bestia del Bosque Oscuro", "Dark Forest Beast", "B", dark_beast, 2.9, P(base="#1c2232", dark="#0a0e18", light="#38445e", accent="#a050e0", accent2="#4a7cff", belly="#2a3248", eye="#4a8cff"),
    hp=120, dmg=13, spd=0.30, arm=4, kb=0.6, det=30, ride=1.3, foods=["res"], fx="knock", abil="Zarpazo brutal: lanza a su presa",
    modes=("surface",), biomes=B_DARK + B_FOREST, time="night", w=5, desc="Depredador enorme de pelaje oscuro y apariencia monstruosa.", biome="Bosques oscuros, de noche")
