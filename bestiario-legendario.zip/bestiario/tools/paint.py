# -*- coding: utf-8 -*-
import math
from PIL import Image

VARIANTS = ["normal", "albino", "melanic", "golden", "crystal", "crimson"]
LEATHER = (122, 74, 42)
METAL = (170, 172, 180)

def hx(s):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))

def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))

def lum(c):
    return (0.3 * c[0] + 0.59 * c[1] + 0.11 * c[2]) / 255.0

def clamp(c):
    return tuple(max(0, min(255, int(v))) for v in c)

def mul(c, f):
    return clamp((c[0] * f, c[1] * f, c[2] * f))

def H(x, y, s=0):
    n = (x * 374761393 + y * 668265263 + s * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return (n ^ (n >> 16)) & 0xFFFF

def make_palette(spec):
    """spec: dict nombre->hex. Completa claves."""
    p = {k: hx(v) for k, v in spec.items()}
    p.setdefault("dark", mul(p["base"], 0.6))
    p.setdefault("light", mul(p["base"], 1.3))
    p.setdefault("accent", p["light"])
    p.setdefault("accent2", p["dark"])
    p.setdefault("belly", lerp(p["base"], p["light"], 0.6))
    p.setdefault("eye", (255, 220, 40))
    p.setdefault("bone", (230, 225, 205))
    p["leather"] = LEATHER
    p["metal"] = METAL
    return p

def variant_palette(p, v):
    if v == 0:
        return p
    q = dict(p)
    for k, c in p.items():
        if k in ("leather", "metal"):
            continue
        l = lum(c)
        if v == 1:   # albina
            q[k] = lerp((185, 188, 205), (255, 252, 255), l)
        elif v == 2:  # melánica
            q[k] = lerp((8, 7, 12), (66, 60, 78), l)
        elif v == 3:  # dorada
            q[k] = lerp((125, 82, 10), (255, 216, 84), l)
        elif v == 4:  # cristalina
            q[k] = lerp((28, 108, 160), (196, 246, 255), l)
        elif v == 5:  # carmesí
            q[k] = lerp((52, 4, 12), (206, 32, 42), l)
    if v == 1:
        q["eye"] = (232, 40, 70); q["accent"] = lerp((140, 165, 205), (235, 242, 255), lum(p["accent"]))
    elif v == 2:
        q["eye"] = (232, 120, 255)
        a = p["accent"]; m = max(a) or 1
        q["accent"] = clamp((a[0] * 255 / m, a[1] * 255 / m, a[2] * 255 / m))
    elif v == 3:
        q["eye"] = (255, 255, 255); q["accent2"] = (255, 236, 150)
    elif v == 4:
        q["eye"] = (170, 255, 255); q["accent"] = (235, 255, 255)
    elif v == 5:
        q["eye"] = (255, 215, 60); q["accent"] = (24, 0, 8)
    return q

# ---------------------------------------------------------------- patrones
def pattern(name, c, pal, lx, ly, W, Hh, seed):
    h = H(lx, ly, seed)
    if name == "fur":
        if H(lx, ly // 3, seed + 3) % 5 == 0:
            return mul(c, 0.82)
        if h % 11 == 0:
            return mul(c, 1.12)
    elif name == "feather":
        row = ly // 3
        off = 2 if row % 2 else 0
        if ly % 3 == 2:
            return mul(c, 0.78)
        if (lx + off) % 4 == 0:
            return mul(c, 1.14)
    elif name == "scale":
        if (lx + ly) % 4 == 0 or (lx - ly) % 4 == 0:
            return mul(c, 0.78)
        if (lx + ly) % 4 == 2 and h % 3 == 0:
            return mul(c, 1.12)
    elif name == "plate":
        if lx == 0 or ly == 0 or lx == W - 1 or ly == Hh - 1:
            return mul(c, 0.62)
        if (lx in (1, W - 2)) and (ly in (1, Hh - 2)):
            return mul(c, 1.3)
    elif name == "stripe":
        if (ly // 2) % 3 == 0:
            return pal["dark"]
    elif name == "spot":
        if H(lx // 2, ly // 2, seed + 7) % 6 == 0:
            return lerp(c, pal["accent"], 0.75)
    elif name == "crack":
        if (lx * 3 + ly * 5 + seed) % 11 == 0 or (lx * 5 - ly * 3 + seed) % 13 == 0:
            return lerp(pal["accent"], pal["accent2"], (h % 100) / 100.0)
        return mul(c, 0.8 + (h % 20) / 60.0)
    elif name == "crystal":
        if (lx + ly) % 6 == 0:
            return lerp(c, (255, 255, 255), 0.7)
        if ((lx + ly) // 3) % 2:
            return mul(c, 1.14)
        return mul(c, 0.93)
    elif name == "bone":
        if lx % 4 == 0 and ly % 3 != 1:
            return mul(c, 0.7)
        if ly % 5 == 4:
            return mul(c, 0.82)
    elif name == "stone":
        k = H(lx // 2, ly // 2, seed + 11) % 100
        return mul(c, 0.82 + k / 280.0)
    elif name == "glow":
        if h % 6 == 0:
            return pal["accent2"]
    elif name == "leather":
        if lx == 0 or ly == 0 or lx == W - 1 or ly == Hh - 1:
            return mul(c, 0.7)
        if (lx + ly) % 4 == 0:
            return mul(c, 1.1)
    elif name == "membrane":
        if lx % 4 == 0:
            return mul(c, 0.72)
        return mul(c, 1.0 + (h % 10) / 90.0)
    elif name == "chitin":
        if ly % 4 == 0:
            return mul(c, 0.68)
        if ly % 4 == 1:
            return mul(c, 1.18)
    elif name == "metal":
        if h % 11 == 0:
            return mul(c, 1.25)
        if lx == 0 or ly == 0:
            return mul(c, 0.8)
    elif name == "shell":
        if lx % 5 == 0 or ly % 5 == 0:
            return pal["dark"]
        if H(lx // 5, ly // 5, seed) % 3 == 0:
            return mul(c, 1.14)
    elif name == "vein":
        if (lx * 2 + ly + seed) % 9 == 0 and h % 2 == 0:
            return pal["accent"]
    elif name == "mist":
        return lerp(c, pal["light"], (h % 100) / 140.0)
    if name == "ink":
        return mul(c, 0.9 + (h % 16) / 90.0)
    return mul(c, 0.94 + (h % 14) / 120.0)

def overlay(v, c, pal, lx, ly, seed):
    h = H(lx, ly, seed + 99)
    if v == 1 and h % 17 == 0:
        return lerp(c, (140, 140, 155), 0.55)
    if v == 2 and h % 13 == 0:
        return lerp(c, pal["accent"], 0.6)
    if v == 3 and h % 9 == 0:
        return (255, 242, 160)
    if v == 4:
        if (lx + ly) % 7 == 0:
            return (225, 255, 255)
        if (lx - ly + 40) % 11 == 0:
            return (50, 150, 205)
    if v == 5 and (lx * 2 + ly) % 9 == 0 and h % 2 == 0:
        return (38, 0, 8)
    return c

def face_rects(u0, v0, w, h, d):
    return {
        "top": (u0 + d, v0, w, d),
        "bottom": (u0 + d + w, v0, w, d),
        "sideA": (u0, v0 + d, d, h),
        "front": (u0 + d, v0 + d, w, h),
        "sideB": (u0 + d + w, v0 + d, d, h),
        "back": (u0 + 2 * d + w, v0 + d, w, h),
    }

SHADE = {"top": 1.12, "front": 1.0, "sideA": 0.93, "sideB": 0.93, "back": 0.86, "bottom": 0.7}

def paint_part(px, part, u0, v0, pal, variant, seed):
    w, h, d = part["sz"]
    base = pal.get(part["mat"], pal["base"])
    pat = part["pat"]
    flag = part["flag"]
    for face, (fx, fy, fw, fh) in face_rects(u0, v0, w, h, d).items():
        for ly in range(fh):
            for lx in range(fw):
                c = pattern(pat, base, pal, lx, ly, fw, fh, seed)
                if part["mat"] == "belly" or (face == "bottom" and part["mat"] == "base"):
                    pass
                if face == "bottom" and pat != "plate" and part["mat"] in ("base", "dark", "light"):
                    c = lerp(c, pal["belly"], 0.55)
                c = mul(c, SHADE[face])
                c = overlay(variant, c, pal, lx + fx, ly + fy, seed)
                px[fx + lx, fy + ly] = c + (255,)
        if face == "front" and flag.startswith("face"):
            ey = max(1, int(fh * 0.34))
            e1 = max(0, int(fw * 0.22))
            e2 = fw - 1 - e1
            if flag == "face3":
                for (ex, ey2) in ((1, 1), (fw - 2, 1), (max(1, fw // 2 - 1), 0), (min(fw - 1, fw // 2 + 1), 0)):
                    if 0 <= ex < fw and 0 <= ey2 < fh:
                        px[fx + ex, fy + ey2] = pal["eye"] + (255,)
            else:
                for ex in (e1, e2):
                    if fw >= 3:
                        px[fx + ex, fy + ey] = pal["eye"] + (255,)
                        if ey > 0:
                            px[fx + ex, fy + ey - 1] = mul(pal["dark"], 0.7) + (255,)
                        if fw >= 6 and ex == e1 and e1 + 1 < fw:
                            px[fx + ex + 1, fy + ey] = pal["eye"] + (255,)
                        if fw >= 6 and ex == e2 and e2 - 1 >= 0:
                            px[fx + ex - 1, fy + ey] = pal["eye"] + (255,)
                    else:
                        px[fx + min(ex, fw - 1), fy + ey] = pal["eye"] + (255,)
                if fh >= 5:
                    for lx in range(max(1, fw // 4), fw - max(1, fw // 4)):
                        px[fx + lx, fy + fh - 2] = mul(pal["dark"], 0.55) + (255,)
        if face == "front" and flag == "mouth" and fh >= 1:
            for lx in range(fw):
                if lx % 2 == 0:
                    px[fx + lx, fy] = pal["bone"] + (255,)

def render_texture(parts, pal, variant, W, Hh, pos, seed):
    img = Image.new("RGBA", (W, Hh), (0, 0, 0, 0))
    px = img.load()
    p2 = variant_palette(pal, variant)
    for i, part in enumerate(parts):
        u0, v0 = pos[i]
        paint_part(px, part, u0, v0, p2, variant, seed + i * 31)
    return img
