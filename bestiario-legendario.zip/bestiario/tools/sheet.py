import sys, importlib
sys.path.insert(0, '.')
from PIL import Image, ImageDraw
from mb import export
from paint import make_palette
from preview import draw_view
import reg
mods = sys.argv[3:] or ['s1']
for mname in mods:
    importlib.import_module(mname)
lo, hi = int(sys.argv[1]), int(sys.argv[2])
items = [r for r in reg.REG if lo <= r['num'] <= hi]
cols = 3
tw, th = 360, 230
rows = (len(items) + cols - 1) // cols
sheet = Image.new('RGB', (cols * tw, rows * th), (30, 30, 30))
d = ImageDraw.Draw(sheet)
for i, r in enumerate(items):
    m = r['build']()
    parts = export(m)
    pal = make_palette(r['pal'])
    side = draw_view(parts, pal, 'side', (tw - 6, th - 22))
    sheet.paste(side, ((i % cols) * tw + 3, (i // cols) * th + 18))
    d.text(((i % cols) * tw + 6, (i // cols) * th + 3), "%d %s (%d partes)" % (r['num'], r['id'], len(parts)), fill=(255, 255, 255))
sheet.save('/home/claude/sheet_%d_%d.png' % (lo, hi))
print('saved')
