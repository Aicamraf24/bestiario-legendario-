# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math
from s1 import serpent
def P(**k):
    return k
SW = dict(move="swim")

# ---------------------------------------------------------------- 31 Megalodón
def megalodon(m=None, pal=None):
    m = m or Model()
    fish(m, bw=12, bh=12, bd=18, y=2, n=4, head_s=(10, 10, 9), snout=(8, 5, 7), mat="base", pat="scale", dorsal=8, tailh=14, pec=(8, 1, 5), taper=0.8)
    return m
reg(31, "megalodon", "Megalodón", "Megalodon", "D", megalodon, 2.6, P(base="#6a7c8c", dark="#34444e", light="#9aaab8", accent="#e6f0f6", accent2="#c82828", belly="#e6eef4", eye="#101010"),
    move="swim", swim=0.35, hp=130, dmg=14, spd=0.30, arm=4, kb=0.6, det=34, ride=1.6, ovi=True, foods=["bacalao"], fx="bleed", abil="Mordida devastadora",
    modes=("water",), biomes=B_OCEAN, w=5, desc="Tiburón prehistórico gigantesco de mandíbulas descomunales.", biome="Océanos profundos")

# ---------------------------------------------------------------- 32 Leviatán Marino
def sea_leviathan(m=None, pal=None):
    m = m or Model()
    fish(m, bw=9, bh=9, bd=16, y=2, n=7, head_s=(8, 8, 9), snout=(6, 4, 7), mat="base", pat="plate", dorsal=6, tailh=10, pec=(7, 1, 5), taper=0.88)
    for i in range(5):
        m.add("plates%d" % i, "body", (0, 11, 6 - i * 4), (5, 3, 3), mat="accent", pat="plate")
    return m
reg(32, "leviatan_marino", "Leviatán Marino", "Sea Leviathan", "D", sea_leviathan, 2.4, P(base="#1e5aa8", dark="#0e2e68", light="#4a9ae0", accent="#50d2ff", accent2="#2aa0ff", belly="#8ec8f0", eye="#7affff"),
    move="swim", swim=0.34, hp=150, dmg=15, spd=0.30, arm=8, kb=0.7, det=34, ride=1.6, ovi=True, foods=["salmon"], fx="shock", abil="Descarga abisal",
    modes=("water",), biomes=B_DEEP, w=3, desc="Monstruo marino enorme de cuerpo alargado y placas azules.", biome="Océanos profundos")

# ---------------------------------------------------------------- 33 Kraken
def kraken(m=None, pal=None):
    m = m or Model()
    octopus(m, mantle=(13, 13, 13), y=14, tent=8, tn=4, tw=3, tstep=6, mat="base", pat="spot", tmat="base", spread=5.5)
    return m
reg(33, "kraken", "Kraken", "Kraken", "D", kraken, 4.0, P(base="#c8405a", dark="#7a1c34", light="#f08aa0", accent="#e8c8c8", accent2="#ffb0c0", belly="#e8a0b0", eye="#ffe040"),
    move="swim", swim=0.28, hp=160, dmg=14, spd=0.28, arm=6, kb=0.8, det=32, ride=1.3, ovi=True, foods=["bacalao", "tinta"], fx="slow", abil="Tentáculos aplastantes: apresan y ralentizan",
    modes=("water",), biomes=B_DEEP, w=3, desc="Pulpo gigantesco de poderosos tentáculos.", biome="Océanos profundos")

# ---------------------------------------------------------------- 34 Serpiente Abisal
def abyssal_serpent(m=None, pal=None):
    m = m or Model()
    serpent(m, n=14, w0=7, h0=6, step=4, ampx=7.0, y0=2, mat="base", pat="glow", period=0.7, taper=0.93)
    head(m, "seg0", "head", 0, 2, 4, 7, 6, 7, snout=(5, 3, 4), jaw=True, fangs=True, mat="base", pat="glow", pivot=(0, 5, 1))
    m.pair("fin", "head", (4, 6, 0), (2, 4, 3), rot=(0, 0, 0.5), mat="accent", pat="membrane")
    m.add("lure", "head", (0, 8, 2), (1, 5, 1), mat="accent", pat="glow", rot=(0.5, 0, 0))
    m.add("lureb", "lure", (0, 13, 4), (3, 3, 3), mat="accent2", pat="glow")
    saddle(m, "seg1", 8, -4, 5, 5, x=4.5)
    return m
reg(34, "serpiente_abisal", "Serpiente Abisal", "Abyssal Serpent", "D", abyssal_serpent, 1.8, P(base="#1a1030", dark="#080414", light="#3c2a64", accent="#a050ff", accent2="#50f0ff", belly="#2a1c48", eye="#50f0ff"),
    move="swim", swim=0.34, hp=90, dmg=10, spd=0.30, arm=2, kb=0.2, det=30, ride=1.6, ovi=True, foods=["pez_tropical"], fx="darkness", abil="Señuelo bioluminiscente: oscurece la vista",
    modes=("water",), biomes=B_DEEP, w=4, desc="Serpiente marina oscura con detalles bioluminiscentes.", biome="Océanos profundos")

# ---------------------------------------------------------------- 35 Dragón Celeste
def sky_dragon(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=8, bh=7, bd=15, lh=7, lw=3, wings=((8, 2, 6), (14, 1, 14), (11, 1, 11)), wmats=("base", "accent", "light"), mat="base", pat="scale",
           hornmat="light", spinemat="accent", neck_n=4, neck_step=3, tail_n=6, tail_step=4, head_s=(5, 5, 7), snout=(3, 3, 4), horn=(1, 4, 1))
    return m
reg(35, "dragon_celeste", "Dragón Celeste", "Sky Dragon", "D", sky_dragon, 3.4, P(base="#4a96e0", dark="#2860b0", light="#a6dcff", accent="#d2f0ff", accent2="#ffffff", belly="#cfe8f8", eye="#ffffff"),
    move="fly", hp=130, dmg=12, spd=0.30, arm=5, kb=0.4, det=36, fs=1.0, ride=1.4, ovi=True, foods=["pollo", "amatista"], fx="freeze", abil="Aliento celeste: congela",
    modes=("air",), biomes=B_MOUNT + B_SNOW, w=2, desc="Dragón volador azul de alas enormes que surca las cumbres.", biome="Cumbres nevadas y montañas")

# ---------------------------------------------------------------- 36 Fénix
def phoenix(m=None, pal=None):
    m = m or Model()
    bird(m, bw=6, bh=6, bd=11, lh=5, mat="base", hmat="accent", bmat="accent2", tailmat="accent", wmats=("accent", "base", "accent2"),
         wings=((6, 2, 6), (11, 1, 12), (8, 1, 9)), tail=(3, 1, 4), legmat="accent2", neck=True, head_s=(4, 4, 5), beak=(2, 2, 3), crest=3, tail_n=1)
    tb = [("t%d" % i, (i - 2) * 2.5) for i in range(5)]
    for i in range(5):
        x = (i - 2) * 2.6
        chain(m, "body", "plume%d_" % i, (x, 9, -6), 4, 2, 1, 2, axis="z", sign=-1, step=4, taper=0.9, steptaper=1.0, mat=("accent2" if i % 2 else "base"),
              pat="glow", role="tail", rot=(0.18, 0, -x * 0.04), ph=0.6 + i * 0.2)
    return m
reg(36, "fenix", "Fénix", "Phoenix", "D", phoenix, 1.9, P(base="#e8561a", dark="#a01c0c", light="#ffd23c", accent="#ff9a1e", accent2="#fff08a", belly="#ffb43c", eye="#ffffff"),
    move="fly", hp=70, dmg=9, spd=0.30, arm=1, kb=0.0, det=34, fs=0.95, ride=1.5, ovi=True, foods=["semillas", "blaze"], fx="fire", abil="Plumas ardientes: prende fuego",
    dims=("overworld", "nether"), modes=("air", "cave"), biomes=B_DESERT + B_MOUNT + B_NETHER, w=3, desc="Ave de fuego de plumaje naranja, rojo y amarillo.", biome="Desiertos, montañas y Nether")

# ---------------------------------------------------------------- 37 Quimera
def chimera(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 9, 10, 18, 10
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="fur", foot=(5, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 5, bd / 2.0 + 2, 7, 7, 7, snout=(4, 3, 4), jaw=True, fangs=True, ears=(2, 2, 1, 3, -1, "dark"), mat="light", pat="fur", pivot=(0, top - 1, bd / 2.0))
    m.add("mane", "body", (0, top - 5, bd / 2.0 - 2), (10, 10, 3), mat="accent2", pat="fur")
    # cabeza de cabra en el lomo
    m.add("goatneck", "body", (0, top, 0), (4, 6, 4), mat="dark", pat="fur", role="neck", pivot=(0, top, 0), rot=(0.25, 0, 0))
    head(m, "goatneck", "head2", 0, top + 5, 2, 5, 5, 6, snout=(3, 3, 3), jaw=True, mat="dark", pat="fur", idx=1, pivot=(0, top + 6, 0))
    horns(m, "head2", "ghorn", 1.5, top + 10, 1, 1, 4, 1, tilt=(-0.4, 0, 0.2), mat="bone", segs=2, curl=0.4)
    wing(m, "body", "wing", 3, top - 1, -2, [(5, 2, 5), (8, 1, 9), (6, 1, 7)], ["accent2", "accent2", "dark"], pat="feather", fold=1.25)
    t = chain(m, "body", "tail", (0, top - 4, -bd / 2.0), 6, 2, 2, 2, axis="z", sign=-1, step=3, taper=0.97, steptaper=1.0, mat="accent", pat="scale", role="tail", rot=(0.2, 0, 0), ph=0.5)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    head(m, t[-1], "head3", 0, ey - 2, ez - 3, 3, 3, 4, snout=(2, 2, 2), jaw=False, mat="accent", pat="scale", idx=2, pivot=(ex, ey, ez + 1), face="face")
    saddle(m, "body", top, -1, 7, 7)
    return m
reg(37, "quimera", "Quimera", "Chimera", "D", chimera, 2.4, P(base="#a87430", dark="#5e3e18", light="#d8b070", accent="#4a9a3a", accent2="#8a5a2a", belly="#d2a860", eye="#ffd23c"),
    move="fly", hp=100, dmg=11, spd=0.30, arm=3, kb=0.3, det=30, fs=0.75, ride=1.4, foods=["res"], fx="poison", abil="Tres ataques a la vez: león, cabra y serpiente",
    modes=("surface", "air"), biomes=B_PLAINS + B_DESERT + B_MOUNT, w=4, desc="Criatura híbrida fantástica con cabeza de león, de cabra y cola de serpiente.", biome="Praderas, badlands y montañas")

# ---------------------------------------------------------------- 38 Wyvern de Veneno
def wyvern(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=8, bh=7, bd=14, lh=9, lw=4, legs=2, wings=((6, 2, 6), (15, 1, 14), (12, 1, 11)), wmats=("base", "accent", "accent"), mat="base", pat="scale",
           hornmat="accent2", spinemat="accent2", neck_n=3, neck_step=3, tail_n=7, tail_step=4, head_s=(5, 5, 7), snout=(3, 3, 5), horn=(1, 4, 1), foot=True)
    return m
reg(38, "wyvern_veneno", "Wyvern de Veneno", "Venom Wyvern", "D", wyvern, 2.8, P(base="#4a7a2a", dark="#284a14", light="#8ac83c", accent="#9a3cd2", accent2="#d2ff3c", belly="#b8d070", eye="#d2ff3c"),
    move="fly", hp=90, dmg=11, spd=0.30, arm=3, kb=0.2, det=34, fs=0.9, ride=1.4, ovi=True, foods=["carne_podrida", "ojo_arana"], fx="poison", abil="Aguijón tóxico: veneno intenso",
    modes=("air", "surface"), biomes=B_SWAMP + ["jungle", "dark_forest"], w=3, desc="Dragón de dos patas con alas membranosas y una cola de veneno.", biome="Pantanos, selvas y bosques oscuros")

# ---------------------------------------------------------------- 39 Mantarraya Fantasma
def ghost_ray(m=None, pal=None):
    m = m or Model()
    ray(m, bw=12, bh=3, bd=14, y=4, wings=((8, 1, 14), (9, 1, 10)), tail_n=6, mat="base", pat="mist", wmat="base")
    return m
reg(39, "mantarraya_fantasma", "Mantarraya Fantasma", "Phantom Manta", "D", ghost_ray, 1.3, P(base="#a89cf0", dark="#5a4cb0", light="#e0dcff", accent="#7ad0ff", accent2="#ffffff", belly="#d8d4ff", eye="#ffffff"),
    move="fly", hp=60, dmg=8, spd=0.30, arm=0, kb=0.0, det=36, fs=0.9, ride=1.5, ovi=False, foods=["bacalao", "amatista"], fx="levitate", abil="Aleteo espectral: eleva a los atacados",
    modes=("air",), biomes=B_OCEAN + ["beach", "river"], w=3, desc="Enorme mantarraya voladora de apariencia espectral.", biome="Costas y océanos (sobre el agua)")

# ---------------------------------------------------------------- 40 Ballena de Cristal
def crystal_whale(m=None, pal=None):
    m = m or Model()
    fish(m, bw=14, bh=14, bd=24, y=2, n=3, head_s=(13, 12, 11), snout=(10, 6, 5), mat="base", pat="crystal", dorsal=0, tailh=16, pec=(9, 1, 6), taper=0.75, fluke=True, jaw=True, fangs=False)
    for i in range(4):
        m.add("ridge%d" % i, "body", (0, 16, 8 - i * 4), (2, 3, 3), mat="accent", pat="crystal")
    return m
reg(40, "ballena_cristal", "Ballena de Cristal", "Crystal Whale", "D", crystal_whale, 3.4, P(base="#9ad4f0", dark="#3c82c0", light="#e0f8ff", accent="#78e6ff", accent2="#ffffff", belly="#d4eefa", eye="#ffffff"),
    move="swim", swim=0.28, hp=190, dmg=12, spd=0.26, arm=6, kb=0.9, det=28, ride=1.4, foods=["hierba_marina", "amatista"], fx="slow", abil="Coletazo cristalino",
    modes=("water",), biomes=B_OCEAN + ["frozen"], w=3, desc="Ballena gigantesca de cuerpo y aletas cristalinas.", biome="Océanos fríos y profundos")
