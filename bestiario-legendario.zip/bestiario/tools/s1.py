# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math

def P(**k):
    return k

# ---------------------------------------------------------------- 1 Grifo Real
def griffin(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 8, 9, 18, 10
    quad_base(m, bw, bh, bd, lh, 3, mat="base", pat="fur", foot=(4, 2, 5))
    top = lh + bh
    head(m, "body", "head", 0, top - 2, bd / 2.0 + 1, 6, 6, 6, snout=(3, 3, 5), jaw=True, mat="light", smat="accent", pat="feather",
         pivot=(0, top + 1, bd / 2.0 - 1))
    m.add("beak_hook", "head_sn", (0, top - 1 - 1.5, bd / 2.0 + 1 + 3 + 4), (2, 2, 1), mat="accent")
    m.add("ruff", "body", (0, top - 4, bd / 2.0 - 3), (9, 8, 4), mat="accent2", pat="feather")
    wing(m, "body", "wing", 4, top - 1, 1, [(7, 2, 6), (9, 1, 10), (7, 1, 8)], ["accent2", "accent2", "dark"], pat="feather", fold=1.25)
    t = chain(m, "body", "tail", (0, lh + bh * 0.6, -bd / 2.0), 4, 2, 2, 2, axis="z", sign=-1, step=3, taper=1.0, steptaper=1.0,
              mat="base", pat="fur", role="tail", rot=(0.08, 0, 0), ph=0.3)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("tuft", t[-1], (0, ey - 2, ez - 1), (3, 4, 4), mat="accent2", pat="fur", pivot=(ex, ey, ez + 1))
    saddle(m, "body", top, 0, 7, 7)
    return m
reg(1, "grifo_real", "Grifo Real", "Royal Griffin", "A", griffin, 2.0, P(base="#c98a2b", dark="#7a4a1c", light="#f1e9d8", accent="#e6b422", accent2="#6b4423", belly="#e1b25a", eye="#ffd21a"),
    move="fly", hp=70, dmg=9, spd=0.30, arm=2, kb=0.2, det=28, fs=0.85, ride=1.5, ovi=True, foods=["pollo"], fx="knock",
    abil="Embestida alada: derriba a su presa con un golpe de garras", modes=("air", "surface"), biomes=B_MOUNT + B_PLAINS, time="day", w=7,
    desc="Cuerpo de león, cabeza y alas de águila. Señor de los cielos abiertos, defiende ferozmente su territorio.", biome="Montañas, praderas y acantilados")

# ---------------------------------------------------------------- 2 Ciervo Cristalino
def crystal_deer(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 12, 8, 16, 7
    quad_base(m, bw, bh, bd, lh, 2, mat="base", pat="crystal", foot=(3, 1, 3))
    top = lh + bh
    m.add("neck", "body", (0, top - 3, bd / 2.0 - 1), (4, 9, 4), mat="base", pat="crystal", role="neck", pivot=(0, top - 3, bd / 2.0 - 1), rot=(0.4, 0, 0))
    head(m, "neck", "head", 0, top + 5, bd / 2.0 + 1.5, 4, 5, 6, snout=(3, 3, 3), jaw=False, ears=(1, 3, 2, 3, -1, "light", (0, 0, 0.5)),
         mat="base", pat="crystal", pivot=(0, top + 6, bd / 2.0))
    horns(m, "head", "antler", 1.5, top + 10, bd / 2.0 + 0.5, 1, 4, 1, tilt=(0, 0, 0.25), mat="accent", segs=2, curl=0.35, pat="crystal")
    m.pair("tine", "head", (3, top + 12, bd / 2.0 + 0.5), (1, 4, 1), rot=(0, 0, 0.9), mat="accent", pat="crystal")
    m.pair("tine2", "head", (3.5, top + 13, bd / 2.0 + 0.5), (1, 3, 1), rot=(0, 0, 0.9), mat="accent2")
    m.add("tail", "body", (0, top - 3, -bd / 2.0 - 1), (3, 4, 2), role="tail", mat="light", pivot=(0, top - 1, -bd / 2.0))
    saddle(m, "body", top, 0, 5, 7)
    return m
reg(2, "ciervo_cristalino", "Ciervo Cristalino", "Crystal Stag", "A", crystal_deer, 2.2, P(base="#8fc4ea", dark="#4a78b8", light="#dff4ff", accent="#7ae6ff", accent2="#ffffff", belly="#cfe8f8", eye="#ffffff"),
    hp=56, dmg=7, spd=0.34, arm=1, kb=0.1, det=24, ride=1.7, foods=["bayas", "flores"], fx="slow", abil="Astas de cristal: ralentizan a los atacados",
    modes=("surface",), biomes=B_FOREST + ["meadow"], w=8, desc="Ciervo de cuerpo cristalino con astas de cristal luminoso que brillan en la penumbra.", biome="Bosques y praderas")

# ---------------------------------------------------------------- 3 Lobo de Escarcha
def frost_wolf(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 8, 8, 14, 7
    quad_base(m, bw, bh, bd, lh, 3, mat="base", pat="fur", foot=(3, 1, 4), lpat="fur")
    top = lh + bh
    head(m, "body", "head", 0, top - 3, bd / 2.0 + 2, 6, 6, 5, snout=(3, 3, 5), jaw=True, fangs=True,
         ears=(2, 3, 1, 2, -1, "accent"), mat="base", pat="fur", pivot=(0, top, bd / 2.0))
    for i in range(4):
        m.add("ice%d" % i, "body", (0, top, 5 - i * 3.2), (2, 3 + (i % 2), 2), mat="accent", pat="crystal")
    m.pair("shard", "body", (4, top - 2, 4), (2, 4, 2), rot=(0, 0, 0.35), mat="accent", pat="crystal")
    t = chain(m, "body", "tail", (0, lh + bh - 2, -bd / 2.0), 3, 3, 3, 3, axis="z", sign=-1, step=3, taper=0.95, steptaper=1.0,
              mat="base", pat="fur", role="tail", rot=(0.1, 0, 0), ph=0.4)
    saddle(m, "body", top, 0, 5, 6)
    return m
reg(3, "lobo_escarcha", "Lobo de Escarcha", "Frost Wolf", "A", frost_wolf, 1.6, P(base="#e4eefa", dark="#6a98d6", light="#ffffff", accent="#78d2ff", accent2="#3c78dc", belly="#d4e2f4", eye="#50c8ff"),
    hp=48, dmg=7, spd=0.36, arm=1, kb=0.0, det=30, ride=1.7, foods=["cordero"], fx="freeze", abil="Aliento helado: congela y ralentiza",
    modes=("surface",), biomes=B_SNOW, w=10, grp_size=(1, 3), desc="Lobo de pelaje blanco y azul que emana energía congelante. Caza en manadas.", biome="Biomas nevados")

# ---------------------------------------------------------------- 4 Oso Colosal
def colossal_bear(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 9, 12, 20, 14
    quad_base(m, bw, bh, bd, lh, 5, mat="base", pat="fur", foot=(5, 1, 2), lx=4.5)
    top = lh + bh
    m.add("hump", "body", (0, top, 4), (11, 4, 8), mat="base", pat="fur")
    head(m, "body", "head", 0, top - 6, bd / 2.0 + 3, 9, 8, 8, snout=(5, 4, 4), jaw=True, fangs=True, smat="belly",
         ears=(3, 3, 2, 3.5, -1, "dark"), mat="base", pat="fur", pivot=(0, top - 2, bd / 2.0 - 1))
    m.add("tail", "body", (0, top - 3, -bd / 2.0 - 1), (3, 3, 2), role="tail", mat="dark", pivot=(0, top - 2, -bd / 2.0))
    saddle(m, "body", top + 3, 3, 8, 9)
    return m
reg(4, "oso_colosal", "Oso Colosal", "Colossal Bear", "A", colossal_bear, 2.6, P(base="#8c5428", dark="#5a341a", light="#b2743c", accent="#e6e1cd", accent2="#3a2210", belly="#cda064", eye="#ffc83c"),
    hp=130, dmg=13, spd=0.26, arm=6, kb=0.5, det=22, ride=1.1, foods=["salmon", "miel"], fx="stomp", abil="Zarpazo sísmico: golpea a los enemigos cercanos",
    modes=("surface",), biomes=B_FOREST, w=7, desc="Enorme oso marrón de fuerza y resistencia descomunales.", biome="Bosques y taigas", step=1.0)

# ---------------------------------------------------------------- 5 Zorro de las Sombras
def shadow_fox(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 6, 6, 11, 5
    quad_base(m, bw, bh, bd, lh, 2, mat="base", pat="fur", foot=(2, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 3, bd / 2.0 + 1.5, 5, 5, 5, snout=(2, 2, 4), jaw=True, ears=(2, 5, 1, 1.8, -0.5, "accent"),
         mat="base", pat="fur", pivot=(0, top, bd / 2.0 - 1))
    t = chain(m, "body", "tail", (0, top - 2, -bd / 2.0), 4, 5, 5, 4, axis="z", sign=-1, step=3, taper=0.95, steptaper=1.0,
              mat="base", pat="fur", role="tail", rot=(0.1, 0, 0), ph=0.5)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("tailglow", t[-1], (0, ey - 2, ez - 1), (4, 4, 3), mat="accent", pat="glow", pivot=(ex, ey, ez + 1))
    for i in range(3):
        m.pair("wisp%d" % i, "body", (4.5, top + 1 + i, 3 - i * 4), (1, 1, 1), mat="accent2", pat="glow")
    saddle(m, "body", top, 0, 4, 5)
    return m
reg(5, "zorro_sombras", "Zorro de las Sombras", "Shadow Fox", "A", shadow_fox, 1.1, P(base="#1b1626", dark="#0a0810", light="#3c3250", accent="#a046f0", accent2="#dc96ff", belly="#2a2238", eye="#be5aff"),
    hp=34, dmg=6, spd=0.40, arm=0, kb=0.0, det=26, ride=1.9, foods=["bayas", "conejo"], fx="darkness", abil="Velo sombrío: ciega brevemente a sus presas",
    modes=("surface",), biomes=B_FOREST + B_DARK, time="night", w=8, desc="Zorro negro con detalles morados y energía sombría. Rápido y escurridizo.", biome="Bosques (de noche)")

# ---------------------------------------------------------------- 6 Tortuga Colosal
def colossal_turtle(m=None, pal=None):
    m = m or Model()
    lh = 5
    m.add("body", None, (0, lh, 0), (14, 4, 18), role="body", mat="accent2", pat="")
    legs(m, "body", [(7.5, 6, 0, False), (-7.5, 6, 1, False), (7.5, -6, 1, True), (-7.5, -6, 0, True)], 4, 5, lh, mat="accent", pat="scale", foot=(5, 1, 6))
    m.add("shell", "body", (0, lh + 4, 0), (16, 6, 18), mat="base", pat="shell")
    m.add("shell2", "shell", (0, lh + 10, 0), (11, 3, 13), mat="light", pat="shell")
    m.add("shell3", "shell2", (0, lh + 13, 0), (6, 2, 7), mat="base", pat="shell")
    m.add("neck", "body", (0, lh + 1, 9), (5, 4, 4), mat="accent", pat="scale", role="neck", pivot=(0, lh + 3, 8))
    head(m, "neck", "head", 0, lh + 1, 12, 6, 5, 6, snout=(4, 3, 2), jaw=False, mat="accent", pat="scale", pivot=(0, lh + 3, 10))
    m.add("tail", "body", (0, lh + 1, -10), (3, 2, 4), role="tail", mat="accent", pivot=(0, lh + 2, -9))
    saddle(m, "shell", lh + 13, 0, 8, 8)
    return m
reg(6, "tortuga_colosal", "Tortuga Colosal", "Colossal Turtle", "A", colossal_turtle, 2.0, P(base="#4a8a32", dark="#285a1e", light="#78b448", accent="#96b155", accent2="#c8be6e", belly="#d2c880", eye="#141414"),
    hp=160, dmg=8, spd=0.18, arm=14, kb=0.9, det=16, ride=0.9, ovi=True, foods=["hierba_marina"], fx="stomp", abil="Caparazón blindado: resiste casi todo daño",
    modes=("surface",), biomes=["swamp", "mangrove", "beach", "jungle", "river"], w=6, desc="Tortuga gigante verde con un caparazón extremadamente resistente.", biome="Pantanos, playas y selvas")

# ---------------------------------------------------------------- 7 Rinoceronte de Hierro
def iron_rhino(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 8, 12, 20, 13
    quad_base(m, bw, bh, bd, lh, 5, mat="base", pat="metal", foot=(5, 2, 5), lx=4)
    top = lh + bh
    for i in range(3):
        m.add("plate%d" % i, "body", (0, top, 5 - i * 5.5), (11, 3, 5), mat="dark", pat="plate")
    m.pair("armor", "body", (6.8, lh + 2, 0), (1, 8, 14), mat="dark", pat="plate")
    head(m, "body", "head", 0, top - 8, bd / 2.0 + 3, 8, 8, 9, snout=(6, 5, 4), jaw=False, ears=(2, 3, 1, 3.5, -2, "dark"), mat="base", pat="metal",
         pivot=(0, top - 3, bd / 2.0 - 1))
    m.add("horn1", "head_sn", (0, top - 2, bd / 2.0 + 3 + 6), (3, 6, 3), mat="accent", pat="metal", rot=(0.7, 0, 0), pivot=(0, top - 2, bd / 2.0 + 3 + 6))
    m.add("horn2", "head", (0, top - 8 + 8, bd / 2.0 + 3 + 1), (2, 4, 2), mat="accent", pat="metal", rot=(0.5, 0, 0), pivot=(0, top, bd / 2.0 + 3 + 1))
    m.add("tail", "body", (0, top - 3, -bd / 2.0 - 3), (2, 6, 2), role="tail", mat="dark", pivot=(0, top - 1, -bd / 2.0), rot=(0.4, 0, 0))
    saddle(m, "body", top + 3, 0, 8, 9)
    return m
reg(7, "rinoceronte_hierro", "Rinoceronte de Hierro", "Iron Rhinoceros", "A", iron_rhino, 2.6, P(base="#7d8088", dark="#464850", light="#b4b6be", accent="#cdcdd2", accent2="#c87832", belly="#5e6068", eye="#ff5a3c"),
    hp=150, dmg=14, spd=0.27, arm=12, kb=0.8, det=22, ride=1.3, foods=["zanahoria"], fx="knock", abil="Embestida de hierro: lanza por los aires",
    modes=("surface",), biomes=B_PLAINS + B_DESERT, w=6, step=1.0, desc="Rinoceronte con armadura metálica y cuernos de hierro. Embiste sin freno.", biome="Sabanas, llanuras y badlands")

# ---------------------------------------------------------------- 8 Serpiente Esmeralda
def serpent(m, n=10, w0=6, h0=5, step=4, ampx=5.0, y0=0, z0=0, mat="base", pat="scale", period=0.8, taper=0.9, head_s=(6, 5, 6), snout=(4, 3, 3), fangs=True, ph=0.5, stripe=False):
    z = z0
    w, h = float(w0), float(h0)
    prev = None
    names = []
    for i in range(n):
        x = math.sin(i * period) * ampx
        s = max(2, int(round(step)))
        nm = "seg%d" % i
        m.add(nm, prev, (x, y0, z - s / 2.0), (w, h, s), pivot=(x, y0 + h / 2.0, z), role="seg", idx=i, amp=1.0, mat=mat,
              pat=("stripe" if (stripe and i % 2 == 0) else pat), ph=ph * i)
        names.append(nm)
        prev = nm
        z -= s
        w = max(1.5, w * taper)
        h = max(1.5, h * taper)
    return names

def emerald_snake(m=None, pal=None):
    m = m or Model()
    names = serpent(m, n=11, w0=6, h0=5, step=4, ampx=5.0, mat="base", pat="scale", z0=0, taper=0.92)
    hx_ = math.sin(0) * 5.0
    head(m, "seg0", "head", 0, 0, 4, 6, 5, 6, snout=(4, 3, 3), jaw=True, fangs=True, mat="base", pat="scale", pivot=(0, 2.5, 1))
    m.add("tongue", "head_sn", (0, 0.5, 11), (1, 1, 3), mat="accent", role="static")
    m.add("crest", "seg0", (0, 5, 0), (2, 3, 4), mat="accent2", pat="")
    saddle(m, "seg1", 5, -4, 4, 5, x=3.6)
    return m
reg(8, "serpiente_esmeralda", "Serpiente Esmeralda", "Emerald Serpent", "A", emerald_snake, 0.9, P(base="#1e9646", dark="#0c5528", light="#5adc78", accent="#e6323c", accent2="#c8dc50", belly="#cddc78", eye="#ffe632"),
    move="ground", hp=32, dmg=5, spd=0.30, arm=0, kb=0.0, det=20, ride=1.5, ovi=True, foods=["conejo"], fx="poison", abil="Mordisco venenoso",
    modes=("surface",), biomes=B_FOREST + B_SWAMP, w=9, desc="Serpiente de escamas verdes brillantes que repta entre la vegetación.", biome="Selvas, pantanos y bosques")

# ---------------------------------------------------------------- 9 Águila Gigante
def giant_eagle(m=None, pal=None):
    m = m or Model()
    bird(m, bw=7, bh=7, bd=12, lh=6, mat="base", hmat="light", bmat="accent", tailmat="light", wmats=("base", "accent2", "dark"),
         wings=((6, 2, 6), (10, 1, 11), (8, 1, 9)), tail=(7, 1, 8), legmat="accent")
    return m
reg(9, "aguila_gigante", "Águila Gigante", "Giant Eagle", "A", giant_eagle, 1.5, P(base="#6e4826", dark="#46301a", light="#f5f0e6", accent="#f0be28", accent2="#96643a", belly="#8a6a40", eye="#ffdc28"),
    move="fly", hp=40, dmg=7, spd=0.30, arm=0, kb=0.0, det=32, fs=0.9, ride=1.6, ovi=True, foods=["pollo"], fx="bleed", abil="Garras afiladas: provocan hemorragia",
    modes=("air",), biomes=B_MOUNT + B_PLAINS + B_FOREST + B_DESERT, time="day", w=8, desc="Águila enorme de plumaje marrón y cabeza blanca. Domina las alturas.", biome="Montañas y regiones abiertas")

# ---------------------------------------------------------------- 10 Dragón de los Bosques
def forest_dragon(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=9, bh=8, bd=16, lh=7, lw=3, wmats=("base", "accent", "accent"), mat="base", pat="scale", hornmat="accent2", spinemat="accent2")
    for i in range(3):
        m.pair("leaf%d" % i, "body", (4.5, 15, 5 - i * 5), (3, 1, 3), mat="accent", pat="spot", rot=(0, 0, -0.5))
    return m
reg(10, "dragon_bosques", "Dragón de los Bosques", "Forest Dragon", "A", forest_dragon, 3.2, P(base="#32963c", dark="#195a23", light="#6ec850", accent="#96d746", accent2="#e66496", belly="#bec86e", eye="#ffdc3c"),
    move="fly", hp=120, dmg=11, spd=0.28, arm=5, kb=0.4, det=34, fs=0.85, ride=1.3, ovi=True, foods=["manzana_dorada"], fx="poison", abil="Aliento de esporas: envenena",
    modes=("air", "surface"), biomes=B_FOREST, time="day", w=4, desc="Dragón verde con escamas y rasgos vegetales: hojas, flores y espinas de madera.", biome="Bosques y selvas")
