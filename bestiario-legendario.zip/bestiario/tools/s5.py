# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math
from s1 import serpent, griffin, forest_dragon
from s2 import blood_spider
from s3 import scorpion, manticore
def P(**k):
    return k

# ---------------------------------------------------------------- 41 Rey de las Sombras
def shadow_king(m=None, pal=None):
    m = m or Model()
    biped(m, tw=12, th=14, td=7, lh=12, lw=5, aw=4, ah=15, head_s=(8, 8, 7), mat="base", pat="plate", fist=True, hpat="plate")
    top = 26
    m.pair("pauldron", "body", (8, top - 3, 0), (6, 4, 7), mat="accent", pat="plate")
    for i in range(5):
        m.add("crown%d" % i, "head", (-4 + i * 2, top + 7, 1), (1, 3 + (i % 2), 1), mat="accent2")
    horns(m, "head", "horn", 3, top + 4, 1, 2, 4, 2, tilt=(0, 0, 0.45), mat="accent", segs=2, curl=0.5)
    m.add("cape", "body", (0, 6, -4), (14, 20, 1), mat="dark", pat="membrane", role="tail", pivot=(0, 26, -3.5), rot=(0.06, 0, 0))
    m.add("aura", "body", (0, 17, 4), (6, 6, 1), mat="accent", pat="glow")
    return m
reg(41, "rey_sombras", "Rey de las Sombras", "Shadow King", "E", shadow_king, 4.2, P(base="#2a1a40", dark="#0c0618", light="#4c3270", accent="#8a30e8", accent2="#d8a0ff", belly="#34224c", eye="#ff50ff"),
    hp=260, dmg=17, spd=0.28, arm=10, kb=0.8, det=34, ride=1.2, foods=["carne_podrida", "amatista"], fx="wither", abil="Poder sombrío: marchita y oscurece",
    modes=("surface", "cave"), time="night", w=2, step=1.0, desc="Soberano oscuro de gran tamaño con poderes sombríos y una corona de espinas.", biome="Cualquier bioma, de noche (muy raro)")

# ---------------------------------------------------------------- 42 Dragón del Apocalipsis
def apoc_dragon(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=12, bh=11, bd=22, lh=10, lw=5, wings=((9, 3, 7), (18, 1, 16), (14, 1, 13)), wmats=("base", "accent", "dark"), mat="base", pat="scale",
           hornmat="accent2", spinemat="accent", neck_n=4, neck_step=4, neck_w=6, tail_n=7, tail_w=7, tail_step=5, head_s=(8, 7, 9), snout=(5, 4, 5), horn=(2, 6, 2), spines=8, spine_size=(2, 4, 3))
    return m
reg(42, "dragon_apocalipsis", "Dragón del Apocalipsis", "Apocalypse Dragon", "E", apoc_dragon, 5.0, P(base="#241418", dark="#0a0608", light="#5a2428", accent="#e0301e", accent2="#ff9a1e", belly="#6a2a24", eye="#ff4020"),
    move="fly", hp=320, dmg=20, spd=0.30, arm=12, kb=1.0, det=42, fs=1.0, ride=1.3, ovi=True, foods=["res", "blaze"], fx="fire", abil="Aliento apocalíptico: prende fuego",
    dims=("overworld", "nether"), modes=("air", "cave"), biomes=B_NETHER + B_DESERT, w=2, step=1.0, desc="Dragón gigantesco de escamas negras y rojas envuelto en llamas.", biome="Nether y badlands (muy raro)")

# ---------------------------------------------------------------- 43 Titán de Piedra
def stone_titan(m=None, pal=None):
    m = m or Model()
    biped(m, tw=16, th=16, td=10, lh=12, lw=7, aw=7, ah=18, head_s=(8, 7, 8), mat="base", pat="stone", fist=True)
    top = 28
    m.pair("peak", "body", (9, top - 2, 0), (6, 8, 6), mat="light", pat="stone", rot=(0, 0, -0.2))
    for i in range(4):
        m.add("rock%d" % i, "body", (-6 + i * 4, top, -3), (4, 4 + (i % 2) * 2, 4), mat="dark", pat="stone")
    m.add("moss", "body", (0, top, 0), (10, 1, 8), mat="accent", pat="spot")
    m.add("chestgem", "body", (0, 20, 5.2), (4, 4, 1), mat="accent2", pat="glow")
    return m
reg(43, "titan_piedra", "Titán de Piedra", "Stone Titan", "E", stone_titan, 6.0, P(base="#80848a", dark="#44484e", light="#b4b8be", accent="#5a8a3a", accent2="#ffb84a", belly="#6a6e74", eye="#ffb84a"),
    hp=380, dmg=19, spd=0.20, arm=18, kb=1.0, det=30, ride=0.9, foods=["carbon", "hierro"], fx="stomp", abil="Pisotón sísmico: derriba a todo lo cercano",
    modes=("surface",), biomes=B_MOUNT + B_DESERT, w=2, step=1.0, desc="Coloso formado por rocas y estructuras montañosas.", biome="Montañas y badlands (muy raro)")

# ---------------------------------------------------------------- 44 Reina de las Arañas
def spider_queen(m=None, pal=None):
    m = m or Model()
    spider(m, bw=12, bh=8, bd=12, lh=10, abd=(15, 11, 17), up=13, low=13, leg_t=3, mat="base", pat="chitin", abmat="base", abpat="spot", leg_mat="dark")
    for i in range(5):
        m.add("crown%d" % i, "head", (-4 + i * 2, 20, 8), (1, 3 + (i % 2), 1), mat="accent2")
    m.add("mark", "abdomen", (0, 22, -12), (5, 1, 6), mat="accent", pat="glow")
    return m
reg(44, "reina_aranas", "Reina de las Arañas", "Spider Queen", "E", spider_queen, 3.4, P(base="#1a1018", dark="#08040a", light="#3c2230", accent="#c81e28", accent2="#e8c040", belly="#2a1820", eye="#ff2830"),
    hp=240, dmg=16, spd=0.30, arm=8, kb=0.6, det=34, ride=1.2, ovi=True, foods=["ojo_arana"], fx="web", abil="Telaraña letal: inmoviliza a sus presas",
    modes=("cave", "surface"), biomes=B_DARK + B_FOREST, time="night", w=2, desc="Araña gigantesca de aspecto regio que domina a las demás.", biome="Bosques oscuros y cuevas (muy rara)")

# ---------------------------------------------------------------- 45 Dios de las Tormentas
def storm_god(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 10, 11, 20, 11
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="glow", foot=(5, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 6, bd / 2.0 + 3, 8, 8, 8, snout=(5, 4, 5), jaw=True, fangs=True, mat="light", pat="mist", pivot=(0, top - 2, bd / 2.0))
    horns(m, "head", "bolt", 3, top + 2, bd / 2.0 + 2, 1, 5, 1, tilt=(-0.2, 0, 0.3), mat="accent", segs=3, curl=-0.5, pat="glow")
    for i in range(4):
        m.add("cloud%d" % i, "body", (0, top, 7 - i * 4), (7, 3, 4), mat="light", pat="mist")
    wing(m, "body", "wing", 4, top - 1, 0, [(7, 2, 6), (13, 1, 13), (10, 1, 10)], ["base", "light", "accent2"], pat="mist", fold=1.25)
    chain(m, "body", "tail", (0, top - 3, -bd / 2.0), 5, 3, 3, 3, axis="z", sign=-1, step=4, taper=0.85, steptaper=1.0, mat="accent", pat="glow", role="tail", rot=(0.12, 0, 0), ph=0.7)
    for i in range(3):
        m.pair("zap%d" % i, "body", (6.5, lh + 4 + i * 2, 5 - i * 5), (1, 3, 1), mat="accent", pat="glow", role="tentacle", idx=i)
    saddle(m, "body", top, 0, 8, 8)
    return m
reg(45, "dios_tormentas", "Dios de las Tormentas", "Storm God", "E", storm_god, 4.6, P(base="#c8d8f4", dark="#5a6ca8", light="#ffffff", accent="#ffe03c", accent2="#7ad0ff", belly="#dbe6fa", eye="#ffff90"),
    move="fly", hp=300, dmg=18, spd=0.30, arm=8, kb=0.8, det=40, fs=1.0, ride=1.3, foods=["cobre", "redstone"], fx="shock", abil="Descarga eléctrica: daño mágico y aturdimiento",
    modes=("air", "surface"), biomes=B_MOUNT + B_PLAINS, w=2, step=1.0, desc="Criatura colosal rodeada de electricidad y tormentas.", biome="Montañas y llanuras (muy raro)")

# ---------------------------------------------------------------- 46 Leviatán Primordial
def primordial_leviathan(m=None, pal=None):
    m = m or Model()
    serpent(m, n=16, w0=12, h0=11, step=6, ampx=9.0, y0=3, mat="base", pat="scale", period=0.6, taper=0.94)
    head(m, "seg0", "head", 0, 3, 5, 10, 9, 10, snout=(7, 5, 6), jaw=True, fangs=True, mat="base", pat="scale", pivot=(0, 7, 1))
    for k, sx in enumerate((-1, 1)):
        nk = chain(m, "seg1", "neck%d_" % k, (sx * 5, 8, -2), 3, 5, 5, 5, axis="y", sign=1, step=5, taper=0.95, steptaper=1.0, mat="base", pat="scale", role="neck", rot=(0.12, 0, -sx * 0.2), ph=0.8 + k)
        tx, ty, tz = tip(m, nk[-1], "y", 1)
        head(m, nk[-1], "headx%d" % k, tx, ty - 3, tz + 3, 6, 6, 7, snout=(4, 3, 4), jaw=True, fangs=True, mat="base", pat="scale", idx=k + 1, pivot=(tx, ty, tz))
    for i in range(6):
        m.add("fin%d" % i, "seg%d" % (i + 1), (0, 8, -3), (1, 5, 4), mat="accent", pat="membrane")
    saddle(m, "seg2", 9, -3, 7, 6, x=8.4)
    return m
reg(46, "leviatan_primordial", "Leviatán Primordial", "Primordial Leviathan", "E", primordial_leviathan, 3.6, P(base="#1e64b4", dark="#0a2c68", light="#3cc8a0", accent="#50e6ff", accent2="#2ac88c", belly="#8ec8e0", eye="#fff03c"),
    move="swim", swim=0.34, hp=360, dmg=19, spd=0.30, arm=10, kb=1.0, det=40, ride=1.5, ovi=True, foods=["salmon", "tinta_luz"], fx="shock", abil="Tormenta marina: descargas y ralentización",
    modes=("water",), biomes=B_DEEP, w=2, step=1.0, desc="Monstruo marino legendario de dimensiones enormes y varias cabezas.", biome="Océanos profundos (muy raro)")

# ---------------------------------------------------------------- 47 Coloso de Hielo
def ice_colossus(m=None, pal=None):
    m = m or Model()
    biped(m, tw=17, th=16, td=11, lh=12, lw=7, aw=7, ah=18, head_s=(9, 8, 8), mat="base", pat="crystal", fist=True)
    top = 28
    for i in range(6):
        m.add("ice%d" % i, "body", (-8 + i * 3.2, top, -3), (3, 5 + (i % 3) * 2, 3), mat="accent", pat="crystal", rot=(0, 0, (i - 2.5) * 0.08))
    m.pair("shard", "body", (10, top - 2, 0), (5, 9, 5), mat="light", pat="crystal", rot=(0, 0, -0.25))
    m.add("crownice", "head", (0, top + 7, 0), (7, 5, 7), mat="accent", pat="crystal")
    return m
reg(47, "coloso_hielo", "Coloso de Hielo", "Ice Colossus", "E", ice_colossus, 6.0, P(base="#a8dcf8", dark="#4a8cd0", light="#e8f8ff", accent="#78e0ff", accent2="#ffffff", belly="#cce8f8", eye="#ffffff"),
    hp=370, dmg=18, spd=0.20, arm=14, kb=1.0, det=30, ride=0.9, foods=["nieve", "hielo"], fx="freeze", abil="Puños gélidos: congelan",
    modes=("surface",), biomes=B_SNOW, w=2, step=1.0, desc="Gigante formado por hielo y estructuras congeladas.", biome="Biomas nevados (muy raro)")

# ---------------------------------------------------------------- 48 Rey de los Muertos
def dead_king(m=None, pal=None):
    m = m or Model()
    biped(m, tw=9, th=11, td=5, lh=11, lw=3, aw=3, ah=12, head_s=(7, 7, 7), mat="bone", pat="bone", fist=False, armpat="bone")
    top = 22
    m.pair("pauldron", "body", (6, top - 2, 0), (5, 4, 6), mat="accent", pat="plate")
    m.add("breast", "body", (0, 12, 2.6), (9, 9, 1), mat="accent", pat="plate")
    for i in range(5):
        m.add("crown%d" % i, "head", (-4 + i * 2, top + 6, 0), (1, 3 + (i % 2), 1), mat="accent2")
    m.add("cape", "body", (0, 3, -3), (11, 20, 1), mat="accent", pat="membrane", role="tail", pivot=(0, 22, -2.6), rot=(0.06, 0, 0))
    m.add("sword", "arm_r", (-6, 0, 3), (1, 20, 2), mat="metal", pat="metal", rot=(0, 0, 0)) 
    saddle_ = None
    return m
reg(48, "rey_muertos", "Rey de los Muertos", "King of the Dead", "E", dead_king, 3.6, P(base="#e4e0cc", dark="#8a8470", light="#fffff0", accent="#2a3c8a", accent2="#e8c040", belly="#d4d0bc", eye="#40a0ff"),
    hp=250, dmg=16, spd=0.27, arm=10, kb=0.7, det=34, ride=1.2, foods=["hueso", "carne_podrida"], fx="wither", abil="Hoja espectral: marchita",
    modes=("surface", "cave"), time="night", w=2, step=1.0, desc="Jefe esquelético con armadura y poderes oscuros, rey de los no muertos.", biome="Cualquier bioma, de noche (muy raro)")

# ---------------------------------------------------------------- 49 Hidra Ancestral
def ancient_hydra(m=None, pal=None):
    m = m or Model()
    hydra(m, heads=5, bw=14, bh=11, bd=22, lh=8, lw=5, neck_n=5, neck_step=4, neck_w=4, head_s=(6, 5, 7), snout=(4, 3, 5), spread=5.2, spikes=True, tail_n=5, hornmat="accent")
    return m
reg(49, "hidra_ancestral", "Hidra Ancestral", "Ancient Hydra", "E", ancient_hydra, 4.6, P(base="#2a8a52", dark="#124a2a", light="#6ad28a", accent="#d2c84a", accent2="#e8e0a0", belly="#b8d09a", eye="#ff5a28"),
    hp=340, dmg=18, spd=0.26, arm=10, kb=0.8, det=34, ride=1.1, ovi=True, foods=["res", "baba"], fx="poison", abil="Cinco mordiscos venenosos simultáneos",
    modes=("surface",), biomes=B_SWAMP + ["jungle"], w=2, step=1.0, desc="Hidra gigantesca de múltiples cabezas, tan antigua como los pantanos.", biome="Pantanos y selvas (muy rara)")

# ---------------------------------------------------------------- 50 El Devorador de Mundos
def world_devourer(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=13, bh=12, bd=24, lh=10, lw=5, wings=((10, 3, 8), (20, 1, 17), (16, 1, 14)), wmats=("base", "accent", "accent"), mat="base", pat="vein",
           hornmat="accent", spinemat="accent2", neck_n=4, neck_step=4, neck_w=7, tail_n=8, tail_w=8, tail_step=5, head_s=(9, 8, 10), snout=(6, 5, 6), horn=(2, 7, 2), spines=9, spine_size=(2, 5, 3), hpat="vein")
    return m
reg(50, "devorador_mundos", "El Devorador de Mundos", "World Devourer", "E", world_devourer, 6.0, P(base="#1c1240", dark="#080418", light="#3a2a78", accent="#a040ff", accent2="#e090ff", belly="#2a1c58", eye="#ff50ff"),
    move="fly", hp=420, dmg=22, spd=0.30, arm=14, kb=1.0, det=44, fs=1.0, ride=1.2, ovi=True, foods=["perla", "coro"], fx="darkness", abil="Vacío devorador: oscurece y debilita",
    dims=("overworld", "nether"), modes=("air", "cave", "surface"), time="night", w=1, step=1.0, desc="Criatura final de dimensiones colosales, oscura y púrpura. Devora la luz a su paso.", biome="Cualquier lugar, de noche (rarísimo)")
