# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math
from s1 import serpent
def P(**k):
    return k

# ---------------------------------------------------------------- 21 Hidra de Tres Cabezas
def hydra3(m=None, pal=None):
    m = m or Model()
    hydra(m, heads=3, bw=10, bh=8, bd=16, lh=6, neck_n=4, spikes=False)
    return m
reg(21, "hidra_tres_cabezas", "Hidra de Tres Cabezas", "Three-Headed Hydra", "C", hydra3, 3.0, P(base="#3c9632", dark="#1c5a1c", light="#82d250", accent="#d2b43c", accent2="#e6dc8c", belly="#c8d28c", eye="#ffe632"),
    hp=110, dmg=11, spd=0.26, arm=4, kb=0.4, det=28, ride=1.2, ovi=True, foods=["res"], fx="poison", abil="Tres mordiscos venenosos a la vez",
    modes=("surface",), biomes=B_SWAMP + ["jungle"], w=4, desc="Criatura reptiliana con tres cabezas independientes que atacan por separado.", biome="Pantanos y selvas")

# ---------------------------------------------------------------- 22 Manticora
def manticore(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 9, 10, 18, 10
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="fur", foot=(5, 1, 3))
    top = lh + bh
    head(m, "body", "head", 0, top - 5, bd / 2.0 + 2, 8, 8, 7, snout=(5, 3, 3), jaw=True, fangs=True, ears=(2, 2, 1, 3.5, -1, "dark"), mat="light", pat="fur", pivot=(0, top - 1, bd / 2.0))
    m.add("mane", "body", (0, top - 6, bd / 2.0 - 1), (12, 12, 4), mat="accent2", pat="fur")
    wing(m, "body", "wing", 4, top - 1, 0, [(6, 2, 6), (11, 1, 12), (8, 1, 9)], ["accent", "accent", "accent2"], pat="membrane", fold=1.25)
    t = chain(m, "body", "tail", (0, top - 2, -bd / 2.0), 6, 3, 3, 3, axis="z", sign=-1, step=3, taper=0.92, steptaper=1.0, mat="dark", pat="chitin", role="tail", rot=(0.38, 0, 0), ph=0.4)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("sting", t[-1], (0, ey - 1, ez - 2), (2, 2, 4), mat="bone", pivot=(ex, ey, ez + 1))
    saddle(m, "body", top, 0, 7, 7)
    return m
reg(22, "manticora", "Manticora", "Manticore", "C", manticore, 2.4, P(base="#d8962c", dark="#8a4e14", light="#f3dca8", accent="#e8661e", accent2="#a8441a", belly="#e6bc70", eye="#ffe632"),
    move="fly", hp=96, dmg=11, spd=0.30, arm=3, kb=0.3, det=30, fs=0.8, ride=1.4, foods=["cordero"], fx="poison", abil="Aguijón de escorpión: veneno potente",
    modes=("surface", "air"), biomes=B_DESERT + ["savanna"], w=4, desc="Cuerpo de león, alas de murciélago y cola de escorpión.", biome="Desiertos, badlands y sabanas")

# ---------------------------------------------------------------- 23 Minotauro
def minotaur(m=None, pal=None):
    m = m or Model()
    biped(m, tw=12, th=12, td=7, lh=10, lw=5, aw=5, ah=13, head_s=(7, 7, 8), mat="base", pat="fur", fist=True, legmat="base")
    m.parts = [p for p in m.parts if p["name"] != "head"]; m.names.discard("head")
    top = 22
    head(m, "body", "head", 0, top - 2, 2, 7, 7, 7, snout=(5, 4, 3), jaw=True, mat="base", pat="fur", pivot=(0, top + 1, 0), ears=(3, 2, 1, 4, -1, "dark"))
    m.add("ring", "head_sn", (0, top - 3, 2 + 3.5 + 3 + 1), (2, 2, 1), mat="metal")
    horns(m, "head", "horn", 3.5, top + 4, 2, 2, 4, 2, tilt=(0, 0, -0.5), mat="bone", segs=2, curl=0.9)
    m.add("belt", "body", (0, 10, 0), (13, 3, 8), mat="leather", pat="leather")
    m.add("axe", "arm_r", (-8, 2, 0), (2, 14, 2), mat="dark", pat="") if False else None
    return m
reg(23, "minotauro", "Minotauro", "Minotaur", "C", minotaur, 3.0, P(base="#8a5028", dark="#52301a", light="#b87848", accent="#e6dcc0", accent2="#6a4a30", belly="#c89868", eye="#ff6a28"),
    hp=130, dmg=14, spd=0.28, arm=5, kb=0.5, det=28, ride=1.2, foods=["trigo"], fx="stomp", abil="Embestida astada: aturde a los cercanos",
    modes=("surface", "cave"), biomes=B_DESERT + B_PLAINS + B_MOUNT, w=5, step=1.0, desc="Monstruo humanoide musculoso con cabeza de toro.", biome="Badlands, llanuras y montañas")

# ---------------------------------------------------------------- 24 Escorpión Colosal
def scorpion(m=None, pal=None, big=False):
    m = m or Model()
    spider(m, bw=9, bh=4, bd=12, lh=5, abd=(8, 4, 10), up=7, low=6, leg_t=2, mat="base", pat="chitin", abmat="base", leg_mat="dark", fangs=False, rot_up=0.35)
    top = 9
    for s_, nm in ((1, "l"), (-1, "r")):
        a = chain(m, "body", "claw%s_" % nm, (s_ * 4.5, 8, 6), 2, 2, 3, 2, axis="z", sign=1, step=5, taper=1.0, steptaper=1.0, mat="dark", pat="chitin", role="spleg",
                  rot=(0, -s_ * 0.2, 0), ph=0.6)
        ex, ey, ez = tip(m, a[-1], "z", 1)
        m.add("pin%s_a" % nm, a[-1], (ex - s_ * 1.5 * 0 + s_ * 1, ey - 1.5, ez + 2), (3, 3, 4), mat="accent", pat="chitin", role="pincer", pivot=(ex, ey, ez))
        m.add("pin%s_b" % nm, a[-1], (ex - s_ * 2, ey - 1.5, ez + 2), (2, 2, 4), mat="accent", pat="chitin", role="pincer", pivot=(ex, ey, ez))
    t = chain(m, "abdomen", "tail", (0, 8, -13), 6, 3, 3, 3, axis="z", sign=-1, step=3, taper=0.9, steptaper=1.0, mat="base", pat="chitin", role="tail", rot=(0.42, 0, 0), ph=0.3)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("sting", t[-1], (0, ey - 1.5, ez - 2), (2, 3, 4), mat="bone", pivot=(ex, ey, ez + 1))
    return m
reg(24, "escorpion_colosal", "Escorpión Colosal", "Colossal Scorpion", "C", scorpion, 2.2, P(base="#7a2a1e", dark="#3a1410", light="#b8482c", accent="#d2602a", accent2="#e8d080", belly="#5a2018", eye="#ff3020"),
    hp=70, dmg=10, spd=0.30, arm=6, kb=0.2, det=26, ride=1.5, ovi=True, foods=["conejo"], fx="poison", abil="Aguijón venenoso",
    modes=("surface",), biomes=B_DESERT, w=8, desc="Escorpión gigante con enormes pinzas y un aguijón venenoso.", biome="Desiertos y badlands")

# ---------------------------------------------------------------- 25 Gólem de Magma
def magma_golem(m=None, pal=None):
    m = m or Model()
    biped(m, tw=14, th=14, td=9, lh=9, lw=6, aw=6, ah=14, head_s=(8, 7, 7), mat="base", pat="crack", fist=True)
    m.add("core", "body", (0, 15, 4.6), (6, 6, 1), mat="accent", pat="glow")
    m.pair("shoulder", "body", (7, 21, 0), (6, 5, 8), mat="dark", pat="stone")
    m.pair("lavaeye", "head", (2, 24, 5), (2, 1, 1), mat="eye") if False else None
    return m
reg(25, "golem_magma", "Gólem de Magma", "Magma Golem", "C", magma_golem, 3.2, P(base="#4a3228", dark="#241410", light="#6e4a3a", accent="#ff8a1e", accent2="#ffd23c", belly="#3a2620", eye="#ffd23c"),
    hp=170, dmg=15, spd=0.22, arm=10, kb=0.9, det=22, ride=1.0, foods=["crema_magma"], fx="fire", abil="Puños de lava: prende fuego",
    dims=("overworld", "nether"), modes=("cave",), w=6, step=1.0, desc="Gólem de roca volcánica atravesado por grietas de lava ardiente.", biome="Cuevas profundas y Nether")

# ---------------------------------------------------------------- 26 Gusano Titánico
def titan_worm(m=None, pal=None):
    m = m or Model()
    names = serpent(m, n=7, w0=14, h0=12, step=7, ampx=0.0, y0=0, mat="base", pat="plate", taper=0.9, ph=0.5)
    m.add("belly", "seg0", (0, 0, -3), (10, 3, 6), mat="belly", pat="") if False else None
    nk = chain(m, "seg0", "neck", (0, 6, 0), 3, 11, 11, 11, axis="y", sign=1, step=6, taper=0.95, steptaper=1.0, mat="base", pat="plate", role="neck", rot=(0.22, 0, 0), ph=0.5)
    tx, ty, tz = tip(m, nk[-1], "y", 1)
    head(m, nk[-1], "head", 0, ty - 4, tz + 3, 11, 9, 9, snout=(9, 5, 5), jaw=True, fangs=True, mat="base", pat="plate", pivot=(0, ty, tz))
    for i in range(5):
        m.add("ring%d" % i, "seg%d" % i, (0, 12 - 0 if False else 13, -3), (8, 2, 2), mat="accent", pat="plate")
    m.pair("hornw", "head", (4.5, ty + 5, tz + 3), (2, 4, 2), rot=(-0.3, 0, 0.3), mat="accent")
    saddle(m, "seg1", 12, -3, 8, 8)
    return m
reg(26, "gusano_titanico", "Gusano Titánico", "Titanic Worm", "C", titan_worm, 3.0, P(base="#b0502e", dark="#6a2814", light="#e07844", accent="#e8c864", accent2="#f0e0a0", belly="#d8a070", eye="#ffe030"),
    hp=140, dmg=13, spd=0.22, arm=8, kb=0.7, det=24, ride=1.1, ovi=True, foods=["carne_podrida"], fx="stomp", abil="Coletazo sísmico",
    modes=("surface", "cave"), biomes=B_DESERT + B_PLAINS, w=4, step=1.0, desc="Gusano monstruoso gigantesco recubierto de placas acorazadas.", biome="Desiertos, badlands y llanuras")

# ---------------------------------------------------------------- 27 Ciempiés Gigante
def giant_centipede(m=None, pal=None):
    m = m or Model()
    centipede(m, n=13, w=8, h=5, d=4, mat="base", mat2="dark", legl=5, y=3)
    return m
reg(27, "ciempies_gigante", "Ciempiés Gigante", "Giant Centipede", "C", giant_centipede, 1.1, P(base="#d8821e", dark="#2a1c14", light="#f0a840", accent="#f0c850", accent2="#ffe080", belly="#a85a14", eye="#ff3020"),
    hp=60, dmg=8, spd=0.34, arm=3, kb=0.0, det=26, ride=1.6, ovi=True, foods=["ojo_arana"], fx="poison", abil="Mandíbulas venenosas",
    modes=("cave", "surface"), biomes=B_FOREST + B_SWAMP, w=8, desc="Artrópodo enorme de numerosas patas y segmentos acorazados.", biome="Selvas, pantanos y cuevas")

# ---------------------------------------------------------------- 28 Jabalí Acorazado
def armored_boar(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 7, 10, 18, 11
    quad_base(m, bw, bh, bd, lh, 4, mat="base", pat="fur", foot=(4, 1, 3))
    top = lh + bh
    for i in range(3):
        m.add("plate%d" % i, "body", (0, top, 5 - i * 5), (9, 3, 4), mat="accent", pat="plate")
    m.pair("sideplate", "body", (5.8, lh + 3, 0), (1, 6, 12), mat="accent", pat="plate")
    head(m, "body", "head", 0, top - 7, bd / 2.0 + 3, 8, 7, 7, snout=(5, 4, 5), jaw=True, mat="base", pat="fur", pivot=(0, top - 2, bd / 2.0), ears=(2, 3, 1, 3, -1, "dark"))
    m.pair("tusk", "head_sn", (2.5, top - 9, bd / 2.0 + 3 + 8), (1, 4, 1), rot=(0.3, 0, 0), mat="bone")
    m.add("helm", "head", (0, top, bd / 2.0 + 3), (7, 2, 5), mat="accent", pat="plate")
    for i in range(4):
        m.add("bristle%d" % i, "body", (0, top + 3, 6 - i * 4), (1, 3, 1), mat="dark")
    m.add("tail", "body", (0, top - 3, -bd / 2.0 - 2), (2, 4, 2), role="tail", mat="base", pivot=(0, top - 1, -bd / 2.0), rot=(0.4, 0, 0))
    saddle(m, "body", top + 3, 0, 7, 8)
    return m
reg(28, "jabali_acorazado", "Jabalí Acorazado", "Armored Boar", "C", armored_boar, 2.0, P(base="#a86a32", dark="#603a1a", light="#d29a58", accent="#c4c6cc", accent2="#5a4a3a", belly="#d8b078", eye="#ff5a28"),
    hp=90, dmg=10, spd=0.30, arm=8, kb=0.5, det=24, ride=1.6, foods=["zanahoria"], fx="knock", abil="Embestida acorazada",
    modes=("surface",), biomes=B_FOREST + B_PLAINS + B_DESERT, w=9, desc="Jabalí gigante protegido por placas metálicas.", biome="Bosques, llanuras y badlands")

# ---------------------------------------------------------------- 29 Gárgola Viviente
def gargoyle(m=None, pal=None):
    m = m or Model()
    biped(m, tw=9, th=9, td=6, lh=7, lw=4, aw=3, ah=9, head_s=(7, 7, 6), mat="base", pat="stone", fist=True)
    m.parts = [p for p in m.parts if p["name"] != "head"]; m.names.discard("head")
    top = 16
    head(m, "body", "head", 0, top - 1, 1, 7, 7, 6, snout=(4, 3, 2), jaw=True, fangs=True, mat="base", pat="stone", pivot=(0, top + 1, 0), ears=(2, 3, 1, 3, 0, "dark"))
    horns(m, "head", "horn", 2.5, top + 6, 1, 1, 4, 1, tilt=(-0.5, 0, 0.3), mat="dark", segs=2, curl=0.3)
    wing(m, "body", "wing", 4, top - 2, -1, [(5, 2, 6), (11, 1, 12), (8, 1, 10)], ["base", "light", "light"], pat="stone", fold=1.25)
    chain(m, "body", "tail", (0, 9, -3), 4, 2, 2, 2, axis="z", sign=-1, step=3, taper=0.9, steptaper=1.0, mat="base", pat="stone", role="tail", rot=(0.15, 0, 0))
    return m
reg(29, "gargola_viviente", "Gárgola Viviente", "Living Gargoyle", "C", gargoyle, 2.2, P(base="#8e9298", dark="#52565c", light="#c4c8ce", accent="#6a6e74", accent2="#d8dce2", belly="#7a7e84", eye="#ff4020"),
    move="fly", hp=86, dmg=10, spd=0.26, arm=8, kb=0.6, det=28, fs=0.7, ride=1.3, ovi=True, foods=["piedra", "amatista"], fx="slow", abil="Piel de piedra: casi inmune a golpes",
    modes=("air", "surface"), biomes=B_MOUNT + B_PLAINS + ANY[:0], w=4, desc="Criatura de piedra con alas y aspecto de estatua que cobra vida.", biome="Montañas y cumbres")

# ---------------------------------------------------------------- 30 Devorador de Huesos
def bone_devourer(m=None, pal=None):
    m = m or Model()
    lh, bh, bd, bw = 10, 8, 20, 8
    quad_base(m, bw, bh, bd, lh, 3, mat="base", pat="bone", foot=(4, 1, 3), lx=3)
    top = lh + bh
    for i in range(6):
        m.pair("rib%d" % i, "body", (4.5, lh + 1, 8 - i * 3.2), (1, 6, 2), mat="base", pat="bone", rot=(0, 0, -0.2))
        m.add("vert%d" % i, "body", (0, top, 8 - i * 3.2), (2, 2, 2), mat="dark", pat="bone")
    head(m, "body", "head", 0, top - 6, bd / 2.0 + 3, 7, 7, 7, snout=(5, 3, 5), jaw=True, fangs=True, mat="base", pat="bone", pivot=(0, top - 2, bd / 2.0), ears=(2, 3, 1, 3, 0, "dark"))
    chain(m, "body", "tail", (0, top - 3, -bd / 2.0), 6, 2, 2, 2, axis="z", sign=-1, step=3, taper=0.9, steptaper=1.0, mat="base", pat="bone", role="tail", rot=(0.1, 0, 0), ph=0.5)
    saddle(m, "body", top, 0, 5, 8)
    return m
reg(30, "devorador_huesos", "Devorador de Huesos", "Bone Devourer", "C", bone_devourer, 2.0, P(base="#e4e2d4", dark="#948f7c", light="#fffff0", accent="#3a3830", accent2="#c8c4b0", belly="#d6d2c0", eye="#ff3030"),
    hp=80, dmg=11, spd=0.31, arm=3, kb=0.2, det=28, ride=1.5, foods=["hueso"], fx="weak", abil="Mordisco óseo: debilita",
    dims=("overworld", "nether"), modes=("cave", "surface"), time="night", w=6, desc="Monstruo formado por placas y estructuras óseas.", biome="Cuevas, Nether (valle de almas) y noches")
