# -*- coding: utf-8 -*-
"""Genera todos los recursos de Bestiario Legendario: especies (JSON), texturas PNG, idiomas, receta e ítem.
Uso: python3 tools/gen_assets.py   (desde la raíz del proyecto)"""
import sys, os, json, math, copy, importlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from PIL import Image, ImageDraw
from mb import Model, export, bounds, pack
from paint import *
import reg
for n in ("s1", "s2", "s3", "s4", "s5", "s6"):
    importlib.import_module(n)

ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, "src", "main", "resources")
TEX = os.path.join(RES, "assets", "bestiario", "textures", "entity")
VNAMES_ES = ["Normal", "Albina", "Melánica", "Dorada", "Cristalina", "Carmesí"]

def babify(m):
    b = Model()
    k = 0.55
    heads = set()
    byname = {p["name"]: p for p in m.parts}
    for p in m.parts:
        if p["role"] == "head" or (p["parent"] in heads):
            heads.add(p["name"])
    for p in m.parts:
        if p["role"] == "saddle":
            continue
        q = copy.deepcopy(p)
        f = 1.3 if p["name"] in heads else 1.0
        q["c"] = tuple(v * k for v in p["c"])
        q["pivot"] = tuple(v * k for v in p["pivot"])
        q["s"] = tuple(max(1, int(round(v * k * f))) for v in p["s"])
        b.parts.append(q)
        b.names.add(q["name"])
    return b

def sit_drop(parts):
    hs = [p["sz"][1] for p in parts if p["role"] == "leg"]
    return round(0.5 * max(hs), 2) if hs else 0.0

def pick_size(a_parts, b_parts):
    wa, ha, _ = pack(a_parts)
    wb, hb, _ = pack(b_parts)
    W, H = max(wa, wb), max(ha, hb)
    sizes = [(W, H)]
    return pack(a_parts, sizes), pack(b_parts, sizes), W, H

def png(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, optimize=True)

def main():
    out = []
    egg_model = Model()
    egg_model.add("egg0", None, (0, 0, 0), (6, 2, 6), mat="base", pat="spot", role="body")
    egg_model.add("egg1", "egg0", (0, 2, 0), (8, 5, 8), mat="base", pat="spot")
    egg_model.add("egg2", "egg1", (0, 7, 0), (6, 3, 6), mat="base", pat="spot")
    egg_parts = export(egg_model)
    egg_w, egg_h, egg_pos = pack(egg_parts, [(64, 32)])
    for i, p in enumerate(egg_parts):
        p["uv"] = list(egg_pos[i])
    lang_es, lang_en = {}, {}
    for r in sorted(reg.REG, key=lambda x: x["num"]):
        m = r["build"]()
        bm = babify(m)
        ap, bp = export(m), export(bm)
        res = pick_size(ap, bp)
        (aw_, ah_, apos), (bw2, bh2, bpos), W, H = res
        for i, p in enumerate(ap):
            p["uv"] = list(apos[i])
        for i, p in enumerate(bp):
            p["uv"] = list(bpos[i])
        x0, x1, y0, y1, z0, z1 = bounds(m)
        sc = r["h"] * 16.0 / max(1.0, y1)
        hw = max(0.6, min(5.0, max((x1 - x0) * 0.8, (z1 - z0) * 0.4) * sc / 16.0))
        hh = r["h"]
        sad = [p for p in m.parts if p["name"] == "saddle"]
        seat = round((sad[0]["c"][1] + 2.5) * sc / 16.0, 3) if sad else round(hh * 0.8, 3)
        pal = make_palette(r["pal"])
        for v, vn in enumerate(VARIANTS):
            png(render_texture(ap, pal, v, W, H, apos, 1000 + r["num"]), os.path.join(TEX, r["id"], "%s.png" % vn))
            png(render_texture(bp, pal, v, W, H, bpos, 2000 + r["num"]), os.path.join(TEX, r["id"], "baby_%s.png" % vn))
        # huevo
        ep = {k: v for k, v in pal.items()}
        epal = dict(pal)
        epal["base"] = lerp(pal["light"], (255, 255, 255), 0.35)
        epal["accent"] = pal["base"]
        epal["dark"] = mul(pal["base"], 0.7)
        epal["light"] = (255, 255, 255)
        png(render_texture(egg_parts, epal, 0, egg_w, egg_h, egg_pos, 7 + r["num"]), os.path.join(TEX, "egg", r["id"] + ".png"))
        sp = {k: r[k] for k in ("num", "id", "es", "en", "grp", "move", "hp", "dmg", "spd", "arm", "kb", "det", "fs", "ride", "ovi", "foods",
                                "fx", "abil", "dims", "modes", "biomes", "time", "w", "grp_size", "desc", "biome", "step", "spawn", "swim")}
        sp["hybrid"] = list(r["hybrid"]) if r["hybrid"] else []
        sp.update(dict(h=hh, sc=round(sc, 4), hw=round(hw, 3), seat=seat, sit=sit_drop(ap), tw=W, th=H,
                       foodnames=[reg.FOODNAME[f] for f in r["foods"]], foodids=[reg.FOOD[f] for f in r["foods"]],
                       adult=ap, baby=bp))
        out.append(sp)
        lang_es["entity.bestiario." + r["id"]] = r["es"]
        lang_en["entity.bestiario." + r["id"]] = r["en"]
        print("%2d %-22s partes=%3d tex=%dx%d sc=%.2f hit=%.2fx%.2f seat=%.2f" % (r["num"], r["id"], len(ap), W, H, sc, hw, hh, seat))
    os.makedirs(RES, exist_ok=True)
    data = dict(variants=VARIANTS, egg=egg_parts, egg_tex=[egg_w, egg_h], species=out)
    with open(os.path.join(RES, "bestiario_species.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    lang_es["entity.bestiario.huevo"] = "Huevo de criatura"
    lang_en["entity.bestiario.huevo"] = "Creature Egg"
    lang_es["item.bestiario.bestiario"] = "Bestiario Legendario"
    lang_en["item.bestiario.bestiario"] = "Legendary Bestiary"
    for d, name in ((lang_es, "es_es"), (lang_en, "en_us")):
        p = os.path.join(RES, "assets", "bestiario", "lang", name + ".json")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    # ítem bestiario
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = img.load()
    for y in range(1, 15):
        for x in range(2, 14):
            c = (96, 24, 28) if x > 2 else (60, 14, 18)
            if y in (1, 14) or x in (2, 13):
                c = (50, 10, 14)
            px[x, y] = c + (255,)
    for y in range(3, 13):
        for x in range(4, 12):
            if (x in (4, 11) or y in (3, 12)):
                px[x, y] = (214, 170, 60, 255)
    for (x, y) in ((7, 6), (8, 6), (6, 7), (9, 7), (7, 8), (8, 8), (6, 9), (9, 9)):
        px[x, y] = (255, 220, 100, 255)
    png(img, os.path.join(RES, "assets", "bestiario", "textures", "item", "bestiario.png"))
    for sub, content in (("items/bestiario.json", {"model": {"type": "minecraft:model", "model": "bestiario:item/bestiario"}}),
                         ("models/item/bestiario.json", {"parent": "minecraft:item/generated", "textures": {"layer0": "bestiario:item/bestiario"}})):
        p = os.path.join(RES, "assets", "bestiario", sub)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump(content, open(p, "w"), indent=2)
    rp = os.path.join(RES, "data", "bestiario", "recipe", "bestiario.json")
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    json.dump({"type": "minecraft:crafting_shapeless", "category": "misc", "ingredients": ["minecraft:book", "minecraft:emerald"],
               "result": {"id": "bestiario:bestiario", "count": 1}}, open(rp, "w"), indent=2)
    print("TOTAL especies:", len(out))

if __name__ == "__main__":
    main()
