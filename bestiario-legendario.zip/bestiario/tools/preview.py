# -*- coding: utf-8 -*-
import math
from PIL import Image, ImageDraw
import numpy as np
from mb import export

def rotzyx(rx, ry, rz):
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx

def world_boxes(parts):
    by = {}
    out = []
    for p in parts:
        R = rotzyx(*p["rot"])
        off = np.array(p["off"], float)
        if p["p"]:
            pw, pR = by[p["p"]]
            o = pw + pR @ off
            Rw = pR @ R
        else:
            o = off
            Rw = R
        by[p["n"]] = (o, Rw)
        mn = np.array(p["mn"], float)
        sz = np.array(p["sz"], float)
        corners = []
        for dx in (0, 1):
            for dy in (0, 1):
                for dz in (0, 1):
                    corners.append(o + Rw @ (mn + sz * np.array([dx, dy, dz])))
        out.append((p, np.array(corners)))
    return out

def hull(pts):
    pts = sorted(set(map(tuple, pts)))
    if len(pts) <= 2:
        return pts
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]

def draw_view(parts, pal, view="side", size=(300, 200), pad=8):
    wb = world_boxes(parts)
    allp = np.concatenate([c for _, c in wb])
    if view == "side":
        sx = -allp[:, 2]; sy = allp[:, 1]
    else:
        sx = allp[:, 0]; sy = allp[:, 1]
    minx, maxx, miny, maxy = sx.min(), sx.max(), sy.min(), sy.max()
    sc = min((size[0] - 2 * pad) / max(1, maxx - minx), (size[1] - 2 * pad) / max(1, maxy - miny))
    img = Image.new("RGB", size, (86, 142, 200))
    dr = ImageDraw.Draw(img)
    dr.rectangle([0, size[1] - 14, size[0], size[1]], fill=(70, 120, 60))
    def proj(c):
        if view == "side":
            x = -c[2]; y = c[1]
        else:
            x = c[0]; y = c[1]
        return ((x - minx) * sc + pad, (y - miny) * sc + pad)
    order = sorted(wb, key=lambda t: (t[1][:, 0].mean() if view == "side" else -t[1][:, 2].mean()))
    for p, c in order:
        if p['role'] == 'saddle':
            continue
        col = pal.get(p["mat"], pal["base"])
        col = tuple(col)
        pts = hull([proj(v) for v in c])
        if len(pts) >= 3:
            dr.polygon(pts, fill=col, outline=tuple(int(v * 0.5) for v in col))
    return img
