# -*- coding: utf-8 -*-
import math
from mb import *

def quad_base(m, bw, bh, bd, lh, lw, mat="base", pat="fur", lpat=None, foot=None, lx=None, zf=None, zb=None,
              lmat=None, ld=None):
    lx = lx if lx is not None else bw / 2.0 - lw / 2.0
    zf = zf if zf is not None else bd / 2.0 - lw / 2.0
    zb = zb if zb is not None else -(bd / 2.0 - lw / 2.0)
    m.add("body", None, (0, lh, 0), (bw, bh, bd), role="body", mat=mat, pat=pat)
    legs(m, "body", quad_spots(lx, zf, zb), lw, ld or lw, lh, mat=lmat or mat, pat=lpat or pat, foot=foot)

def dragon(m, bw=9, bh=8, bd=16, lh=7, lw=3, wings=((7, 2, 5), (10, 1, 10), (8, 1, 8)), wmats=("base", "accent", "accent"),
           wpat="membrane", neck_n=3, neck_w=4, neck_step=4, neck_rot=0.16, head_s=(6, 5, 7), snout=(4, 3, 4),
           horn=(1, 5, 1), tail_n=5, tail_w=5, tail_step=4, mat="base", pat="scale", hornmat="accent2", spines=5,
           spinemat="accent2", legs=4, foot=True, fold=1.25, jawfangs=True, wing_y=None, tailpat=None, hpat=None,
           frill=True, lpat=None, spine_size=(2, 3, 2), tail_end=True):
    quad_base(m, bw, bh, bd, lh, lw, mat=mat, pat=pat, foot=(lw + 1, 1, lw + 1) if foot else None, lpat=lpat)
    if legs == 2:
        # wyvern: sólo patas traseras; quitar delanteras
        m.parts = [p for p in m.parts if not (p["name"] in ("leg0", "leg1", "leg0_f", "leg1_f"))]
        m.names -= {"leg0", "leg1", "leg0_f", "leg1_f"}
    top = lh + bh
    neck = chain(m, "body", "neck", (0, top - 1, bd / 2.0 - 1), neck_n, neck_w, neck_w, neck_w, axis="y", sign=1,
                 step=neck_step, taper=0.93, steptaper=1.0, mat=mat, pat=pat, role="neck", rot=(neck_rot, 0, 0), ph=0.4)
    tx, ty, tz = tip(m, neck[-1], "y", 1)
    hw, hh, hd = head_s
    head(m, neck[-1], "head", 0, ty - hh * 0.45, tz + hd / 2.0 - 1, hw, hh, hd, snout=snout, jaw=True,
         fangs=jawfangs, mat=mat, pat=hpat or pat, pivot=(0, ty, tz))
    hy = ty - hh * 0.45 + hh
    if horn:
        horns(m, "head", "horn", hw / 2.0 - 0.5, hy, tz + hd / 2.0 - 2, horn[0], horn[1], horn[2], tilt=(-0.55, 0, 0.25),
              mat=hornmat, segs=2, curl=0.25)
    if frill:
        m.pair("frill", "head", (hw / 2.0 + 0.5, hy - hh * 0.8, tz + hd / 2.0 - 2), (1, 4, 3), rot=(0, 0, 0.6), mat="accent", pat="membrane")
    for i in range(spines):
        m.add("spine%d" % i, "body", (0, top, bd / 2.0 - 2 - i * (bd - 4) / max(1, spines)), spine_size, mat=spinemat, pat="")
    ta = chain(m, "body", "tail", (0, lh + bh * 0.55, -bd / 2.0), tail_n, tail_w, tail_w * 0.8, tail_w, axis="z", sign=-1,
               step=tail_step, taper=0.8, steptaper=0.95, mat=mat, pat=tailpat or pat, role="tail", rot=(0.06, 0, 0), ph=0.35)
    if tail_end:
        ex, ey, ez = tip(m, ta[-1], "z", -1)
        m.add("tailtip", ta[-1], (0, ey - 1.5, ez - 2), (2, 3, 4), mat=spinemat, pivot=(ex, ey, ez + 2))
    if wings:
        wing(m, "body", "wing", bw / 2.0 - 1, wing_y if wing_y is not None else top - 1, 1, list(wings), list(wmats), pat=wpat, fold=fold)
    saddle(m, "body", top, 0, max(4, bw - 2), 6)

def bird(m, bw=7, bh=7, bd=12, lh=6, lw=2, wings=((6, 2, 6), (10, 1, 11), (8, 1, 9)), wmats=("accent2", "accent2", "dark"),
         head_s=(5, 5, 5), beak=(2, 3, 4), mat="base", hmat="light", bmat="accent", tail=(7, 1, 8), tailmat="light",
         talon=True, hpat="feather", pat="feather", crest=0, fold=1.25, neck=False, legmat="accent", tailup=0.35, hooked=True,
         tail_n=1):
    m.add("body", None, (0, lh, 0), (bw, bh, bd), role="body", mat=mat, pat=pat)
    legs(m, "body", [(bw / 4.0 + 0.5, 0, 0, False), (-bw / 4.0 - 0.5, 0, 1, False)], lw, lw, lh, mat=legmat, pat="",
         foot=(lw + 2, 1, lw + 3) if talon else None, fmat=legmat)
    top = lh + bh
    if neck:
        m.add("neck", "body", (0, top - 2, bd / 2.0 - 2), (4, 5, 4), mat=hmat, pat=hpat, role="neck", pivot=(0, top - 2, bd / 2.0 - 2), rot=(0.4, 0, 0))
        parent = "neck"; hy = top + 2
    else:
        parent = "body"; hy = top - 2
    hw, hh, hd = head_s
    head(m, parent, "head", 0, hy, bd / 2.0 + 1, hw, hh, hd, snout=beak, jaw=True, mat=hmat, smat=bmat, pat=hpat,
         pivot=(0, hy + hh / 2.0, bd / 2.0 - 1))
    if hooked:
        m.add("beak_hook", "head_sn", (0, hy + hh * 0.12 - 1.5, bd / 2.0 + 1 + hd / 2.0 + beak[2] - 1), (max(1, beak[0] - 1), 2, 1), mat=bmat)
    for i in range(crest):
        m.add("crest%d" % i, "head", (0, hy + hh, bd / 2.0 + 1 - i * 1.5), (1, 3 - i % 2, 2), mat="accent2", rot=(-0.3, 0, 0))
    tw, th, td = tail
    prev = "body"
    t = chain(m, "body", "tail", (0, lh + bh * 0.6, -bd / 2.0), tail_n, tw, th, td, axis="z", sign=-1, step=td, taper=0.9,
              steptaper=1.0, mat=tailmat, pat="feather", role="tail", rot=(tailup, 0, 0), ph=0.3)
    if wings:
        wing(m, "body", "wing", bw / 2.0, top - 3, 0, list(wings), list(wmats), pat="feather", fold=fold)
    saddle(m, "body", top, -1, max(4, bw - 2), 5)

def spider(m, bw=8, bh=6, bd=9, lh=7, abd=(10, 8, 12), up=9, low=9, leg_t=2, mat="base", pat="chitin", abmat=None, abpat=None,
           hmat=None, fangmat="bone", leg_mat="dark", span=4.0, rot_up=0.5, fangs=True, eyes="face3"):
    low = lh + bh * 0.5 - up * math.sin(rot_up) * 0 + up * math.sin(rot_up) + 1
    m.add("body", None, (0, lh, 0), (bw, bh, bd), role="body", mat=mat, pat=pat)
    hd = max(4, bw - 2)
    head(m, "body", "head", 0, lh + 1, bd / 2.0 + hd / 2.0 - 1, hd, hd - 1, hd, mat=hmat or mat, pat=pat, face=eyes,
         pivot=(0, lh + 3, bd / 2.0 - 1))
    if fangs:
        m.pair("mandible", "head", (hd / 4.0 + 0.5, lh - 1, bd / 2.0 + hd - 1), (1, 3, 1), role="pincer", mat=fangmat)
    aw, ah, ad = abd
    m.add("abdomen", "body", (0, lh + 1, -bd / 2.0 - ad / 2.0 + 2), (aw, ah, ad), mat=abmat or mat, pat=abpat or pat, role="body")
    zs = [bd / 2.0 - 1.5, bd / 6.0, -bd / 6.0, -bd / 2.0 + 1.5]
    k = 0
    for i, z in enumerate(zs):
        yaw = (1 - i) * 0.35
        # pierna superior
        for side in (1, -1):
            sx = side * bw / 2.0
            nm = "legu%d%s" % (i, "l" if side == 1 else "r")
            m.add(nm, "body", (sx + side * up / 2.0, lh + bh * 0.5 - 1, z), (up, leg_t, leg_t), pivot=(sx, lh + bh * 0.5, z),
                  rot=(0, yaw * side, -side * rot_up), role="spleg", idx=i, ph=(i % 2) * math.pi + (0 if side == 1 else math.pi), mat=leg_mat, pat="")
            ex = sx + side * up
            m.add(nm.replace("legu", "legd"), nm, (ex, lh + bh * 0.5 - low + 1, z), (leg_t, low, leg_t), pivot=(ex, lh + bh * 0.5 + 1, z),
                  rot=(0, 0, side * 0.5), role="spleg", idx=i, ph=(i % 2) * math.pi + (0 if side == 1 else math.pi), mat=leg_mat, pat="")
    saddle(m, "body", lh + bh, 0, max(4, bw - 2), 5)

def biped(m, tw=10, th=12, td=6, lh=10, lw=4, aw=4, ah=12, head_s=(8, 8, 8), mat="base", pat="stone", hmat=None, hpat=None,
          legmat=None, armmat=None, fist=True, neck=0, arm_x=None, armpat=None):
    m.add("body", None, (0, lh, 0), (tw, th, td), role="body", mat=mat, pat=pat)
    legs(m, "body", [(tw / 4.0, 0, 0, True), (-tw / 4.0, 0, 1, True)], lw, lw + 1, lh, mat=legmat or mat, pat=pat, foot=(lw + 1, 2, lw + 2) if fist else None)
    ax = arm_x if arm_x is not None else tw / 2.0 + aw / 2.0
    m.add("arm_l", "body", (ax, lh + th - ah, 0), (aw, ah, aw), pivot=(ax, lh + th - 1, 0), role="arm", idx=1, mat=armmat or mat, pat=armpat or pat)
    m.add("arm_r", "body", (-ax, lh + th - ah, 0), (aw, ah, aw), pivot=(-ax, lh + th - 1, 0), role="arm", idx=0, mat=armmat or mat, pat=armpat or pat)
    if fist:
        m.add("fist_l", "arm_l", (ax, lh + th - ah - aw * 0.6, 0), (aw + 1, aw * 0.8, aw + 1), mat=armmat or mat, pat=pat)
        m.add("fist_r", "arm_r", (-ax, lh + th - ah - aw * 0.6, 0), (aw + 1, aw * 0.8, aw + 1), mat=armmat or mat, pat=pat)
    hw, hh, hd = head_s
    base = lh + th
    if neck:
        m.add("neck", "body", (0, base - 1, 0), (hw // 2, neck, hw // 2), mat=mat, pat=pat, role="neck")
        base += neck - 1
    head(m, "body", "head", 0, base - 1, 1, hw, hh, hd, mat=hmat or mat, pat=hpat or pat, pivot=(0, base + 1, 0))
    saddle(m, "body", lh + th, -1, max(4, tw - 2), max(3, td))

def fish(m, bw=8, bh=8, bd=14, y=2, n=4, head_s=(7, 7, 7), snout=(5, 4, 5), mat="base", pat="scale", fins=True, tailh=10,
         dorsal=5, belly="belly", pec=(6, 1, 4), taper=0.82, fangs=True, fluke=False, jaw=True):
    m.add("body", None, (0, y, 0), (bw, bh, bd), role="body", mat=mat, pat=pat)
    segs = chain(m, "body", "seg", (0, y + bh / 2.0, -bd / 2.0), n, bw * taper, bh * taper, bd, axis="z", sign=-1,
                 step=bd * 0.55, taper=taper, steptaper=0.95, mat=mat, pat=pat, role="seg", ph=0.5)
    ex, ey, ez = tip(m, segs[-1], "z", -1)
    if fluke:
        m.add("caudal", segs[-1], (0, ey - 0.5, ez - 2), (tailh, 1, 5), mat="dark", pat="membrane", role="fin", pivot=(0, ey, ez + 1), idx=n)
    else:
        m.add("caudal", segs[-1], (0, ey - tailh / 2.0, ez - 2), (1, tailh, 4), mat="dark", pat="membrane", role="fin",
              pivot=(0, ey, ez + 1), idx=n)
    hw, hh, hd = head_s
    head(m, "body", "head", 0, y + 0.5, bd / 2.0 + hd / 2.0 - 1, hw, hh, hd, snout=snout, jaw=jaw, fangs=fangs, mat=mat,
         pat=pat, pivot=(0, y + bh / 2.0, bd / 2.0 - 1), jawmat="belly")
    if fins:
        m.add("dorsal", "body", (0, y + bh, 0), (1, dorsal, 5), mat="dark", pat="membrane", rot=(0.25, 0, 0), role="fin", idx=1,
              pivot=(0, y + bh, 2))
        m.pair("pec", "body", (bw / 2.0 + pec[0] / 2.0 - 1, y + 1, bd / 4.0), pec, rot=(0, 0, 0.5), role="fin", idx=2, mat="dark",
               pat="membrane", pivot=(bw / 2.0 - 1, y + 2, bd / 4.0))
    saddle(m, "body", y + bh, 0, bw - 2, 5)

def soft_orb(m, name, parent, c, s, **kw):
    return m.add(name, parent, c, s, **kw)


def hydra(m, heads=3, bw=10, bh=8, bd=16, lh=6, lw=3, neck_n=4, neck_step=4, neck_w=3, head_s=(5, 4, 6), snout=(3, 3, 4),
          mat="base", pat="scale", tail_n=4, spread=4.5, spikes=False, hornmat="accent2", neckmat=None):
    quad_base(m, bw, bh, bd, lh, lw, mat=mat, pat=pat, foot=(lw + 1, 1, lw + 1))
    top = lh + bh
    c = (heads - 1) / 2.0
    for i in range(heads):
        x = (i - c) * spread
        tall = 1.0 + (0.3 if abs(i - c) < 0.1 else 0.0)
        names = chain(m, "body", "neck%d_" % i, (x * 0.7, top - 1, bd / 2.0 - 2), neck_n, neck_w, neck_w, neck_w, axis="y", sign=1,
                      step=neck_step * tall, taper=0.95, steptaper=1.0, mat=neckmat or mat, pat=pat, role="neck", rot=(0.1, 0, -(i - c) * 0.07), ph=0.5 + i)
        tx, ty, tz = tip(m, names[-1], "y", 1)
        hw, hh, hd = head_s
        head(m, names[-1], "head%d" % i, tx, ty - hh * 0.45, tz + hd / 2.0 - 1, hw, hh, hd, snout=snout, jaw=True, fangs=True, mat=mat, pat=pat,
             pivot=(tx, ty, tz), idx=i)
        if spikes:
            m.pair("hh%d" % i, "head%d" % i, (tx + hw / 2.0, ty - hh * 0.45 + hh, tz), (1, 3, 1), rot=(-0.4, 0, 0.3), mat=hornmat)
    for k in range(4 if spikes else 0):
        m.add("spn%d" % k, "body", (0, top, 5 - k * 4), (2, 3, 2), mat=hornmat)
    ta = chain(m, "body", "tail", (0, lh + bh * 0.5, -bd / 2.0), tail_n, 5, 4, 5, axis="z", sign=-1, step=4, taper=0.8, mat=mat, pat=pat, role="tail", rot=(0.05, 0, 0))
    saddle(m, "body", top, 0, max(4, bw - 2), 6)

def centipede(m, n=12, w=7, h=5, d=4, mat="base", pat="chitin", mat2="dark", legl=5, y=3, head_w=7):
    prev = None
    z = 0.0
    names = []
    for i in range(n):
        wi = w * (1.0 if i < n - 3 else 0.8 ** (i - n + 4))
        nm = "seg%d" % i
        m.add(nm, prev, (0, y, z - d / 2.0), (wi, h, d), pivot=(0, y + h / 2.0, z), role="seg", idx=i, mat=(mat if i % 2 == 0 else mat2), pat=pat, ph=0.6 * i)
        for s_ in (1, -1):
            m.add("leg%d%s" % (i, "l" if s_ == 1 else "r"), nm, (s_ * (wi / 2.0 + 1.5), 0, z - d / 2.0), (1, y + 1, 1), pivot=(s_ * (wi / 2.0), y + 1, z - d / 2.0),
                  rot=(0, 0, -s_ * 0.5), role="spleg", idx=i, ph=(i % 2) * math.pi + (0 if s_ == 1 else math.pi), mat="accent", pat="")
        names.append(nm)
        prev = nm
        z -= d
    head(m, "seg0", "head", 0, y - 1, 4, head_w, h + 1, 6, mat=mat2, pat=pat, face="face3", pivot=(0, y + 2, 1))
    m.pair("antenna", "head", (head_w / 2.0 - 1, y + h, 6), (1, 1, 6), rot=(0.2, 0.3, 0), mat="accent")
    m.pair("mandible", "head", (2, y - 1, 8), (1, 2, 3), role="pincer", mat="bone")
    saddle(m, "seg3", y + h, -d, 5, 5)
    return names

def octopus(m, mantle=(13, 13, 13), y=13, tent=8, tn=4, tw=3, tstep=5, mat="base", pat="scale", tmat=None, spread=5.5):
    mw, mh, md = mantle
    m.add("body", None, (0, y, 0), (mw, mh, md), role="body", mat=mat, pat=pat, flag="face")
    m.add("mantle", "body", (0, y + mh, -2), (mw - 3, 6, md - 3), mat=mat, pat=pat)
    m.add("crown", "mantle", (0, y + mh + 6, -3), (mw - 7, 3, md - 7), mat="light", pat=pat)
    for k in range(tent):
        a = k * 2 * math.pi / tent
        cx, cz = math.cos(a) * spread, math.sin(a) * spread
        chain(m, "body", "tent%d_" % k, (cx, y + 1, cz), tn, tw, tw, tw, axis="y", sign=-1, step=tstep, taper=0.82, steptaper=0.97,
              mat=tmat or mat, pat=pat, role="tentacle", rot=(-0.28 * math.sin(a), 0, -0.28 * math.cos(a)), ph=0.7 + k * 0.4)
    m.pair("eyeb", "body", (mw / 4.0, y + mh * 0.55, md / 2.0), (3, 3, 1), mat="eye")
    saddle(m, "mantle", y + mh + 6, -2, 8, 7)

def ray(m, bw=14, bh=3, bd=16, y=4, wings=((8, 1, 14), (9, 1, 10)), tail_n=6, mat="base", pat="membrane", wmat="base", tailmat="dark"):
    m.add("body", None, (0, y, 0), (bw, bh + 1, bd), role="body", mat=mat, pat=pat)
    m.add("bump", "body", (0, y + bh + 1, 3), (6, 3, 6), mat=mat, pat=pat)
    head(m, "body", "head", 0, y, bd / 2.0 + 2, 6, 4, 4, mat=mat, pat=pat, pivot=(0, y + 2, bd / 2.0))
    m.pair("hear", "head", (2, y + 4, bd / 2.0 + 2), (2, 4, 1), mat="dark", rot=(0, 0, 0.2))
    wing(m, "body", "wing", bw / 2.0, y + 1, 0, list(wings), [wmat, wmat], pat=pat, fold=0.0, droop=0.0)
    for p in m.parts:
        if p["role"] == "wing":
            p["rot"] = (0, 0, 0)
    chain(m, "body", "tail", (0, y + 2, -bd / 2.0), tail_n, 2, 2, 2, axis="z", sign=-1, step=4, taper=0.9, steptaper=1.0, mat=tailmat, pat="", role="tail", ph=0.5)
    saddle(m, "body", y + bh + 1, 0, 7, 6)
