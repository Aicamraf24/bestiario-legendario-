# -*- coding: utf-8 -*-
REG = []
FOOD = {
 "pollo": "minecraft:chicken", "cordero": "minecraft:mutton", "res": "minecraft:beef", "cerdo": "minecraft:porkchop",
 "conejo": "minecraft:rabbit", "salmon": "minecraft:salmon", "bacalao": "minecraft:cod", "miel": "minecraft:honey_bottle",
 "bayas": "minecraft:sweet_berries", "flores": "#minecraft:flowers", "hierba_marina": "minecraft:seagrass",
 "zanahoria": "minecraft:carrot", "manzana_dorada": "minecraft:golden_apple", "carne_podrida": "minecraft:rotten_flesh",
 "redstone": "minecraft:redstone", "lagrima": "minecraft:ghast_tear", "amatista": "minecraft:amethyst_shard",
 "ojo_arana": "minecraft:spider_eye", "trigo": "minecraft:wheat", "crema_magma": "minecraft:magma_cream",
 "piedra": "minecraft:stone", "hueso": "minecraft:bone", "tinta": "minecraft:ink_sac", "pez_tropical": "minecraft:tropical_fish",
 "semillas": "minecraft:wheat_seeds", "blaze": "minecraft:blaze_powder", "carbon": "minecraft:coal", "hierro": "minecraft:raw_iron",
 "cobre": "minecraft:copper_ingot", "tinta_luz": "minecraft:glow_ink_sac", "nieve": "minecraft:snowball", "hielo": "minecraft:packed_ice",
 "baba": "minecraft:slime_ball", "perla": "minecraft:ender_pearl", "coro": "minecraft:chorus_fruit",
}
FOODNAME = {
 "pollo": "carne de pollo cruda", "cordero": "carne de cordero cruda", "res": "carne de res cruda", "cerdo": "carne de cerdo cruda",
 "conejo": "carne de conejo cruda", "salmon": "salmón crudo", "bacalao": "bacalao crudo", "miel": "botella de miel",
 "bayas": "bayas dulces", "flores": "flores", "hierba_marina": "hierba marina", "zanahoria": "zanahorias",
 "manzana_dorada": "manzanas doradas", "carne_podrida": "carne podrida", "redstone": "polvo de redstone",
 "lagrima": "lágrima de ghast", "amatista": "fragmentos de amatista", "ojo_arana": "ojo de araña", "trigo": "trigo",
 "crema_magma": "crema de magma", "piedra": "piedra", "hueso": "huesos", "tinta": "saco de tinta", "pez_tropical": "pez tropical",
 "semillas": "semillas", "blaze": "polvo de blaze", "carbon": "carbón", "hierro": "hierro en bruto", "cobre": "lingotes de cobre",
 "tinta_luz": "saco de tinta luminosa", "nieve": "bolas de nieve", "hielo": "hielo compacto", "baba": "bola de baba",
 "perla": "perla de ender", "coro": "fruta de chorus",
}
B_FOREST = ["forest", "taiga", "jungle", "grove", "birch", "cherry", "bamboo"]
B_DARK = ["dark_forest", "swamp", "mangrove", "old_growth"]
B_SWAMP = ["swamp", "mangrove"]
B_SNOW = ["snowy", "frozen", "ice_spikes", "grove", "jagged"]
B_DESERT = ["desert", "badlands"]
B_MOUNT = ["peaks", "slopes", "windswept", "meadow", "hills", "stony", "grove"]
B_PLAINS = ["plains", "savanna", "meadow", "sunflower"]
B_OCEAN = ["ocean"]
B_DEEP = ["deep_"]
B_NETHER = ["nether", "crimson", "warped", "soul_sand", "basalt"]
ANY = ["*"]

def reg(num, id, es, en, grp, build, h, pal, move="ground", hp=40, dmg=6, spd=0.25, arm=0, kb=0.0, det=24, fs=0.0,
        ride=1.4, ovi=False, foods=(), fx="", abil="", dims=("overworld",), modes=("surface",), biomes=ANY, time="any",
        w=6, grp_size=(1, 1), desc="", biome="", step=0.0, hybrid=None, spawn=True, sit=None, swim=0.0):
    REG.append(dict(num=num, id=id, es=es, en=en, grp=grp, build=build, h=h, pal=pal, move=move, hp=hp, dmg=dmg, spd=spd,
                    arm=arm, kb=kb, det=det, fs=fs, ride=ride, ovi=ovi, foods=list(foods), fx=fx, abil=abil, dims=list(dims),
                    modes=list(modes), biomes=list(biomes), time=time, w=w, grp_size=grp_size, desc=desc, biome=biome,
                    step=step, hybrid=hybrid, spawn=spawn, sit=sit, swim=swim))
