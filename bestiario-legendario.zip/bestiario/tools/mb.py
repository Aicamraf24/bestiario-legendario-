# -*- coding: utf-8 -*-
"""Constructor de modelos cúbicos (estilo Minecraft) + empaquetado UV + exportación.
Coordenadas "naturales": x lateral (+ = izquierda del modelo), y altura sobre el suelo, z hacia delante.
Cada caja se define por centro x, base y, centro z y tamaño (w,h,d)."""
import math

ROLES_NO_HEIGHT = {"wing", "tail", "fin", "tentacle", "spleg", "saddle"}

class Model:
    def __init__(self):
        self.parts = []
        self.names = set()

    def add(self, name, parent, c, s, pivot=None, rot=(0, 0, 0), role="", idx=0, amp=1.0,
            mat="base", pat="", ph=0.0, flag="", rear=False):
        assert name not in self.names, "duplicado " + name
        self.names.add(name)
        x, y, z = c
        w, h, d = [max(1, int(round(v))) for v in s]
        if pivot is None:
            pivot = (x, y + h / 2.0, z)
        self.parts.append(dict(name=name, parent=parent, c=(x, y, z), s=(w, h, d), pivot=tuple(pivot),
                               rot=tuple(rot), role=role, idx=idx, amp=amp, mat=mat, pat=pat, ph=ph,
                               flag=flag, rear=rear))
        return name

    def pair(self, name, parent, c, s, pivot=None, rot=(0, 0, 0), **kw):
        """Crea name_l (x>0) y name_r (x<0) con rotaciones espejadas."""
        x, y, z = c
        if pivot is None:
            pivot = (x, y + s[1] / 2.0, z)
        px, py, pz = pivot
        self.add(name + "_l", parent, (abs(x), y, z), s, (abs(px), py, pz), rot, **kw)
        self.add(name + "_r", parent, (-abs(x), y, z), s, (-abs(px), py, pz), (rot[0], -rot[1], -rot[2]), **kw)
        return name

    def get(self, name):
        for p in self.parts:
            if p["name"] == name:
                return p
        raise KeyError(name)

# ---------------------------------------------------------------- primitivas
def legs(m, parent, spots, lw, ld, lh, mat="base", pat="", foot=None, amp=1.0, tag="leg", fmat="dark", joint=None):
    """spots: lista (x, z, idx, rear). Pivote en la parte alta de la pierna."""
    for i, (x, z, idx, rear) in enumerate(spots):
        n = "%s%d" % (tag, i)
        m.add(n, parent, (x, 0, z), (lw, lh, ld), pivot=(x, lh, z), role="leg", idx=idx, amp=amp, mat=mat, pat=pat, rear=rear)
        if foot:
            fw, fh, fd = foot
            m.add(n + "_f", n, (x, 0, z + (fd - ld) / 2.0), (fw, fh, fd), mat=fmat, pat="", role="")

def quad_spots(lx, zf, zb, ph=(0, 1, 1, 0)):
    return [(lx, zf, ph[0], False), (-lx, zf, ph[1], False), (lx, zb, ph[2], True), (-lx, zb, ph[3], True)]

def head(m, parent, nm, x, y, z, hw, hh, hd, snout=None, jaw=False, ears=None, mat="base", smat=None, pat="fur",
         pivot=None, idx=0, face="face", fangs=False, role="head", amp=1.0, jawmat=None):
    smat = smat or mat
    piv = pivot or (x, y + hh * 0.5, z - hd / 2.0)
    m.add(nm, parent, (x, y, z), (hw, hh, hd), pivot=piv, role=role, idx=idx, mat=mat, pat=pat, flag=face, amp=amp)
    if snout:
        sw, sh, sd = snout
        sy = y + hh * 0.12
        m.add(nm + "_sn", nm, (x, sy, z + hd / 2.0 + sd / 2.0), (sw, sh, sd), mat=smat, pat=pat if pat != "feather" else "")
        if jaw:
            jh = max(1, int(round(sh * 0.45)))
            jd = sd + hd * 0.45
            m.add(nm + "_jaw", nm, (x, sy - jh, z + hd / 2.0 + sd / 2.0 - hd * 0.225), (sw * 0.9, jh, jd),
                  pivot=(x, sy, z + hd / 2.0 - hd * 0.45), role="jaw", mat=jawmat or smat, pat="", flag="mouth")
            if fangs:
                m.add(nm + "_fu_l", nm + "_sn", (sw * 0.32, sy - 1, z + hd / 2.0 + sd - 1), (1, 1, 1), mat="bone")
                m.add(nm + "_fu_r", nm + "_sn", (-sw * 0.32, sy - 1, z + hd / 2.0 + sd - 1), (1, 1, 1), mat="bone")
                m.add(nm + "_fl_l", nm + "_jaw", (sw * 0.32, sy, z + hd / 2.0 + sd - 1), (1, 1, 1), mat="bone")
                m.add(nm + "_fl_r", nm + "_jaw", (-sw * 0.32, sy, z + hd / 2.0 + sd - 1), (1, 1, 1), mat="bone")
    if ears:
        ew, eh, ed, dx, dz = ears[:5]
        emat = ears[5] if len(ears) > 5 else "dark"
        er = ears[6] if len(ears) > 6 else (0, 0, 0)
        m.pair(nm + "_ear", nm, (dx, y + hh, z + dz), (ew, eh, ed), rot=er, mat=emat, pat="")
    return nm

def horns(m, parent, nm, x, ybase, z, w, h, d, tilt=(0.0, 0.0, 0.5), mat="accent", segs=2, curl=0.5, pat=""):
    """Cuernos pareados formados por segmentos que se curvan."""
    prev_l = prev_r = parent
    cx = x
    for i in range(segs):
        hh = max(1, int(round(h * (1.0 - 0.18 * i))))
        ww = max(1, int(round(w * (1.0 - 0.2 * i))))
        rot = (tilt[0], tilt[1], tilt[2] if i == 0 else curl)
        if i == 0:
            m.pair("%s%d" % (nm, i), parent, (cx, ybase, z), (ww, hh, d), pivot=(cx, ybase, z), rot=rot, mat=mat, pat=pat)
        else:
            # hijo del anterior, pivote en la punta del anterior
            ph = m.get("%s%d_l" % (nm, i - 1))
            cxp, cyp, czp = ph["c"]
            top = cyp + ph["s"][1]
            m.add("%s%d_l" % (nm, i), "%s%d_l" % (nm, i - 1), (cxp, top, czp), (ww, hh, d), pivot=(cxp, top, czp), rot=(0, 0, curl), mat=mat, pat=pat)
            m.add("%s%d_r" % (nm, i), "%s%d_r" % (nm, i - 1), (-cxp, top, czp), (ww, hh, d), pivot=(-cxp, top, czp), rot=(0, 0, -curl), mat=mat, pat=pat)

def chain(m, parent, nm, start, n, w, h, d, axis="z", sign=-1, step=4, taper=0.88, steptaper=0.95, mat="base", pat="",
          role="tail", rot=(0, 0, 0), amp=1.0, ph=0.35, rot_last=None):
    """Cadena de segmentos (cola, cuello, cuerpo de serpiente, tentáculo).
    start = punto de unión (x,y,z). axis: 'z' (sign -1 hacia atrás, +1 hacia delante), 'y' (+1 arriba, -1 abajo), 'x'.
    Cada segmento pivota en su punto de inicio; rot se aplica a cada segmento."""
    x, y, z = start
    prev = parent
    cw, ch, cd, st = float(w), float(h), float(d), float(step)
    names = []
    for i in range(n):
        s = max(1, int(round(st)))
        sw, sh, sd = max(1, int(round(cw))), max(1, int(round(ch))), max(1, int(round(cd)))
        nme = "%s%d" % (nm, i)
        r = rot_last if (rot_last is not None and i == n - 1) else rot
        if axis == "z":
            m.add(nme, prev, (x, y - sh / 2.0, z + sign * s / 2.0), (sw, sh, s), pivot=(x, y, z), rot=r, role=role,
                  idx=i, amp=amp, mat=mat, pat=pat, ph=ph * i)
            z += sign * s
        elif axis == "y":
            m.add(nme, prev, (x, y if sign > 0 else y - s, z), (sw, s, sd), pivot=(x, y, z), rot=r, role=role,
                  idx=i, amp=amp, mat=mat, pat=pat, ph=ph * i)
            y += sign * s
        else:
            m.add(nme, prev, (x + sign * s / 2.0, y - sh / 2.0, z), (s, sh, sd), pivot=(x, y, z), rot=r, role=role,
                  idx=i, amp=amp, mat=mat, pat=pat, ph=ph * i)
            x += sign * s
        names.append(nme)
        prev = nme
        cw *= taper
        ch *= taper
        cd *= taper
        st *= steptaper
    return names

def saddle(m, parent, y, z, w, d, x=0):
    m.add("saddle", parent, (x, y, z), (w, 2, d), mat="leather", pat="leather", role="saddle")
    m.add("saddle_a", "saddle", (x, y + 2, z + d / 2.0 - 1), (max(2, w // 2), 1, 2), mat="leather", role="saddle")
    m.add("saddle_b", "saddle", (x, y + 2, z - d / 2.0 + 1), (max(2, w // 2), 1, 2), mat="leather", role="saddle")
    m.add("saddle_l", "saddle", (x + w / 2.0 + 0.5, y - 3, z), (1, 4, 2), mat="metal", role="saddle")
    m.add("saddle_r", "saddle", (x - w / 2.0 - 0.5, y - 3, z), (1, 4, 2), mat="metal", role="saddle")

def wing(m, parent, nm, x, y, z, segs, mats, pat="feather", fold=1.25, up=0.0, role="wing", droop=0.25):
    """Ala pareada de varios segmentos que crecen hacia +x. segs = [(largo, grosor, ancho)...]. Pivote en el hombro.
    En reposo se pliega hacia atrás (rotación Y) y cuelga un poco (rotación Z)."""
    cx = x
    for i, (L, T, W) in enumerate(segs):
        Li, Ti, Wi = int(round(L)), max(1, int(round(T))), int(round(W))
        mt = mats[min(i, len(mats) - 1)]
        if i == 0:
            ry, rz = -fold, droop
        elif i == 1:
            ry, rz = -0.9, 0.0
        else:
            ry, rz = 0.4, 0.0
        par_l = parent if i == 0 else "%s%d_l" % (nm, i - 1)
        par_r = parent if i == 0 else "%s%d_r" % (nm, i - 1)
        m.add("%s%d_l" % (nm, i), par_l, (cx + Li / 2.0, y, z), (Li, Ti, Wi), pivot=(cx, y + Ti / 2.0, z), rot=(0, ry, rz),
              role=role, idx=i, mat=mt, pat=pat)
        m.add("%s%d_r" % (nm, i), par_r, (-(cx + Li / 2.0), y, z), (Li, Ti, Wi), pivot=(-cx, y + Ti / 2.0, z), rot=(0, -ry, -rz),
              role=role, idx=i, mat=mt, pat=pat)
        cx += Li

# ---------------------------------------------------------------- exportación
def bounds(m, skip_roles=ROLES_NO_HEIGHT):
    xs, ys, zs = [], [], []
    for p in m.parts:
        if p["role"] in skip_roles:
            continue
        x, y, z = p["c"]
        w, h, d = p["s"]
        xs += [x - w / 2.0, x + w / 2.0]
        ys += [y, y + h]
        zs += [z - d / 2.0, z + d / 2.0]
    return min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)

def pack(parts, sizes=((64, 64), (128, 64), (128, 128), (256, 128), (256, 256), (512, 256))):
    rects = []
    for i, p in enumerate(parts):
        w, h, d = p.get("s") or p["sz"]
        rects.append((i, 2 * (d + w), d + h))
    order = sorted(rects, key=lambda r: (-r[2], -r[1]))
    for (W, H) in sizes:
        x = y = rowh = 0
        pos = {}
        ok = True
        for i, rw, rh in order:
            if rw > W:
                ok = False
                break
            if x + rw > W:
                x = 0
                y += rowh
                rowh = 0
            if y + rh > H:
                ok = False
                break
            pos[i] = (x, y)
            x += rw
            rowh = max(rowh, rh)
        if ok:
            return W, H, pos
    raise RuntimeError("no cabe en textura")

def export(m):
    """Devuelve lista de partes en coordenadas de modelo de Minecraft (y hacia abajo, suelo en y=24)."""
    byname = {p["name"]: p for p in m.parts}
    out = []
    for p in m.parts:
        px, py, pz = p["pivot"]
        mp = (px, 24.0 - py, -pz)
        if p["parent"]:
            q = byname[p["parent"]]
            qx, qy, qz = q["pivot"]
            qm = (qx, 24.0 - qy, -qz)
        else:
            qm = (0.0, 0.0, 0.0)
        off = (mp[0] - qm[0], mp[1] - qm[1], mp[2] - qm[2])
        cx, cy, cz = p["c"]
        w, h, d = p["s"]
        mn = ((cx - w / 2.0) - px, py - (cy + h), pz - cz - d / 2.0)
        side = 0 if abs(px) < 0.01 else (1 if px > 0 else -1)
        out.append(dict(n=p["name"], p=p["parent"] or "", off=[round(v, 3) for v in off], mn=[round(v, 3) for v in mn],
                        sz=[w, h, d], rot=[round(v, 4) for v in p["rot"]], role=p["role"], idx=p["idx"],
                        amp=p["amp"], side=side, ph=round(p["ph"], 3), rear=1 if p["rear"] else 0,
                        mat=p["mat"], pat=p["pat"], flag=p["flag"]))
    return out

def tip(m, nm, axis="z", sign=-1):
    """Punto final (x,y,z) de un segmento creado con chain()."""
    p = m.get(nm)
    px, py, pz = p["pivot"]
    w, h, d = p["s"]
    if axis == "z":
        return (px, py, pz + sign * d)
    if axis == "y":
        return (px, py + sign * h, pz)
    return (px + sign * w, py, pz)
