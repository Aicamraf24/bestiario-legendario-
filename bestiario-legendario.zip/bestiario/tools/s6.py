# -*- coding: utf-8 -*-
from reg import *
from arch import *
import math
from s1 import serpent, griffin, forest_dragon, crystal_deer, frost_wolf, shadow_fox, colossal_bear
from s2 import blood_spider
from s3 import scorpion, manticore
from s4 import megalodon, sea_leviathan, kraken, abyssal_serpent, sky_dragon, wyvern, ghost_ray, crystal_whale, phoenix
def P(**k):
    return k
BY = {}
def _by(i):
    if not BY:
        for r in REG:
            BY[r["id"]] = r
    return BY[i]

def hyb(num, id, es, en, pa, pb, build, h, pal, desc, biome, **kw):
    a, b = _by(pa), _by(pb)
    foods = []
    for k in a["foods"] + b["foods"]:
        if k not in foods:
            foods.append(k)
    move = "fly" if "fly" in (a["move"], b["move"]) else ("swim" if "swim" in (a["move"], b["move"]) else "ground")
    reg(num, id, es, en, "H", build, h, pal, move=move,
        hp=int((a["hp"] + b["hp"]) / 2 * 1.1), dmg=round((a["dmg"] + b["dmg"]) / 2 * 1.05, 1), spd=round((a["spd"] + b["spd"]) / 2, 3),
        arm=int((a["arm"] + b["arm"]) / 2), kb=round((a["kb"] + b["kb"]) / 2, 2), det=int((a["det"] + b["det"]) / 2),
        fs=round(max(a["fs"], b["fs"]), 2), ride=round((a["ride"] + b["ride"]) / 2, 2), ovi=(a["ovi"] and b["ovi"]), foods=foods,
        fx=a["fx"], abil=a["abil"] + " + " + b["abil"].split(":")[0].lower(), swim=max(a["swim"], b["swim"]), step=max(a["step"], b["step"]),
        desc=desc, biome=biome, hybrid=(pa, pb), spawn=False, modes=("surface",), **kw)

# 51 Esfinge Alada (Grifo Real x Manticora)
def sphinx(m=None, pal=None):
    m = griffin()
    for p in m.parts:
        if p["name"].startswith("wing"):
            p["mat"] = "accent" if p["name"][4] != "2" else "accent2"; p["pat"] = "membrane"
    t = chain(m, "body", "stail", (0, 15, -9), 5, 2, 2, 2, axis="z", sign=-1, step=3, taper=0.95, steptaper=1.0, mat="dark", pat="chitin", role="tail", rot=(0.36, 0, 0), ph=0.4)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("ssting", t[-1], (0, ey - 1, ez - 2), (2, 2, 4), mat="bone", pivot=(ex, ey, ez + 1))
    m.parts = [p for p in m.parts if not p["name"].startswith("tail") and p["name"] != "tuft"]
    m.names = {p["name"] for p in m.parts}
    return m
hyb(51, "esfinge_alada", "Esfinge Alada", "Winged Sphinx", "grifo_real", "manticora", sphinx, 2.3, P(base="#d49a38", dark="#7a4a1c", light="#f1e9d8", accent="#e8661e", accent2="#a8441a", belly="#e6bc70", eye="#ffd21a"),
    "Híbrido de grifo y manticora: cabeza de águila, cuerpo de león, alas membranosas y cola de escorpión.", "Solo por cría")

# 52 Draco Espinoso (Dragón de los Bosques x Wyvern)
def spiny_drake(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=9, bh=8, bd=15, lh=8, lw=3, legs=2, wings=((7, 2, 5), (13, 1, 12), (10, 1, 10)), wmats=("base", "accent", "accent2"), mat="base", pat="scale",
           hornmat="accent2", spinemat="accent2", spines=8, spine_size=(2, 4, 2), neck_n=3, neck_step=4, tail_n=6)
    for i in range(3):
        m.pair("leaf%d" % i, "body", (4.5, 16, 5 - i * 5), (3, 1, 3), mat="accent", pat="spot", rot=(0, 0, -0.5))
    return m
hyb(52, "draco_espinoso", "Draco Espinoso", "Thorn Drake", "dragon_bosques", "wyvern_veneno", spiny_drake, 3.0, P(base="#3e8a30", dark="#1e4a18", light="#8ad23c", accent="#8a3cd2", accent2="#d8ff3c", belly="#b8d070", eye="#d2ff3c"),
    "Híbrido de dragón del bosque y wyvern: alas moradas y espinas venenosas cubiertas de hojas.", "Solo por cría")

# 53 Dracofénix (Dragón Celeste x Fénix)
def dracophoenix(m=None, pal=None):
    m = m or Model()
    dragon(m, bw=8, bh=7, bd=15, lh=7, lw=3, wings=((8, 2, 6), (14, 1, 14), (11, 1, 11)), wmats=("accent", "accent2", "light"), mat="base", pat="scale",
           hornmat="accent2", spinemat="accent2", neck_n=4, neck_step=3, tail_n=6, tailpat="glow", wpat="glow")
    return m
hyb(53, "dracofenix", "Dracofénix", "Dracophoenix", "dragon_celeste", "fenix", dracophoenix, 3.2, P(base="#d85a2a", dark="#8a2a14", light="#ffd23c", accent="#ff9a1e", accent2="#fff08a", belly="#ffb43c", eye="#a6f0ff"),
    "Híbrido de dragón celeste y fénix: cuerpo escamoso ardiente y alas de llamas.", "Solo por cría")

# 54 Lobo del Ocaso (Lobo de Escarcha x Zorro de las Sombras)
def dusk_wolf(m=None, pal=None):
    m = frost_wolf()
    m.pair("bigear", "head", (3, 17, 9), (2, 5, 1), mat="accent")
    m.parts = [p for p in m.parts if not p["name"].startswith("tail")]
    m.names = {p["name"] for p in m.parts}
    t = chain(m, "body", "tail", (0, 14, -7), 4, 5, 5, 4, axis="z", sign=-1, step=3, taper=0.95, steptaper=1.0, mat="dark", pat="fur", role="tail", rot=(0.1, 0, 0), ph=0.5)
    ex, ey, ez = tip(m, t[-1], "z", -1)
    m.add("tailglow", t[-1], (0, ey - 2, ez - 1), (4, 4, 3), mat="accent2", pat="glow", pivot=(ex, ey, ez + 1))
    return m
hyb(54, "lobo_ocaso", "Lobo del Ocaso", "Dusk Wolf", "lobo_escarcha", "zorro_sombras", dusk_wolf, 1.5, P(base="#a8a8d8", dark="#3a3470", light="#eef0ff", accent="#8a4ae0", accent2="#a8e6ff", belly="#d0d0ee", eye="#c8a0ff"),
    "Híbrido de lobo de escarcha y zorro de las sombras: pelaje bicolor, orejas grandes y cola luminosa.", "Solo por cría")

# 55 Oso Acorazado (Oso Colosal x Jabalí Acorazado)
def armored_bear(m=None, pal=None):
    m = colossal_bear()
    for i in range(3):
        m.add("plate%d" % i, "body", (0, 21, 6 - i * 6), (11, 3, 5), mat="accent", pat="plate")
    m.pair("tusk", "head_sn", (3, 14, 25), (1, 4, 1), rot=(0.3, 0, 0), mat="bone")
    m.pair("sideplate", "body", (7.3, 11, 0), (1, 8, 14), mat="accent", pat="plate")
    return m
hyb(55, "oso_acorazado", "Oso Acorazado", "Armored Bear", "oso_colosal", "jabali_acorazado", armored_bear, 2.7, P(base="#94602e", dark="#5a3a1c", light="#bc844a", accent="#c4c6cc", accent2="#3a2a1a", belly="#cda064", eye="#ff9a3c"),
    "Híbrido de oso y jabalí: corpulento, con colmillos y placas metálicas en el lomo.", "Solo por cría")

# 56 Escorpiaraña (Escorpión Colosal x Araña de Sangre)
def scorpispider(m=None, pal=None):
    m = scorpion()
    m.get("abdomen")["mat"] = "accent"; m.get("abdomen")["pat"] = "spot"
    return m
hyb(56, "escorpiarana", "Escorpiaraña", "Scorpispider", "escorpion_colosal", "arana_sangre", scorpispider, 2.0, P(base="#2a1418", dark="#0e0608", light="#5a2a2a", accent="#c01c28", accent2="#e8d080", belly="#3a1c20", eye="#ff3020"),
    "Híbrido de escorpión y araña de sangre: abdomen rojo manchado, pinzas y aguijón.", "Solo por cría")

# 57 Ciempiés Titán (Ciempiés Gigante x Gusano Titánico)
def titan_centipede(m=None, pal=None):
    m = m or Model()
    centipede(m, n=10, w=12, h=9, d=6, mat="base", mat2="dark", pat="plate", y=4, head_w=11)
    return m
hyb(57, "ciempies_titan", "Ciempiés Titán", "Titan Centipede", "ciempies_gigante", "gusano_titanico", titan_centipede, 2.0, P(base="#b0602a", dark="#3a1c10", light="#e8a050", accent="#f0c850", accent2="#ffe080", belly="#a85a14", eye="#ff3020"),
    "Híbrido de ciempiés y gusano: segmentos acorazados enormes y muchas patas.", "Solo por cría")

# 58 Hidra Esmeralda (Hidra x Serpiente Esmeralda)
def emerald_hydra(m=None, pal=None):
    m = m or Model()
    hydra(m, heads=3, bw=8, bh=6, bd=14, lh=4, lw=2, neck_n=5, neck_step=4, neck_w=3, head_s=(4, 4, 5), snout=(3, 2, 3), mat="base", pat="scale", spread=4.0, tail_n=5)
    return m
hyb(58, "hidra_esmeralda", "Hidra Esmeralda", "Emerald Hydra", "hidra_tres_cabezas", "serpiente_esmeralda", emerald_hydra, 2.4, P(base="#1ea050", dark="#0c5a2a", light="#64e684", accent="#e6323c", accent2="#c8dc50", belly="#cddc78", eye="#ffe632"),
    "Híbrido de hidra y serpiente esmeralda: tres cabezas serpentinas de escamas brillantes.", "Solo por cría")

# 59 Leviatán Dentado (Megalodón x Leviatán Marino)
def toothed_leviathan(m=None, pal=None):
    m = m or Model()
    fish(m, bw=11, bh=11, bd=17, y=2, n=5, head_s=(9, 9, 9), snout=(7, 5, 7), mat="base", pat="plate", dorsal=8, tailh=12, pec=(8, 1, 5), taper=0.85)
    for i in range(4):
        m.add("plates%d" % i, "body", (0, 13, 6 - i * 4), (5, 3, 3), mat="accent", pat="plate")
    return m
hyb(59, "leviatan_dentado", "Leviatán Dentado", "Toothed Leviathan", "megalodon", "leviatan_marino", toothed_leviathan, 2.5, P(base="#3a6e98", dark="#18385a", light="#8ac0e0", accent="#50d2ff", accent2="#e6f0f6", belly="#d8e8f2", eye="#7affff"),
    "Híbrido de megalodón y leviatán: tiburón blindado con placas azules.", "Solo por cría")

# 60 Kraken Abisal (Kraken x Serpiente Abisal)
def abyssal_kraken(m=None, pal=None):
    m = m or Model()
    octopus(m, mantle=(12, 12, 12), y=14, tent=8, tn=5, tw=3, tstep=5, mat="base", pat="glow", tmat="base", spread=5.0)
    return m
hyb(60, "kraken_abisal", "Kraken Abisal", "Abyssal Kraken", "kraken", "serpiente_abisal", abyssal_kraken, 4.0, P(base="#3a1c58", dark="#140a28", light="#7a4ab0", accent="#a050ff", accent2="#50f0ff", belly="#5a3a80", eye="#50f0ff"),
    "Híbrido de kraken y serpiente abisal: tentáculos oscuros con luces bioluminiscentes.", "Solo por cría")

# 61 Raya Cristalina (Mantarraya Fantasma x Ballena de Cristal)
def crystal_ray(m=None, pal=None):
    m = m or Model()
    ray(m, bw=14, bh=3, bd=16, y=4, wings=((9, 1, 15), (9, 1, 11)), tail_n=6, mat="base", pat="crystal", wmat="base", tailmat="accent")
    for i in range(3):
        m.add("cry%d" % i, "body", (0, 8, 4 - i * 4), (2, 4, 2), mat="accent", pat="crystal")
    return m
hyb(61, "raya_cristalina", "Raya Cristalina", "Crystal Ray", "mantarraya_fantasma", "ballena_cristal", crystal_ray, 1.5, P(base="#a8e0f8", dark="#4a96d0", light="#f0fcff", accent="#78e6ff", accent2="#ffffff", belly="#d4eefa", eye="#ffffff"),
    "Híbrido de mantarraya y ballena de cristal: raya voladora de cuerpo cristalino.", "Solo por cría")

# 62 Ciervo de Escarcha (Ciervo Cristalino x Lobo de Escarcha)
def frost_stag(m=None, pal=None):
    m = crystal_deer()
    for p in m.parts:
        if p["name"] in ("body", "neck", "head") or p["name"].startswith("leg"):
            p["pat"] = "fur"
    for i in range(4):
        m.add("ice%d" % i, "body", (0, 20, 5 - i * 3.5), (2, 3, 2), mat="accent", pat="crystal")
    return m
hyb(62, "ciervo_escarcha", "Ciervo de Escarcha", "Frost Stag", "ciervo_cristalino", "lobo_escarcha", frost_stag, 2.2, P(base="#d4e8f8", dark="#6a98d6", light="#ffffff", accent="#78d2ff", accent2="#ffffff", belly="#e0eef8", eye="#50c8ff"),
    "Híbrido de ciervo cristalino y lobo de escarcha: pelaje helado y astas de cristal.", "Solo por cría")
