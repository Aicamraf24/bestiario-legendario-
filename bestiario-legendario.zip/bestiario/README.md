# Bestiario Legendario (Fabric · Minecraft Java 26.1.2)

50 criaturas legendarias + 12 híbridos, integradas con tu mod **Cápsulas**.

## Cómo compilar (GitHub Actions)
1. Crea un repositorio y sube **todo el contenido** de esta carpeta (incluida `.github/`).
2. Actions ejecuta `gradle build` (igual que tu mod Cápsulas: Java 25, Loom 1.15.2, Fabric API 0.150.0+26.1.2).
3. Descarga el artefacto `bestiario-legendario` (el `.jar` de `build/libs/`).
4. Instala en `mods/`: **Bestiario Legendario + Cápsulas (capsulas-1.0.0.jar, versión corregida) + Fabric API**.

> No incluyo `gradle-wrapper.jar` (no se puede generar sin internet). GitHub Actions no lo necesita
> (usa `gradle/actions/setup-gradle`). En local: `gradle wrapper` y luego `./gradlew build`.

## Integración con Cápsulas (real, sin tocar su código)
Cápsulas guarda el mob entero con `mob.save()` y lo recrea con `EntityType.create()`, pero **no guarda quién la lanzó** y no tiene eventos/API.
Por eso se añade un Mixin por nombre (`@Mixin(targets="com.capsulas.entity.ThrownCapsule")`) en `onHitEntity` (solo con cápsula **vacía**):
anota el UUID del lanzador en la criatura; la criatura lo escribe en su NBT **solo durante esa captura** (`BL_CapturedBy`).
Al liberar la cápsula, la criatura lee esa marca y nace **pacífica, domesticada y con ese jugador como propietario permanente**
(aunque la suelte otra persona). Salvajes nunca tienen esa marca → hostiles. Se conservan especie, variante, vida, nivel, genes,
edad, silla, etc. No se modifica ni duplica nada de Cápsulas.

## Cómo se juega
- **Salvajes**: hostiles. Capturas con la cápsula vacía; sueltas lanzando la cápsula llena contra una superficie.
- **Clic derecho (dueño)**: mano vacía = sentarse/levantarse · con silla puesta y sin agacharte = **montar** (agachado = sentarse).
- **Silla vanilla**: clic derecho con silla. **Tijeras**: quitan la silla. **Palo**: alterna modo *defensa* (si no, nunca ataca por su cuenta).
- **Alimento**: comida de la especie (ver `/bestiario info <id>`) → modo "amor"; dos adultos domesticados compatibles y cerca → gestación → cría
  (vivíparas) o **huevo** (ovíparas, eclosiona solo). Cría con modelo y textura propios, crece con el tiempo; la comida acelera su crecimiento.
- **Híbridos** (12, modelo y textura propios): se obtienen cruzando especies compatibles (ver `/bestiario info`). No aparecen salvajes.
- **Vuelo** (especies con alas): montado, el movimiento sigue tu mirada (W/S avanzar/retroceder, A/D lateral; mirar arriba/abajo sube/baja; sin teclas = planear).
  Despega mirando hacia arriba mientras avanzas; aterriza mirando hacia abajo al tocar suelo. **Natación** igual bajo el agua.
- **Bestiario**: ítem `bestiario:bestiario` (receta: libro + esmeralda) o `/bestiario`, `/bestiario lista <n>`, `/bestiario info <id>`, `/bestiario progreso`.
  (Es una interfaz por chat; no hay pantalla gráfica.)
- Probar: `/summon bestiario:grifo_real` (ids en `/bestiario lista`).

## Aparición natural (propia, configurable en `config/bestiario.json`)
Sistema propio por jugador (no depende del mobcap vanilla): prueba posiciones a 24–64 bloques según modo (superficie/cueva/agua/aire),
dimensión (**Overworld y Nether**), bioma y hora. Nether: Espectro Carmesí, Gólem de Magma, Fénix, Devorador de Huesos, Dragón del Apocalipsis, Devorador de Mundos.
No hay jefes: las 10 del grupo E son criaturas iguales a las demás (más fuertes y más raras), con las mismas mecánicas.

## Modelos y texturas
Modelos cúbicos propios por especie (silueta, colores y partes de la imagen de referencia), **no idénticos** a la imagen (es un render, no cúbico).
6 texturas por especie (normal, albina, melánica, dorada, cristalina, carmesí; con patrones distintos, no solo brillo) × adulto/cría + textura de huevo.
Todo se genera con `tools/gen_assets.py` (Python + Pillow): editar `tools/s*.py` y ejecutar `python3 tools/gen_assets.py` regenera recursos.

## Qué NO se ha podido comprobar (sinceridad)
Este ZIP **no se compiló ni se probó en el juego** (sin acceso a Minecraft 26.1.2 ni Gradle). El código usa la API vista en tu Cápsulas más mi conocimiento de
versiones anteriores; si GitHub Actions muestra errores de compilación (nombres de clases/métodos de 26.1 que difieran: renderers, `EntityModel`, `ValueInput`,
`LayerDefinition.bakeRoot`, `EntityType.Builder.passengerAttachments`, `AttachmentRegistry`…), pásamelos y los corrijo. Sin probar en juego:
vuelo/natación montados, reproducción cruzada, IA de cada especie y balance. No hay sonidos (como pediste).
