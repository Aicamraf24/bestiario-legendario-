package com.bestiario.bestiary;

import com.bestiario.data.Species;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/** /bestiario [lista [pagina]] | info <especie> | progreso. También lo abre el ítem Bestiario Legendario. */
public final class BestiaryCommand {
    private static final int PER_PAGE = 10;
    private static final String[] VARIANT_ES = {"Normal", "Albina", "Melánica", "Dorada", "Cristalina", "Carmesí"};

    private BestiaryCommand() { }

    public static void register(CommandDispatcher<CommandSourceStack> d, CommandBuildContext ctx, Commands.CommandSelection env) {
        d.register(Commands.literal("bestiario")
                .executes(c -> { sendList(c.getSource().getPlayerOrException(), 1); return 1; })
                .then(Commands.literal("lista")
                        .executes(c -> { sendList(c.getSource().getPlayerOrException(), 1); return 1; })
                        .then(Commands.argument("pagina", IntegerArgumentType.integer(1))
                                .executes(c -> { sendList(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "pagina")); return 1; })))
                .then(Commands.literal("progreso")
                        .executes(c -> { sendProgress(c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("info")
                        .then(Commands.argument("especie", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(Species.BY_ID.keySet(), b))
                                .executes(c -> { sendInfo(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "especie")); return 1; }))));
    }

    private static Component line(String s, ChatFormatting f) {
        return Component.literal(s).withStyle(f);
    }

    public static void sendList(ServerPlayer p, int page) {
        int total = Species.ALL.size();
        int pages = (total + PER_PAGE - 1) / PER_PAGE;
        page = Math.max(1, Math.min(pages, page));
        p.sendSystemMessage(line("=== Bestiario Legendario — página " + page + "/" + pages + " ===", ChatFormatting.GOLD));
        for (int i = (page - 1) * PER_PAGE; i < Math.min(total, page * PER_PAGE); i++) {
            Species s = Species.ALL.get(i);
            boolean seen = BestiaryData.has(p, s.id + ":seen") || BestiaryData.has(p, s.id + ":captured");
            boolean cap = BestiaryData.has(p, s.id + ":captured");
            boolean rel = BestiaryData.has(p, s.id + ":released");
            String st = (seen ? "[visto]" : "[?]") + (cap ? "[capturado]" : "") + (rel ? "[domesticado]" : "");
            p.sendSystemMessage(line(" #" + s.num + " " + s.es + (s.isHybrid() ? " (híbrido)" : "") + " " + st + "  → /bestiario info " + s.id,
                    seen ? ChatFormatting.GREEN : ChatFormatting.GRAY));
        }
        p.sendSystemMessage(line("Otras páginas: /bestiario lista <n>   |   Progreso: /bestiario progreso", ChatFormatting.YELLOW));
    }

    public static void sendProgress(ServerPlayer p) {
        int seen = 0, cap = 0, rel = 0, base = 0;
        for (Species s : Species.ALL) {
            if (s.isHybrid()) continue;
            base++;
            if (BestiaryData.has(p, s.id + ":seen") || BestiaryData.has(p, s.id + ":captured")) seen++;
            if (BestiaryData.has(p, s.id + ":captured")) cap++;
            if (BestiaryData.has(p, s.id + ":released")) rel++;
        }
        p.sendSystemMessage(line("Progreso: vistas " + seen + "/" + base + " · capturadas " + cap + "/" + base + " · domesticadas " + rel + "/" + base, ChatFormatting.GOLD));
    }

    public static void sendInfo(ServerPlayer p, String id) {
        Species s = Species.BY_ID.get(id);
        if (s == null) {
            p.sendSystemMessage(line("Especie desconocida: " + id, ChatFormatting.RED));
            return;
        }
        boolean cap = BestiaryData.has(p, s.id + ":captured");
        boolean rel = BestiaryData.has(p, s.id + ":released");
        p.sendSystemMessage(line("=== #" + s.num + " " + s.es + " ===", ChatFormatting.GOLD));
        p.sendSystemMessage(line(s.desc, ChatFormatting.WHITE));
        p.sendSystemMessage(line("Hábitat: " + s.biome, ChatFormatting.AQUA));
        p.sendSystemMessage(line(s.isHybrid() ? "Hostilidad: nace domesticada (solo aparece por cría)"
                : "Hostilidad: HOSTIL en estado salvaje; pacífica y domesticable tras liberarla de una Cápsula", ChatFormatting.RED));
        p.sendSystemMessage(line("Estadísticas base: vida " + (int) s.hp + " · daño " + s.dmg + " · velocidad " + s.spd + " · detección " + (int) s.det, ChatFormatting.GRAY));
        p.sendSystemMessage(line("Habilidad: " + s.abil, ChatFormatting.LIGHT_PURPLE));
        p.sendSystemMessage(line("Alimento de cría: " + String.join(", ", s.foodNames), ChatFormatting.GREEN));
        StringBuilder rep = new StringBuilder("Reproducción: " + (s.ovi ? "ovípara (pone huevos y se incuban)" : "vivípara (gestación y nacimiento)"));
        if (s.isHybrid()) {
            Species a = Species.BY_ID.get(s.hybridA), b = Species.BY_ID.get(s.hybridB);
            rep.append(" · híbrido de ").append(a != null ? a.es : s.hybridA).append(" + ").append(b != null ? b.es : s.hybridB);
        } else {
            List<String> partners = new ArrayList<>();
            for (Species h : Species.ALL) {
                if (!h.isHybrid()) continue;
                if (h.hybridA.equals(s.id)) { Species o = Species.BY_ID.get(h.hybridB); partners.add((o != null ? o.es : h.hybridB) + " → " + h.es); }
                else if (h.hybridB.equals(s.id)) { Species o = Species.BY_ID.get(h.hybridA); partners.add((o != null ? o.es : h.hybridA) + " → " + h.es); }
            }
            if (!partners.isEmpty()) rep.append(" · compatible con: ").append(String.join("; ", partners));
        }
        p.sendSystemMessage(line(rep.toString(), ChatFormatting.GREEN));
        String mount = s.isFlyer() ? "montable con silla; VUELA (mira arriba/abajo para subir/bajar, W/S avanzar/retroceder, nada = planear)"
                : s.isSwimmer() ? "montable con silla; NADA bajo el agua siguiendo tu mirada" : "montable con silla (terrestre)";
        p.sendSystemMessage(line("Montura: " + mount, ChatFormatting.YELLOW));
        StringBuilder vs = new StringBuilder("Variantes descubiertas: ");
        for (int i = 0; i < VARIANT_ES.length; i++) {
            vs.append(BestiaryData.has(p, s.id + ":variant:" + i) ? VARIANT_ES[i] : "???").append(i < VARIANT_ES.length - 1 ? ", " : "");
        }
        p.sendSystemMessage(line(vs.toString(), ChatFormatting.WHITE));
        p.sendSystemMessage(line("Estado: " + (cap ? "capturada" : "no capturada") + " · " + (rel ? "domesticada" : "no domesticada"), ChatFormatting.GRAY));
    }
}
