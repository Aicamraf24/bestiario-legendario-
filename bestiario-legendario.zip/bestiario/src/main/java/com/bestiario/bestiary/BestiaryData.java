package com.bestiario.bestiary;

import com.bestiario.Bestiario;
import com.bestiario.data.Species;
import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

/** Progreso del bestiario por jugador (persistente, se conserva al morir). Claves: especie:seen|captured|released|bred|variant:N */
public final class BestiaryData {
    public static AttachmentType<List<String>> ENTRIES;

    public static void init() {
        ENTRIES = AttachmentRegistry.<List<String>>create(Bestiario.id("entries"),
                b -> b.initializer(ArrayList::new).persistent(Codec.STRING.listOf()).copyOnDeath());
    }

    public static boolean has(ServerPlayer p, String key) {
        return p.getAttachedOrCreate(ENTRIES).contains(key);
    }

    public static void mark(ServerPlayer p, String speciesId, String what) {
        String key = speciesId + ":" + what;
        List<String> cur = p.getAttachedOrCreate(ENTRIES);
        if (cur.contains(key)) return;
        List<String> n = new ArrayList<>(cur);
        n.add(key);
        p.setAttached(ENTRIES, n);
        Species s = Species.BY_ID.get(speciesId);
        if (s == null) return;
        String msg = switch (what) {
            case "seen" -> "Bestiario: has descubierto a " + s.es;
            case "captured" -> "Bestiario: has capturado a " + s.es;
            case "released" -> "Bestiario: has domesticado a " + s.es;
            case "bred" -> "Bestiario: ha nacido una cría de " + s.es;
            default -> null;
        };
        if (msg != null) p.displayClientMessage(Component.literal(msg), true);
    }
}
