package com.bestiario;

import com.bestiario.bestiary.BestiaryCommand;
import com.bestiario.bestiary.BestiaryData;
import com.bestiario.config.BestiarioConfig;
import com.bestiario.data.Species;
import com.bestiario.entity.ModEntities;
import com.bestiario.item.ModItems;
import com.bestiario.spawn.SpawnManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Bestiario implements ModInitializer {
    public static final String MOD_ID = "bestiario";
    public static final Logger LOG = LoggerFactory.getLogger("Bestiario Legendario");
    public static BestiarioConfig CONFIG = new BestiarioConfig();

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        CONFIG = BestiarioConfig.load();
        Species.load();
        ModEntities.init();
        ModItems.init();
        BestiaryData.init();
        ServerTickEvents.END_SERVER_TICK.register(SpawnManager::tick);
        CommandRegistrationCallback.EVENT.register(BestiaryCommand::register);
        LOG.info("Bestiario Legendario: {} especies registradas.", Species.ALL.size());
    }
}
