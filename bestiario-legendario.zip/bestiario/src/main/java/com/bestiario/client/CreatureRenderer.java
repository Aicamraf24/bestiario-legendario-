package com.bestiario.client;

import com.bestiario.Bestiario;
import com.bestiario.data.Species;
import com.bestiario.entity.BestiaryCreature;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class CreatureRenderer extends MobRenderer<BestiaryCreature, CreatureRenderState, CreatureModel> {
    private final Species sp;
    private final Identifier[][] textures;

    public CreatureRenderer(EntityRendererProvider.Context ctx, Species sp) {
        super(ctx, CreatureModel.create(sp), Math.max(0.3F, Math.min(2.5F, sp.hw * 0.5F)));
        this.sp = sp;
        int n = Species.VARIANTS.length;
        this.textures = new Identifier[2][n];
        for (int v = 0; v < n; v++) {
            textures[0][v] = Bestiario.id("textures/entity/" + sp.id + "/" + Species.VARIANTS[v] + ".png");
            textures[1][v] = Bestiario.id("textures/entity/" + sp.id + "/baby_" + Species.VARIANTS[v] + ".png");
        }
    }

    @Override
    public CreatureRenderState createRenderState() {
        return new CreatureRenderState();
    }

    @Override
    public void extractRenderState(BestiaryCreature e, CreatureRenderState s, float partialTick) {
        super.extractRenderState(e, s, partialTick);
        s.variant = Math.max(0, Math.min(Species.VARIANTS.length - 1, e.getVariant()));
        s.baby = e.isJuvenile();
        s.sitting = e.isSitting() && !e.isVehicle();
        s.saddled = e.isSaddled();
        s.ridden = e.isVehicle();
        s.hurt = e.hurtTime > 0;
        s.attack = e.getAttackAnim(partialTick);
        s.flying = sp.isFlyer() && !e.onGround() && !e.isInWater();
    }

    @Override
    public Identifier getTextureLocation(CreatureRenderState s) {
        return textures[s.baby ? 1 : 0][s.variant];
    }

    @Override
    protected void scale(CreatureRenderState s, PoseStack poseStack) {
        poseStack.scale(sp.sc, sp.sc, sp.sc);
    }
}
