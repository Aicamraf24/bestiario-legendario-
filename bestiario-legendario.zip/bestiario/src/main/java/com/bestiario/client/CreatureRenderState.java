package com.bestiario.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class CreatureRenderState extends LivingEntityRenderState {
    public int variant;
    public boolean baby, sitting, saddled, flying, ridden, hurt, swimmingMode;
}
