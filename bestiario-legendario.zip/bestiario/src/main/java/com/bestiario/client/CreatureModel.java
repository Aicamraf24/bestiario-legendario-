package com.bestiario.client;

import com.bestiario.data.PartData;
import com.bestiario.data.Species;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Modelo cúbico genérico construido a partir de los datos de cada especie (adulto y cría en el mismo modelo;
 * se muestra uno u otro). Las animaciones se deducen del "rol" de cada caja.
 */
public class CreatureModel extends EntityModel<CreatureRenderState> {
    private static final float DEG = (float) Math.PI / 180.0F;

    private final Species sp;
    private final ModelPart adultGroup, babyGroup;
    private final Map<String, ModelPart> adult = new HashMap<>();
    private final Map<String, ModelPart> baby = new HashMap<>();

    public static CreatureModel create(Species sp) {
        return new CreatureModel(sp, buildLayer(sp).bakeRoot());
    }

    private CreatureModel(Species sp, ModelPart root) {
        super(root);
        this.sp = sp;
        this.adultGroup = root.getChild("adult");
        this.babyGroup = root.getChild("baby");
        collect(adultGroup, sp.adult, adult);
        collect(babyGroup, sp.baby, baby);
    }

    static LayerDefinition buildLayer(Species sp) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        addParts(root.addOrReplaceChild("adult", CubeListBuilder.create(), PartPose.ZERO), sp.adult);
        addParts(root.addOrReplaceChild("baby", CubeListBuilder.create(), PartPose.ZERO), sp.baby);
        return LayerDefinition.create(mesh, sp.tw, sp.th);
    }

    static void addParts(PartDefinition group, List<PartData> parts) {
        Map<String, PartDefinition> defs = new HashMap<>();
        for (PartData p : parts) {
            PartDefinition parent = p.parent.isEmpty() ? group : defs.get(p.parent);
            if (parent == null) parent = group;
            PartDefinition d = parent.addOrReplaceChild(p.name,
                    CubeListBuilder.create().texOffs(p.u, p.v).addBox(p.mx, p.my, p.mz, p.sx, p.sy, p.sz),
                    PartPose.offsetAndRotation(p.ox, p.oy, p.oz, p.rx, p.ry, p.rz));
            defs.put(p.name, d);
        }
    }

    static void collect(ModelPart group, List<PartData> parts, Map<String, ModelPart> out) {
        for (PartData p : parts) {
            ModelPart parent = p.parent.isEmpty() ? group : out.get(p.parent);
            if (parent == null) parent = group;
            out.put(p.name, parent.getChild(p.name));
        }
    }

    @Override
    public void setupAnim(CreatureRenderState s) {
        super.setupAnim(s);
        adultGroup.visible = !s.baby;
        babyGroup.visible = s.baby;
        ModelPart group = s.baby ? babyGroup : adultGroup;
        group.y = s.sitting ? sp.sit * (s.baby ? 0.55F : 1.0F) : 0.0F;
        animate(s.baby ? sp.baby : sp.adult, s.baby ? baby : adult, s);
    }

    private void animate(List<PartData> parts, Map<String, ModelPart> map, CreatureRenderState s) {
        float t = s.ageInTicks;
        float ws = Math.min(1.0F, s.walkAnimationSpeed);
        float wp = s.walkAnimationPos;
        boolean moving = ws > 0.04F;
        float run = ws > 0.55F ? 1.3F : 1.0F;
        float gait = 0.6662F * run;
        float atk = s.attackTime > 0 ? Mth.sin(s.attackTime * (float) Math.PI) : 0.0F;
        float flapRate = s.ridden ? 0.75F : 0.6F;

        for (PartData p : parts) {
            ModelPart mp = map.get(p.name);
            if (mp == null) continue;
            mp.x = p.ox; mp.y = p.oy; mp.z = p.oz;
            mp.xRot = p.rx; mp.yRot = p.ry; mp.zRot = p.rz;
            mp.visible = true;
            float side = p.side;
            switch (p.role) {
                case "body" -> {
                    if (!moving && !s.sitting) mp.y += Mth.sin(t * 0.08F + p.ph) * 0.35F;
                    else if (moving) mp.y += Mth.abs(Mth.cos(wp * gait)) * 0.4F * ws;
                }
                case "head" -> {
                    float yaw = Mth.clamp(s.yRot, -50.0F, 50.0F) * DEG;
                    float pitch = Mth.clamp(s.xRot, -40.0F, 40.0F) * DEG;
                    mp.yRot += yaw;
                    mp.xRot += pitch;
                    if (p.idx > 0 || p.name.startsWith("head")) mp.yRot += Mth.sin(t * 0.07F + p.idx * 2.1F) * 0.22F * (p.idx > 0 ? 1.0F : 0.5F);
                    if (s.sitting) mp.xRot += 0.2F;
                    mp.xRot += atk * 0.7F;
                    if (s.hurt) mp.yRot += Mth.sin(t * 2.2F) * 0.15F;
                }
                case "jaw" -> mp.xRot += atk > 0 ? atk * 0.9F : 0.04F + (Mth.sin(t * 0.1F) + 1.0F) * 0.03F;
                case "neck" -> {
                    mp.xRot += Mth.sin(t * 0.05F + p.ph) * 0.03F + atk * 0.15F;
                    mp.yRot += Mth.sin(t * 0.04F + p.ph) * 0.04F;
                }
                case "leg" -> {
                    if (s.flying) {
                        mp.xRot += p.rear ? 0.9F : 0.7F;
                    } else if (s.sitting) {
                        mp.xRot += p.rear ? -1.25F : -0.05F;
                    } else {
                        mp.xRot += Mth.cos(wp * gait + p.idx * (float) Math.PI) * 1.3F * ws * p.amp;
                    }
                }
                case "arm" -> {
                    if (s.flying) mp.xRot += 0.5F;
                    mp.xRot += Mth.cos(wp * gait + (p.idx + 1) * (float) Math.PI) * 1.0F * ws * p.amp;
                    mp.xRot -= atk * 1.6F;
                    mp.xRot += Mth.sin(t * 0.08F + p.idx) * 0.04F;
                }
                case "wing" -> {
                    float lag = p.idx * 0.45F;
                    float w = Mth.sin(t * flapRate - lag);
                    if (s.flying) {
                        mp.yRot = 0.0F;
                        mp.zRot = -side * (0.2F + 0.7F * w) * (p.idx == 0 ? 1.0F : 0.7F);
                    } else {
                        mp.zRot += side * Mth.sin(t * 0.05F + lag) * 0.03F;
                        if (p.ry == 0.0F && p.rz == 0.0F) mp.zRot += -side * (0.15F + 0.25F * w); // alas planas (raya)
                        if (s.ridden && moving) mp.zRot += -side * 0.1F * w;
                    }
                }
                case "tail" -> {
                    mp.yRot += Mth.sin(t * 0.09F + p.ph) * 0.18F * p.amp + Mth.sin(wp * 0.6662F + p.ph) * 0.25F * ws;
                    mp.xRot += atk * 0.3F * (p.idx + 1) * 0.3F;
                    if (s.sitting) mp.xRot += 0.2F;
                }
                case "seg" -> {
                    float swim = moving ? 1.0F : 0.35F;
                    mp.yRot += Mth.sin(t * 0.12F - p.idx * 0.55F) * 0.12F * swim + Mth.sin(wp * 0.5F - p.idx * 0.7F) * 0.4F * ws;
                }
                case "tentacle" -> {
                    mp.xRot += Mth.sin(t * 0.07F + p.ph) * 0.22F + Mth.sin(wp * 0.4F + p.ph) * 0.2F * ws;
                    mp.zRot += Mth.cos(t * 0.06F + p.ph * 1.3F) * 0.18F;
                }
                case "pincer" -> mp.yRot += side * (0.15F + 0.2F * Mth.sin(t * 0.1F)) - atk * side * 0.5F;
                case "spleg" -> {
                    float ph = p.ph;
                    mp.yRot += Mth.cos(wp * gait + ph) * 0.5F * ws;
                    mp.zRot += -side * Math.max(0.0F, Mth.sin(wp * gait + ph)) * 0.25F * ws;
                    if (!moving) mp.zRot += -side * Mth.sin(t * 0.05F + ph) * 0.02F;
                }
                case "fin" -> {
                    float swim = moving ? 1.0F : 0.4F;
                    if (p.side == 0) mp.yRot += Mth.sin(t * 0.2F + p.idx * 0.5F) * 0.35F * swim;
                    else mp.zRot += Mth.sin(t * 0.15F + p.idx) * 0.25F * swim * side;
                }
                case "saddle" -> mp.visible = s.saddled;
                default -> { }
            }
        }
    }
}
