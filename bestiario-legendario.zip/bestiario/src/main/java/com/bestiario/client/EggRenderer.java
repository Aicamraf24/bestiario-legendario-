package com.bestiario.client;

import com.bestiario.Bestiario;
import com.bestiario.data.PartData;
import com.bestiario.data.Species;
import com.bestiario.entity.BestiaryEgg;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public class EggRenderer extends MobRenderer<BestiaryEgg, EggRenderer.EggState, EggRenderer.EggModel> {
    public static class EggState extends LivingEntityRenderState {
        public int species;
    }

    public static class EggModel extends EntityModel<EggState> {
        public static EggModel create() {
            MeshDefinition mesh = new MeshDefinition();
            PartDefinition root = mesh.getRoot();
            Map<String, PartDefinition> defs = new HashMap<>();
            for (PartData p : Species.EGG) {
                PartDefinition parent = p.parent.isEmpty() ? root : defs.get(p.parent);
                defs.put(p.name, parent.addOrReplaceChild(p.name,
                        CubeListBuilder.create().texOffs(p.u, p.v).addBox(p.mx, p.my, p.mz, p.sx, p.sy, p.sz),
                        PartPose.offsetAndRotation(p.ox, p.oy, p.oz, p.rx, p.ry, p.rz)));
            }
            return new EggModel(LayerDefinition.create(mesh, Species.eggW, Species.eggH).bakeRoot());
        }

        private EggModel(ModelPart root) {
            super(root);
        }
    }

    private final Identifier[] textures;

    public EggRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, EggModel.create(), 0.3F);
        textures = new Identifier[Species.ALL.size()];
        for (int i = 0; i < textures.length; i++) {
            textures[i] = Bestiario.id("textures/entity/egg/" + Species.ALL.get(i).id + ".png");
        }
    }

    @Override
    public EggState createRenderState() {
        return new EggState();
    }

    @Override
    public void extractRenderState(BestiaryEgg e, EggState s, float partialTick) {
        super.extractRenderState(e, s, partialTick);
        s.species = Math.max(0, Math.min(textures.length - 1, e.getSpeciesIndex()));
    }

    @Override
    public Identifier getTextureLocation(EggState s) {
        return textures[s.species];
    }
}
