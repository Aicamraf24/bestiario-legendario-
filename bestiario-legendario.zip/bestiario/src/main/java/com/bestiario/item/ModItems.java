package com.bestiario.item;

import com.bestiario.Bestiario;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

public class ModItems {
    public static Item BOOK;

    public static void init() {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Bestiario.id("bestiario"));
        Item.Properties props = new Item.Properties().setId(key).stacksTo(1);
        BOOK = Registry.register(BuiltInRegistries.ITEM, key, new BestiaryBookItem(props));
    }
}
