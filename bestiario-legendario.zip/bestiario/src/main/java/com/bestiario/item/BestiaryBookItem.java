package com.bestiario.item;

import com.bestiario.bestiary.BestiaryCommand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Libro del Bestiario: clic derecho muestra la lista de especies y tu progreso. */
public class BestiaryBookItem extends Item {
    public BestiaryBookItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer sp) {
            BestiaryCommand.sendList(sp, 1);
        }
        return InteractionResult.SUCCESS;
    }
}
