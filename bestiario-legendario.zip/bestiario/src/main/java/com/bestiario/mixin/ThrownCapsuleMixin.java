package com.bestiario.mixin;

import com.bestiario.entity.BestiaryCreature;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Integración con Cápsulas SIN modificar su código: justo antes de que la cápsula vacía golpee a una criatura
 * se anota qué jugador la lanzó. La criatura guarda esa marca en su NBT durante la captura (mob.save) y,
 * al liberarla, nace pacífica y domesticada con ese jugador como propietario permanente.
 */
@Mixin(targets = "com.capsulas.entity.ThrownCapsule")
public abstract class ThrownCapsuleMixin {

    @Inject(method = "onHitEntity", at = @At("HEAD"))
    private void bestiario$markCaptor(EntityHitResult hit, CallbackInfo ci) {
        ThrowableItemProjectile self = (ThrowableItemProjectile) (Object) this;
        // Solo la cápsula vacía captura: la llena no tiene datos personalizados.
        if (self.getItem().has(DataComponents.CUSTOM_DATA)) return;
        if (hit.getEntity() instanceof BestiaryCreature creature && self.getOwner() instanceof ServerPlayer player) {
            creature.markCapturedBy(player);
        }
    }
}
