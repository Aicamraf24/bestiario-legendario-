package com.bestiario.data;

import com.bestiario.entity.BestiaryCreature;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Definición de una especie (50 base + 12 híbridos). Se carga de bestiario_species.json. */
public final class Species {
    public static final List<Species> ALL = new ArrayList<>();
    public static final Map<String, Species> BY_ID = new LinkedHashMap<>();
    public static final Map<EntityType<?>, Species> BY_TYPE = new HashMap<>();
    public static final List<PartData> EGG = new ArrayList<>();
    public static String[] VARIANTS = {"normal", "albino", "melanic", "golden", "crystal", "crimson"};
    public static int eggW = 64, eggH = 32;

    public int num;
    public String id, es, en, grp, move, fx, abil, time, desc, biome;
    public double hp, dmg, spd, arm, kb, det, fs, ride, swim, step;
    public boolean ovi, spawn;
    public List<String> foodIds = new ArrayList<>(), foodNames = new ArrayList<>(), dims = new ArrayList<>(),
            modes = new ArrayList<>(), biomes = new ArrayList<>();
    public int weight, grpMin = 1, grpMax = 1;
    public String hybridA = "", hybridB = "";
    public float h, sc, hw, seat, sit;
    public int tw, th;
    public List<PartData> adult = new ArrayList<>(), baby = new ArrayList<>();
    public EntityType<BestiaryCreature> type;

    public boolean isFlyer() { return "fly".equals(move); }
    public boolean isSwimmer() { return "swim".equals(move); }
    public boolean isHybrid() { return !hybridA.isEmpty(); }

    public static void load() {
        try (InputStream in = Species.class.getResourceAsStream("/bestiario_species.json")) {
            if (in == null) throw new IllegalStateException("Falta bestiario_species.json");
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonArray vs = root.getAsJsonArray("variants");
            VARIANTS = new String[vs.size()];
            for (int i = 0; i < vs.size(); i++) VARIANTS[i] = vs.get(i).getAsString();
            for (JsonElement e : root.getAsJsonArray("egg")) EGG.add(new PartData(e.getAsJsonObject()));
            eggW = root.getAsJsonArray("egg_tex").get(0).getAsInt();
            eggH = root.getAsJsonArray("egg_tex").get(1).getAsInt();
            for (JsonElement e : root.getAsJsonArray("species")) {
                Species s = parse(e.getAsJsonObject());
                ALL.add(s);
                BY_ID.put(s.id, s);
            }
        } catch (Exception ex) {
            throw new RuntimeException("No se pudieron cargar las especies de Bestiario Legendario", ex);
        }
    }

    private static List<String> strs(JsonArray a) {
        List<String> l = new ArrayList<>();
        for (JsonElement e : a) l.add(e.getAsString());
        return l;
    }

    private static Species parse(JsonObject o) {
        Species s = new Species();
        s.num = o.get("num").getAsInt();
        s.id = o.get("id").getAsString();
        s.es = o.get("es").getAsString();
        s.en = o.get("en").getAsString();
        s.grp = o.get("grp").getAsString();
        s.move = o.get("move").getAsString();
        s.hp = o.get("hp").getAsDouble();
        s.dmg = o.get("dmg").getAsDouble();
        s.spd = o.get("spd").getAsDouble();
        s.arm = o.get("arm").getAsDouble();
        s.kb = o.get("kb").getAsDouble();
        s.det = o.get("det").getAsDouble();
        s.fs = o.get("fs").getAsDouble();
        s.ride = o.get("ride").getAsDouble();
        s.swim = o.get("swim").getAsDouble();
        s.step = o.get("step").getAsDouble();
        s.ovi = o.get("ovi").getAsBoolean();
        s.spawn = o.get("spawn").getAsBoolean();
        s.fx = o.get("fx").getAsString();
        s.abil = o.get("abil").getAsString();
        s.time = o.get("time").getAsString();
        s.desc = o.get("desc").getAsString();
        s.biome = o.get("biome").getAsString();
        s.foodIds = strs(o.getAsJsonArray("foodids"));
        s.foodNames = strs(o.getAsJsonArray("foodnames"));
        s.dims = strs(o.getAsJsonArray("dims"));
        s.modes = strs(o.getAsJsonArray("modes"));
        s.biomes = strs(o.getAsJsonArray("biomes"));
        s.weight = o.get("w").getAsInt();
        JsonArray g = o.getAsJsonArray("grp_size");
        s.grpMin = g.get(0).getAsInt();
        s.grpMax = g.get(1).getAsInt();
        JsonArray hy = o.getAsJsonArray("hybrid");
        if (hy.size() == 2) {
            s.hybridA = hy.get(0).getAsString();
            s.hybridB = hy.get(1).getAsString();
        }
        s.h = o.get("h").getAsFloat();
        s.sc = o.get("sc").getAsFloat();
        s.hw = o.get("hw").getAsFloat();
        s.seat = o.get("seat").getAsFloat();
        s.sit = o.get("sit").getAsFloat();
        s.tw = o.get("tw").getAsInt();
        s.th = o.get("th").getAsInt();
        for (JsonElement e : o.getAsJsonArray("adult")) s.adult.add(new PartData(e.getAsJsonObject()));
        for (JsonElement e : o.getAsJsonArray("baby")) s.baby.add(new PartData(e.getAsJsonObject()));
        return s;
    }

    public static Species byType(EntityType<?> t) {
        return BY_TYPE.get(t);
    }

    /** Híbrido resultante de cruzar a y b (en cualquier orden), o null si no son compatibles. */
    public static Species hybridFor(Species a, Species b) {
        for (Species s : ALL) {
            if (!s.isHybrid()) continue;
            if ((s.hybridA.equals(a.id) && s.hybridB.equals(b.id)) || (s.hybridA.equals(b.id) && s.hybridB.equals(a.id))) return s;
        }
        return null;
    }

    public boolean acceptsFood(ItemStack stack) {
        if (stack.isEmpty()) return false;
        String key = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        for (String f : foodIds) {
            if (f.startsWith("#")) {
                String path = f.substring(f.indexOf(':') + 1);
                TagKey<Item> tag = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath("minecraft", path));
                if (stack.is(tag)) return true;
            } else if (f.equals(key)) {
                return true;
            }
        }
        return false;
    }
}
