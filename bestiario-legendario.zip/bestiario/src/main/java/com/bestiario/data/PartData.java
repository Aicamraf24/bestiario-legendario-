package com.bestiario.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/** Una caja del modelo (datos generados por tools/gen_assets.py). */
public final class PartData {
    public final String name;
    public final String parent;
    public final float ox, oy, oz;      // posición relativa al padre (pivote)
    public final float mx, my, mz;      // esquina mínima de la caja relativa al pivote
    public final float sx, sy, sz;      // tamaño
    public final float rx, ry, rz;      // rotación de reposo
    public final String role;
    public final int idx;
    public final float amp;
    public final int side;
    public final float ph;
    public final boolean rear;
    public final int u, v;

    public PartData(JsonObject o) {
        name = o.get("n").getAsString();
        parent = o.get("p").getAsString();
        JsonArray off = o.getAsJsonArray("off");
        JsonArray mn = o.getAsJsonArray("mn");
        JsonArray size = o.getAsJsonArray("sz");
        JsonArray rot = o.getAsJsonArray("rot");
        JsonArray uv = o.getAsJsonArray("uv");
        ox = off.get(0).getAsFloat(); oy = off.get(1).getAsFloat(); oz = off.get(2).getAsFloat();
        mx = mn.get(0).getAsFloat(); my = mn.get(1).getAsFloat(); mz = mn.get(2).getAsFloat();
        sx = size.get(0).getAsFloat(); sy = size.get(1).getAsFloat(); sz = size.get(2).getAsFloat();
        rx = rot.get(0).getAsFloat(); ry = rot.get(1).getAsFloat(); rz = rot.get(2).getAsFloat();
        role = o.get("role").getAsString();
        idx = o.get("idx").getAsInt();
        amp = o.get("amp").getAsFloat();
        side = o.get("side").getAsInt();
        ph = o.get("ph").getAsFloat();
        rear = o.get("rear").getAsInt() == 1;
        u = uv.get(0).getAsInt();
        v = uv.get(1).getAsInt();
    }
}
