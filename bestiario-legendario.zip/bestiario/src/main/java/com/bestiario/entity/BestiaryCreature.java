package com.bestiario.entity;

import com.bestiario.Bestiario;
import com.bestiario.bestiary.BestiaryData;
import com.bestiario.config.BestiarioConfig;
import com.bestiario.data.Species;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.AmphibiousPathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;
import java.util.UUID;

/**
 * Criatura del Bestiario Legendario. Una única clase para las 62 especies (50 + 12 híbridos); lo que cambia
 * (estadísticas, movimiento, comida, modelo) viene de {@link Species}.
 * Salvaje: hostil. Tras liberarla de una Cápsula: pacífica, domesticada y con propietario permanente.
 */
public class BestiaryCreature extends PathfinderMob {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> LEVEL = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> JUVENILE = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SITTING = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SADDLED = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> TAMED = SynchedEntityData.defineId(BestiaryCreature.class, EntityDataSerializers.BOOLEAN);

    public final Species sp;

    private UUID ownerUuid;
    private boolean defend;
    private int ageTicks;            // <0 = cría, cuenta hasta 0
    private int love, breedCd, pregnant;
    private ChildData pendingChild;
    private float gh = 1f, gd = 1f, gs = 1f;
    private UUID capturedBy;
    private long capturedTick = -100;
    private boolean releasedPending;
    private boolean rideFlying;

    public BestiaryCreature(EntityType<? extends BestiaryCreature> type, Level level) {
        super(type, level);
        this.sp = Species.byType(type);
        if (sp.isFlyer()) {
            this.moveControl = new FlyingMoveControl(this, 10, true);
        } else if (sp.isSwimmer()) {
            this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02F, 0.1F, true);
            this.lookControl = new SmoothSwimmingLookControl(this, 10);
        }
    }

    public static AttributeSupplier.Builder createAttributes(Species sp) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, sp.hp)
                .add(Attributes.MOVEMENT_SPEED, sp.spd)
                .add(Attributes.ATTACK_DAMAGE, sp.dmg)
                .add(Attributes.ATTACK_KNOCKBACK, 0.5)
                .add(Attributes.FOLLOW_RANGE, sp.det)
                .add(Attributes.ARMOR, sp.arm)
                .add(Attributes.KNOCKBACK_RESISTANCE, Math.min(1.0, sp.kb))
                .add(Attributes.FLYING_SPEED, 0.4)
                .add(Attributes.STEP_HEIGHT, sp.step > 0 ? sp.step : 0.6);
    }

    // ------------------------------------------------------------------ datos sincronizados
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0);
        builder.define(LEVEL, 1);
        builder.define(JUVENILE, false);
        builder.define(SITTING, false);
        builder.define(SADDLED, false);
        builder.define(TAMED, false);
    }

    public int getVariant() { return this.entityData.get(VARIANT); }
    public void setVariant(int v) { this.entityData.set(VARIANT, Mth.clamp(v, 0, Species.VARIANTS.length - 1)); }
    public int getCreatureLevel() { return this.entityData.get(LEVEL); }
    public void setCreatureLevel(int l) { this.entityData.set(LEVEL, l); }
    public boolean isJuvenile() { return this.entityData.get(JUVENILE); }
    public boolean isSitting() { return this.entityData.get(SITTING); }
    public void setSitting(boolean b) { this.entityData.set(SITTING, b); }
    public boolean isSaddled() { return this.entityData.get(SADDLED); }
    public void setSaddled(boolean b) { this.entityData.set(SADDLED, b); }
    public boolean isTamed() { return this.entityData.get(TAMED); }
    public void setTamed(boolean b) { this.entityData.set(TAMED, b); }
    public UUID getOwnerUuid() { return ownerUuid; }
    public boolean isOwner(Entity e) { return ownerUuid != null && e != null && ownerUuid.equals(e.getUUID()); }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
        super.onSyncedDataUpdated(accessor);
        if (JUVENILE.equals(accessor)) refreshDimensions();
    }

    @Override
    public EntityDimensions getDefaultDimensions(Pose pose) {
        EntityDimensions d = getType().getDimensions();
        return isJuvenile() ? d.scale(0.55F) : d;
    }

    /** Mensaje corto al jugador. */
    private static void msg(Player p, String text) {
        if (p instanceof ServerPlayer s) s.sendSystemMessage(Component.literal(text));
    }

    // ------------------------------------------------------------------ navegación y objetivos
    @Override
    protected PathNavigation createNavigation(Level level) {
        Species s = Species.byType(getType());
        if (s != null && s.isFlyer()) return new FlyingPathNavigation(this, level);
        if (s != null && s.isSwimmer()) return new AmphibiousPathNavigation(this, level);
        return new GroundPathNavigation(this, level);
    }

    @Override
    protected void registerGoals() {
        Species s = Species.byType(getType());
        boolean fly = s != null && s.isFlyer();
        boolean swim = s != null && s.isSwimmer();
        if (!fly && !swim) this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(3, new FollowOwnerGoal(this, 1.15D, 5.0F));
        if (fly) this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        else if (swim) this.goalSelector.addGoal(5, new RandomSwimmingGoal(this, 1.0D, 40));
        else this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.85D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Siguiente al propietario; se teletransporta si se aleja demasiado. */
    private static class FollowOwnerGoal extends Goal {
        private final BestiaryCreature mob;
        private final double speed;
        private final float startDist;
        private Player owner;
        private int recalc;

        FollowOwnerGoal(BestiaryCreature mob, double speed, float startDist) {
            this.mob = mob;
            this.speed = speed;
            this.startDist = startDist;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (!mob.isTamed() || mob.isSitting() || mob.isVehicle() || mob.ownerUuid == null || mob.isJuvenile() && false) return false;
            Player p = mob.level().getPlayerByUUID(mob.ownerUuid);
            if (p == null || p.isSpectator()) return false;
            if (mob.distanceToSqr(p) < (double) (startDist * startDist)) return false;
            owner = p;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && mob.isTamed() && !mob.isSitting() && !mob.isVehicle()
                    && mob.distanceToSqr(owner) > 4.0D;
        }

        @Override
        public void start() { recalc = 0; }

        @Override
        public void stop() { owner = null; mob.getNavigation().stop(); }

        @Override
        public void tick() {
            mob.getLookControl().setLookAt(owner, 10.0F, (float) mob.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (mob.distanceToSqr(owner) >= 900.0D) {
                    mob.teleportTo(owner.getX() + (mob.random.nextDouble() - 0.5) * 3.0, owner.getY() + (mob.sp.isFlyer() ? 1.0 : 0.0),
                            owner.getZ() + (mob.random.nextDouble() - 0.5) * 3.0);
                    mob.getNavigation().stop();
                } else {
                    mob.getNavigation().moveTo(owner, speed);
                }
            }
        }
    }

    // ------------------------------------------------------------------ hostilidad / domesticación
    @Override
    public boolean canAttack(LivingEntity target) {
        if (isTamed()) {
            if (!defend || isJuvenile()) return false;
            if (target instanceof Player) return false;
            if (isOwner(target)) return false;
            if (target instanceof BestiaryCreature c && c.isTamed()) return false;
            return super.canAttack(target);
        }
        return super.canAttack(target);
    }

    @Override
    public void setTarget(LivingEntity target) {
        if (isTamed() && target != null && !canAttack(target)) target = null;
        super.setTarget(target);
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || (isSitting() && !isVehicle());
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return !isTamed();
    }

    @Override
    public boolean requiresCustomPersistence() {
        return isTamed() || super.requiresCustomPersistence();
    }

    /** Llamado por el Mixin de Cápsulas justo antes de la captura. */
    public void markCapturedBy(ServerPlayer player) {
        if (isTamed()) return; // una criatura ya domesticada conserva a su propietario original
        this.capturedBy = player.getUUID();
        this.capturedTick = level().getGameTime();
        BestiaryData.mark(player, sp.id, "captured");
    }

    private void becomeTamedBy(UUID uuid) {
        this.ownerUuid = uuid;
        setTamed(true);
        setTarget(null);
        setPersistenceRequired();
        this.defend = false;
    }

    // ------------------------------------------------------------------ estadísticas / variantes
    public void initWild(RandomSource r) {
        BestiarioConfig c = Bestiario.CONFIG;
        double roll = r.nextDouble();
        int v = 0;
        double acc = 0;
        double[] ch = {c.chanceAlbino, c.chanceMelanic, c.chanceGolden, c.chanceCrystal, c.chanceCrimson};
        for (int i = 0; i < ch.length; i++) {
            acc += ch[i];
            if (roll < acc) { v = i + 1; break; }
        }
        setVariant(v);
        setCreatureLevel(1 + r.nextInt(8));
        gh = 0.9f + r.nextFloat() * 0.2f;
        gd = 0.9f + r.nextFloat() * 0.2f;
        gs = 0.92f + r.nextFloat() * 0.16f;
        applyStats();
        setHealth(getMaxHealth());
    }

    public void applyStats() {
        double lvl = 1.0 + 0.03 * (getCreatureLevel() - 1);
        double jh = isJuvenile() ? 0.45 : 1.0;
        set(Attributes.MAX_HEALTH, sp.hp * gh * lvl * jh);
        set(Attributes.ATTACK_DAMAGE, sp.dmg * gd * lvl * (isJuvenile() ? 0.4 : 1.0));
        set(Attributes.MOVEMENT_SPEED, sp.spd * gs);
    }

    private void set(net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attr, double v) {
        AttributeInstance inst = getAttribute(attr);
        if (inst != null) inst.setBaseValue(v);
    }

    public void applyChildData(ChildData d) {
        setVariant(d.variant);
        gh = d.gh; gd = d.gd; gs = d.gs;
        setCreatureLevel(1);
        this.ageTicks = -Bestiario.CONFIG.growthTicks;
        this.entityData.set(JUVENILE, true);
        if (!d.owner.isEmpty()) {
            try { becomeTamedBy(UUID.fromString(d.owner)); } catch (IllegalArgumentException ignored) { }
        }
        applyStats();
        setHealth(getMaxHealth());
    }

    // ------------------------------------------------------------------ ataques y habilidades
    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        if (isOwner(target)) return false;
        boolean hit = super.doHurtTarget(level, target);
        if (hit && target instanceof LivingEntity le) applyFx(level, le);
        return hit;
    }

    private void applyFx(ServerLevel level, LivingEntity t) {
        switch (sp.fx) {
            case "slow", "web" -> t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 120, sp.fx.equals("web") ? 2 : 1));
            case "freeze" -> {
                t.setTicksFrozen(220);
                t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 1));
            }
            case "poison" -> t.addEffect(new MobEffectInstance(MobEffects.POISON, 120, 0));
            case "bleed" -> t.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0));
            case "wither" -> t.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
            case "fire" -> t.igniteForSeconds(6.0F);
            case "darkness" -> t.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0));
            case "blind" -> t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
            case "weak" -> t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 140, 0));
            case "levitate" -> t.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 0));
            case "nausea" -> t.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 140, 0));
            case "hunger" -> t.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 1));
            case "shock" -> {
                t.hurtServer(level, level.damageSources().magic(), 3.0F + (float) sp.dmg * 0.2F);
                t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
            }
            case "knock" -> {
                Vec3 d = t.position().subtract(position()).normalize();
                t.push(d.x * 0.9, 0.45, d.z * 0.9);
                t.hurtMarked = true;
            }
            case "stomp" -> {
                List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(3.5),
                        e -> e != this && canAttack(e));
                for (LivingEntity e : near) {
                    e.hurtServer(level, level.damageSources().mobAttack(this), (float) sp.dmg * 0.5F);
                    e.push(0.0, 0.4, 0.0);
                    e.hurtMarked = true;
                }
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ interacción
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isTamed()) return InteractionResult.PASS;
        if (!(level() instanceof ServerLevel sl)) return InteractionResult.SUCCESS;
        if (!isOwner(player)) {
            msg(player, "Esta criatura pertenece a otro jugador.");
            return InteractionResult.SUCCESS;
        }
        if (stack.is(Items.SADDLE) && !isSaddled() && !isJuvenile()) {
            setSaddled(true);
            stack.consume(1, player);
            return InteractionResult.SUCCESS;
        }
        if (stack.is(Items.SHEARS) && isSaddled()) {
            setSaddled(false);
            ejectPassengers();
            spawnAtLocation(sl, new ItemStack(Items.SADDLE));
            return InteractionResult.SUCCESS;
        }
        if (stack.is(Items.STICK)) {
            defend = !defend;
            if (!defend) setTarget(null);
            msg(player, sp.es + (defend ? ": modo DEFENSA activado" : ": modo pasivo"));
            return InteractionResult.SUCCESS;
        }
        if (sp.acceptsFood(stack)) {
            if (isJuvenile()) {
                ageTicks = Math.min(0, ageTicks + Bestiario.CONFIG.growthTicks / 10);
                stack.consume(1, player);
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + getBbHeight(), getZ(), 5, 0.3, 0.3, 0.3, 0.0);
                return InteractionResult.SUCCESS;
            }
            if (breedCd <= 0 && love <= 0 && pregnant <= 0) {
                love = Bestiario.CONFIG.loveTicks;
                stack.consume(1, player);
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight(), getZ(), 7, 0.4, 0.4, 0.4, 0.0);
                return InteractionResult.SUCCESS;
            }
            msg(player, sp.es + " aún no puede reproducirse.");
            return InteractionResult.SUCCESS;
        }
        if (stack.isEmpty()) {
            if (isSaddled() && !isJuvenile() && !player.isShiftKeyDown()) {
                setSitting(false);
                player.startRiding(this);
                return InteractionResult.SUCCESS;
            }
            setSitting(!isSitting());
            getNavigation().stop();
            setTarget(null);
            msg(player, sp.es + (isSitting() ? " se sienta." : " se levanta."));
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }

    // ------------------------------------------------------------------ monturas
    @Override
    public LivingEntity getControllingPassenger() {
        Entity p = getFirstPassenger();
        return (p instanceof Player pl && isOwner(pl) && isSaddled()) ? pl : null;
    }

    @Override
    protected void tickRidden(Player player, Vec3 travelVector) {
        super.tickRidden(player, travelVector);
        this.setRot(player.getYRot(), sp.isFlyer() || sp.isSwimmer() ? player.getXRot() : player.getXRot() * 0.5F);
        this.yRotO = this.yBodyRot = this.yHeadRot = this.getYRot();
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 travelVector) {
        return new Vec3(player.xxa * 0.5F, 0.0, player.zza);
    }

    @Override
    protected float getRiddenSpeed(Player player) {
        return (float) (this.getAttributeValue(Attributes.MOVEMENT_SPEED) * sp.ride);
    }

    @Override
    public void travel(Vec3 input) {
        LivingEntity rider = getControllingPassenger();
        if (rider != null && (sp.isFlyer() || sp.isSwimmer())) {
            rideTravel(input);
            return;
        }
        super.travel(input);
    }

    /** Vuelo y natación controlados: el movimiento sigue la mirada del jugador (W/S = adelante/atrás, A/D = lateral). */
    private void rideTravel(Vec3 in) {
        double yaw = Math.toRadians(getYRot());
        double pitch = Math.toRadians(getXRot());
        Vec3 look = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 left = new Vec3(Math.cos(yaw), 0.0, Math.sin(yaw));
        double fwd = in.z;
        double strafe = in.x;
        boolean active;
        double speed;
        if (sp.isFlyer()) {
            if (!rideFlying && onGround() && fwd > 0.0 && getXRot() < -12.0F) rideFlying = true;   // despegue
            if (rideFlying && onGround() && getXRot() > 8.0F) rideFlying = false;                  // aterrizaje
            active = rideFlying;
            speed = sp.fs * 0.55;
        } else {
            active = isInWater();
            rideFlying = active;
            speed = sp.swim;
        }
        if (active) {
            setNoGravity(true);
            Vec3 target = look.scale(fwd * speed).add(left.scale(strafe * speed * 0.8));
            Vec3 d = getDeltaMovement().scale(0.85).add(target.scale(0.3));
            setDeltaMovement(d);
            move(MoverType.SELF, d);
            resetFallDistance();
        } else {
            setNoGravity(false);
            super.travel(new Vec3(strafe, in.y, fwd));
        }
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (getControllingPassenger() == null && rideFlying) {
            rideFlying = false;
            setNoGravity(false);
        }
        if (sp.isFlyer() || sp.isSwimmer()) resetFallDistance();
        if (!(level() instanceof ServerLevel sl)) return;
        serverTick(sl);
    }

    private void serverTick(ServerLevel sl) {
        BestiarioConfig cfg = Bestiario.CONFIG;
        if (isSitting() && isVehicle()) setSitting(false);
        if (isSitting() && sp.isFlyer() && !isVehicle()) setNoGravity(false);

        if (ageTicks < 0) {
            if (++ageTicks == 0) {
                this.entityData.set(JUVENILE, false);
                applyStats();
                setHealth(getMaxHealth());
            }
        }
        if (love > 0) love--;
        if (breedCd > 0) breedCd--;

        if (tickCount % 20 == 0) {
            if (isTamed() && getHealth() < getMaxHealth() && tickCount % 80 == 0) heal(1.0F);
            if (releasedPending && ownerUuid != null) {
                releasedPending = false;
                Player o = sl.getPlayerByUUID(ownerUuid);
                if (o instanceof ServerPlayer op) {
                    BestiaryData.mark(op, sp.id, "captured");
                    BestiaryData.mark(op, sp.id, "released");
                }
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight(), getZ(), 6, 0.4, 0.4, 0.4, 0.0);
            }
            if (isTamed() && ownerUuid != null && tickCount % cfg.levelUpTicks == 0 && getCreatureLevel() < cfg.maxLevel && !isJuvenile()) {
                setCreatureLevel(getCreatureLevel() + 1);
                applyStats();
            }
        }
        if (tickCount % 40 == 0) discover(sl);
        if (isTamed() && defend && !isJuvenile() && tickCount % 10 == 0) defendTick(sl);
        if (isTamed() && !isJuvenile() && tickCount % 20 == 0) breedTick(sl);

        if (pregnant > 0 && --pregnant == 0 && pendingChild != null) {
            Species cs = Species.BY_ID.get(pendingChild.species);
            if (cs != null) spawnOffspring(sl, cs, getX(), getY(), getZ(), pendingChild);
            Player o = ownerUuid != null ? sl.getPlayerByUUID(ownerUuid) : null;
            if (o instanceof ServerPlayer op && cs != null) BestiaryData.mark(op, cs.id, "bred");
            pendingChild = null;
        }
    }

    private void discover(ServerLevel sl) {
        Player p = sl.getNearestPlayer(this, 28.0);
        if (p instanceof ServerPlayer sp2) {
            BestiaryData.mark(sp2, sp.id, "seen");
            BestiaryData.mark(sp2, sp.id, "variant:" + getVariant());
        }
    }

    private void defendTick(ServerLevel sl) {
        if (ownerUuid == null || getTarget() != null) return;
        Player o = sl.getPlayerByUUID(ownerUuid);
        if (o == null) return;
        LivingEntity t = o.getLastHurtByMob();
        if (t == null || !t.isAlive() || !canAttack(t)) t = o.getLastHurtMob();
        if (t == null || !t.isAlive() || !canAttack(t)) {
            t = null;
            double best = 144.0;
            for (Monster m : sl.getEntitiesOfClass(Monster.class, o.getBoundingBox().inflate(12.0))) {
                double d = m.distanceToSqr(this);
                if (d < best && canAttack(m)) { best = d; t = m; }
            }
        }
        if (t != null && t != this) setTarget(t);
    }

    // ------------------------------------------------------------------ reproducción
    private boolean canMateWith(BestiaryCreature o) {
        if (o.sp == sp) return true;
        return Species.hybridFor(sp, o.sp) != null;
    }

    private void breedTick(ServerLevel sl) {
        if (love <= 0 || breedCd > 0 || pregnant > 0 || isVehicle()) return;
        BestiaryCreature mate = null;
        double best = 400.0;
        for (BestiaryCreature c : sl.getEntitiesOfClass(BestiaryCreature.class, getBoundingBox().inflate(10.0))) {
            if (c == this || !c.isAlive() || !c.isTamed() || c.isJuvenile() || c.love <= 0 || c.breedCd > 0 || c.pregnant > 0) continue;
            if (!canMateWith(c)) continue;
            double d = c.distanceToSqr(this);
            if (d < best) { best = d; mate = c; }
        }
        if (mate == null) return;
        if (best > 12.0) {
            if (!isSitting()) getNavigation().moveTo(mate, 1.1);
            return;
        }
        if (getUUID().compareTo(mate.getUUID()) > 0) return; // solo uno de los dos inicia la cría
        Species child = (mate.sp == sp) ? sp : Species.hybridFor(sp, mate.sp);
        if (child == null) return;
        ChildData d = new ChildData();
        d.species = child.id;
        d.variant = inheritVariant(mate);
        d.gh = mixGene(gh, mate.gh);
        d.gd = mixGene(gd, mate.gd);
        d.gs = mixGene(gs, mate.gs);
        d.owner = ownerUuid != null ? ownerUuid.toString() : "";
        pendingChild = d;
        pregnant = Math.max(20, Bestiario.CONFIG.gestationTicks);
        love = 0; mate.love = 0;
        breedCd = mate.breedCd = Bestiario.CONFIG.breedCooldownTicks;
        sl.sendParticles(ParticleTypes.HEART, getX(), getY() + getBbHeight(), getZ(), 10, 0.5, 0.5, 0.5, 0.0);
    }

    private int inheritVariant(BestiaryCreature o) {
        RandomSource r = random;
        if (r.nextDouble() < Bestiario.CONFIG.mutationChanceOnBreeding) return 1 + r.nextInt(Species.VARIANTS.length - 1);
        if (getVariant() == o.getVariant()) return getVariant();
        return r.nextBoolean() ? getVariant() : o.getVariant();
    }

    private float mixGene(float a, float b) {
        float v = (a + b) / 2.0f * (0.97f + random.nextFloat() * 0.06f);
        return Mth.clamp(v, 0.8f, 1.3f);
    }

    /** Ovíparas: pone un huevo que eclosiona; vivíparas: nace la cría directamente. */
    public static void spawnOffspring(ServerLevel sl, Species cs, double x, double y, double z, ChildData d) {
        if (cs.ovi) {
            BestiaryEgg egg = ModEntities.EGG.create(sl, EntitySpawnReason.NATURAL);
            if (egg == null) return;
            egg.setup(cs, d);
            egg.setPos(x, y, z);
            sl.addFreshEntity(egg);
        } else {
            spawnBaby(sl, cs, x, y, z, d);
        }
    }

    public static void spawnBaby(ServerLevel sl, Species cs, double x, double y, double z, ChildData d) {
        BestiaryCreature c = cs.type.create(sl, EntitySpawnReason.NATURAL);
        if (c == null) return;
        c.setPos(x, y, z);
        c.applyChildData(d);
        sl.addFreshEntity(c);
        sl.sendParticles(ParticleTypes.HEART, x, y + 0.5, z, 6, 0.3, 0.3, 0.3, 0.0);
    }

    // ------------------------------------------------------------------ persistencia
    @Override
    public void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        out.putInt("BL_Variant", getVariant());
        out.putInt("BL_Level", getCreatureLevel());
        out.putInt("BL_Age", ageTicks);
        out.putBoolean("BL_Sit", isSitting());
        out.putBoolean("BL_Saddle", isSaddled());
        out.putBoolean("BL_Tamed", isTamed());
        out.putBoolean("BL_Defend", defend);
        out.putFloat("BL_GH", gh);
        out.putFloat("BL_GD", gd);
        out.putFloat("BL_GS", gs);
        out.putFloat("BL_Health", getHealth());
        out.putInt("BL_Love", love);
        out.putInt("BL_BreedCd", breedCd);
        out.putInt("BL_Preg", pregnant);
        if (ownerUuid != null) out.putString("BL_Owner", ownerUuid.toString());
        // Solo durante la captura con Cápsulas (mob.save en el mismo tick del impacto):
        if (capturedBy != null && level().getGameTime() - capturedTick <= 1) out.putString("BL_CapturedBy", capturedBy.toString());
        if (pendingChild != null) pendingChild.save(out, "BL_P_");
    }

    @Override
    public void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        setVariant(in.getIntOr("BL_Variant", 0));
        setCreatureLevel(Math.max(1, in.getIntOr("BL_Level", 1)));
        ageTicks = in.getIntOr("BL_Age", 0);
        this.entityData.set(JUVENILE, ageTicks < 0);
        setSitting(in.getBooleanOr("BL_Sit", false));
        setSaddled(in.getBooleanOr("BL_Saddle", false));
        setTamed(in.getBooleanOr("BL_Tamed", false));
        defend = in.getBooleanOr("BL_Defend", false);
        gh = in.getFloatOr("BL_GH", 1f);
        gd = in.getFloatOr("BL_GD", 1f);
        gs = in.getFloatOr("BL_GS", 1f);
        love = in.getIntOr("BL_Love", 0);
        breedCd = in.getIntOr("BL_BreedCd", 0);
        pregnant = in.getIntOr("BL_Preg", 0);
        pendingChild = ChildData.load(in, "BL_P_");
        String o = in.getStringOr("BL_Owner", "");
        if (!o.isEmpty()) {
            try { ownerUuid = UUID.fromString(o); } catch (IllegalArgumentException ignored) { }
        }
        String cb = in.getStringOr("BL_CapturedBy", "");
        if (!cb.isEmpty()) {
            try {
                becomeTamedBy(UUID.fromString(cb));
                releasedPending = true; // liberada desde una Cápsula: pacífica y domesticada
            } catch (IllegalArgumentException ignored) { }
        }
        if (isTamed()) setPersistenceRequired();
        applyStats();
        setHealth(Math.min(getMaxHealth(), in.getFloatOr("BL_Health", getHealth())));
    }
}
