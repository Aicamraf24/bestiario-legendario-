package com.bestiario.entity;

import com.bestiario.Bestiario;
import com.bestiario.data.Species;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntities {
    public static EntityType<BestiaryEgg> EGG;

    public static void init() {
        for (Species sp : Species.ALL) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, Bestiario.id(sp.id));
            EntityType.Builder<BestiaryCreature> b = EntityType.Builder.<BestiaryCreature>of(BestiaryCreature::new, MobCategory.CREATURE)
                    .sized(sp.hw, sp.h)
                    .eyeHeight(sp.h * 0.8F)
                    .passengerAttachments(sp.seat)
                    .clientTrackingRange(10)
                    .updateInterval(3);
            if (sp.dims.contains("nether")) b.fireImmune();
            EntityType<BestiaryCreature> t = Registry.register(BuiltInRegistries.ENTITY_TYPE, key, b.build(key));
            sp.type = t;
            Species.BY_TYPE.put(t, sp);
            FabricDefaultAttributeRegistry.register(t, BestiaryCreature.createAttributes(sp));
        }
        ResourceKey<EntityType<?>> ek = ResourceKey.create(Registries.ENTITY_TYPE, Bestiario.id("huevo"));
        EGG = Registry.register(BuiltInRegistries.ENTITY_TYPE, ek,
                EntityType.Builder.<BestiaryEgg>of(BestiaryEgg::new, MobCategory.MISC).sized(0.55F, 0.65F)
                        .clientTrackingRange(6).updateInterval(10).build(ek));
        FabricDefaultAttributeRegistry.register(EGG, BestiaryEgg.createAttributes());
    }
}
