package com.bestiario.entity;

import com.bestiario.Bestiario;
import com.bestiario.data.Species;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Huevo en incubación de las especies ovíparas. Eclosiona tras config.incubationTicks. */
public class BestiaryEgg extends Mob {
    private static final EntityDataAccessor<Integer> SPECIES_INDEX =
            SynchedEntityData.defineId(BestiaryEgg.class, EntityDataSerializers.INT);

    private ChildData child;
    private int hatchIn = 2400;

    public BestiaryEgg(EntityType<? extends BestiaryEgg> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 6.0).add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SPECIES_INDEX, 0);
    }

    public int getSpeciesIndex() {
        return this.entityData.get(SPECIES_INDEX);
    }

    public void setup(Species sp, ChildData data) {
        this.entityData.set(SPECIES_INDEX, Species.ALL.indexOf(sp));
        this.child = data;
        this.hatchIn = Bestiario.CONFIG.incubationTicks;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel sl) || child == null) return;
        if (--hatchIn <= 0) {
            Species cs = Species.BY_ID.get(child.species);
            if (cs != null) {
                BestiaryCreature.spawnBaby(sl, cs, getX(), getY(), getZ(), child);
            }
            discard();
        }
    }

    @Override
    public void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        out.putInt("BL_Species", getSpeciesIndex());
        out.putInt("BL_Hatch", hatchIn);
        if (child != null) child.save(out, "BL_C_");
    }

    @Override
    public void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        this.entityData.set(SPECIES_INDEX, in.getIntOr("BL_Species", 0));
        this.hatchIn = in.getIntOr("BL_Hatch", 2400);
        this.child = ChildData.load(in, "BL_C_");
    }
}
