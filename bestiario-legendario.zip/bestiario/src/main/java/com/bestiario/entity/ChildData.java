package com.bestiario.entity;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/** Datos heredados que lleva una cría en gestación o dentro de un huevo. */
public class ChildData {
    public String species = "";
    public int variant;
    public float gh = 1, gd = 1, gs = 1;
    public String owner = "";

    public void save(ValueOutput out, String prefix) {
        out.putString(prefix + "Species", species);
        out.putInt(prefix + "Variant", variant);
        out.putFloat(prefix + "GH", gh);
        out.putFloat(prefix + "GD", gd);
        out.putFloat(prefix + "GS", gs);
        out.putString(prefix + "Owner", owner);
    }

    public static ChildData load(ValueInput in, String prefix) {
        String sp = in.getStringOr(prefix + "Species", "");
        if (sp.isEmpty()) return null;
        ChildData d = new ChildData();
        d.species = sp;
        d.variant = in.getIntOr(prefix + "Variant", 0);
        d.gh = in.getFloatOr(prefix + "GH", 1f);
        d.gd = in.getFloatOr(prefix + "GD", 1f);
        d.gs = in.getFloatOr(prefix + "GS", 1f);
        d.owner = in.getStringOr(prefix + "Owner", "");
        return d;
    }
}
