package com.bestiario.spawn;

import com.bestiario.Bestiario;
import com.bestiario.config.BestiarioConfig;
import com.bestiario.data.Species;
import com.bestiario.entity.BestiaryCreature;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Aparición natural propia (independiente de las reglas vanilla de mobcap/biomas, para que SIEMPRE haya criaturas).
 * Cada cierto tiempo, por jugador, prueba varias posiciones alrededor y elige una especie válida según
 * dimensión (Overworld/Nether), modo (superficie, cueva, agua, aire), bioma y hora.
 */
public final class SpawnManager {
    private SpawnManager() { }

    public static void tick(MinecraftServer server) {
        BestiarioConfig c = Bestiario.CONFIG;
        if (!c.enableNaturalSpawning) return;
        int tc = server.getTickCount();
        for (ServerLevel level : server.getAllLevels()) {
            boolean overworld = level.dimension() == Level.OVERWORLD;
            boolean nether = level.dimension() == Level.NETHER;
            if (!overworld && !nether) continue;
            for (ServerPlayer p : level.players()) {
                if (p.isSpectator()) continue;
                if ((tc + p.getId()) % Math.max(20, c.spawnIntervalTicks) != 0) continue;
                attempt(level, p, nether, c);
            }
        }
    }

    private static void attempt(ServerLevel level, ServerPlayer p, boolean nether, BestiarioConfig c) {
        AABB area = p.getBoundingBox().inflate(96.0);
        List<BestiaryCreature> near = level.getEntitiesOfClass(BestiaryCreature.class, area, e -> !e.isTamed());
        if (near.size() >= c.maxWildNearPlayer) return;
        for (int i = 0; i < c.spawnAttemptsPerCycle; i++) {
            if (trySpawn(level, p, nether, c, near)) return;
        }
    }

    private static boolean trySpawn(ServerLevel level, ServerPlayer p, boolean nether, BestiarioConfig c, List<BestiaryCreature> near) {
        RandomSource r = level.getRandom();
        double ang = r.nextDouble() * Math.PI * 2.0;
        double dist = c.spawnMinDistance + r.nextDouble() * Math.max(1, c.spawnMaxDistance - c.spawnMinDistance);
        int x = Mth_floor(p.getX() + Math.cos(ang) * dist);
        int z = Mth_floor(p.getZ() + Math.sin(ang) * dist);
        if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) return false;

        String mode;
        if (nether) {
            mode = "cave";
        } else {
            int roll = r.nextInt(100);
            mode = roll < 50 ? "surface" : roll < 72 ? "cave" : roll < 86 ? "water" : "air";
        }
        BlockPos pos = switch (mode) {
            case "surface" -> findSurface(level, x, z);
            case "cave" -> findCave(level, p, x, z, nether, r);
            case "water" -> findWater(level, x, z, r);
            default -> findAir(level, x, z, r);
        };
        if (pos == null) return false;

        String biome = level.getBiome(pos).unwrapKey().map(Object::toString).orElse("");
        boolean night = !nether && level.isDarkOutside();
        List<Species> cands = new ArrayList<>();
        int total = 0;
        for (Species s : Species.ALL) {
            if (!s.spawn || s.weight <= 0) continue;
            if (!s.dims.contains(nether ? "nether" : "overworld")) continue;
            if (!s.modes.contains(mode)) continue;
            if (!biomeMatches(s, biome, nether)) continue;
            if (!nether && !mode.equals("cave")) {
                if (s.time.equals("night") && !night) continue;
                if (s.time.equals("day") && night) continue;
            }
            int same = 0;
            for (BestiaryCreature e : near) if (e.sp == s) same++;
            if (same >= c.maxPerSpeciesNearPlayer) continue;
            cands.add(s);
            total += Math.max(1, (int) Math.round(s.weight * c.weightMultiplier));
        }
        if (cands.isEmpty() || r.nextDouble() > c.spawnChance) return false;
        int pick = r.nextInt(Math.max(1, total));
        Species chosen = cands.get(0);
        for (Species s : cands) {
            pick -= Math.max(1, (int) Math.round(s.weight * c.weightMultiplier));
            if (pick < 0) { chosen = s; break; }
        }
        boolean ok = spawnOne(level, chosen, pos, r);
        if (ok && c.groupSpawning && chosen.grpMax > 1) {
            int n = chosen.grpMin + r.nextInt(chosen.grpMax - chosen.grpMin + 1);
            for (int i = 1; i < n; i++) {
                BlockPos o = pos.offset(r.nextInt(7) - 3, 0, r.nextInt(7) - 3);
                spawnOne(level, chosen, o, r);
            }
        }
        return ok;
    }

    private static int Mth_floor(double d) { return (int) Math.floor(d); }

    private static boolean biomeMatches(Species s, String biome, boolean nether) {
        for (String t : s.biomes) {
            if (t.equals("*") || biome.contains(t)) return true;
        }
        return nether && s.biomes.contains("*");
    }

    private static boolean spawnOne(ServerLevel level, Species s, BlockPos pos, RandomSource r) {
        BestiaryCreature e = s.type.create(level, EntitySpawnReason.NATURAL);
        if (e == null) return false;
        e.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        e.setYRot(r.nextFloat() * 360.0F);
        if (!level.noCollision(e.getBoundingBox())) { e.discard(); return false; }
        e.initWild(r);
        return level.addFreshEntity(e);
    }

    // ------------------------------------------------------------------ búsqueda de posición
    private static BlockPos findSurface(ServerLevel level, int x, int z) {
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        if (!level.getFluidState(pos).isEmpty() || !level.getFluidState(pos.below()).isEmpty()) return null;
        if (!level.getBlockState(pos.below()).blocksMotion()) return null;
        return pos;
    }

    private static BlockPos findCave(ServerLevel level, ServerPlayer p, int x, int z, boolean nether, RandomSource r) {
        int minY = level.dimensionType().minY() + 2;
        int y0 = p.getBlockY() + r.nextInt(16) - 12;
        for (int dy = 0; dy < 28; dy++) {
            int y = y0 - dy;
            if (y < minY) return null;
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.getBlockState(pos).isAir() || !level.getBlockState(pos.above()).isAir()) continue;
            if (!level.getBlockState(pos.below()).blocksMotion()) continue;
            if (!level.getFluidState(pos).isEmpty()) continue;
            if (!nether && level.canSeeSky(pos)) continue;
            return pos;
        }
        return null;
    }

    private static BlockPos findWater(ServerLevel level, int x, int z, RandomSource r) {
        int floor = level.getHeight(Heightmap.Types.OCEAN_FLOOR, x, z);
        int sea = level.getSeaLevel();
        int depth = sea - floor;
        if (depth < 5) return null;
        int y = floor + 2 + r.nextInt(Math.max(1, depth - 3));
        BlockPos pos = new BlockPos(x, y, z);
        if (!level.getFluidState(pos).is(FluidTags.WATER) || !level.getFluidState(pos.above()).is(FluidTags.WATER)) return null;
        return pos;
    }

    private static BlockPos findAir(ServerLevel level, int x, int z, RandomSource r) {
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, ground + 7 + r.nextInt(14), z);
        if (!level.getBlockState(pos).isAir() || !level.canSeeSky(pos)) return null;
        if (!level.getFluidState(pos.below(7)).isEmpty() && !level.getFluidState(pos.below(7)).is(FluidTags.WATER)) return null;
        return pos;
    }
}
