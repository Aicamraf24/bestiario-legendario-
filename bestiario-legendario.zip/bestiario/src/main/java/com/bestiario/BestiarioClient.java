package com.bestiario;

import com.bestiario.client.CreatureRenderer;
import com.bestiario.client.EggRenderer;
import com.bestiario.data.Species;
import com.bestiario.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class BestiarioClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (Species sp : Species.ALL) {
            EntityRendererRegistry.register(sp.type, ctx -> new CreatureRenderer(ctx, sp));
        }
        EntityRendererRegistry.register(ModEntities.EGG, EggRenderer::new);
    }
}
