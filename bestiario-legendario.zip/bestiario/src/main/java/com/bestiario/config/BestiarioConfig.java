package com.bestiario.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Configuración en config/bestiario.json (se crea sola la primera vez). */
public class BestiarioConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // --- aparición natural ---
    public boolean enableNaturalSpawning = true;
    public int spawnIntervalTicks = 100;       // cada cuántos ticks se intenta aparecer algo por jugador
    public int spawnAttemptsPerCycle = 5;      // posiciones probadas por intento
    public double spawnChance = 0.55;          // probabilidad de aparición tras encontrar sitio y especie válidos
    public int maxWildNearPlayer = 6;          // máximo de criaturas salvajes en 96 bloques alrededor de cada jugador
    public int maxPerSpeciesNearPlayer = 2;    // máximo de una misma especie cerca de un jugador
    public int spawnMinDistance = 24;
    public int spawnMaxDistance = 64;
    public boolean groupSpawning = true;
    public double weightMultiplier = 1.0;      // multiplica todos los pesos de aparición

    // --- variantes raras (probabilidad por criatura salvaje) ---
    public double chanceAlbino = 0.02;
    public double chanceMelanic = 0.02;
    public double chanceGolden = 0.015;
    public double chanceCrystal = 0.015;
    public double chanceCrimson = 0.02;
    public double mutationChanceOnBreeding = 0.03;

    // --- reproducción ---
    public int loveTicks = 600;
    public int breedCooldownTicks = 6000;
    public int gestationTicks = 600;
    public int incubationTicks = 2400;
    public int growthTicks = 12000;
    public int levelUpTicks = 12000;
    public int maxLevel = 30;

    public static BestiarioConfig load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("bestiario.json");
        BestiarioConfig c = new BestiarioConfig();
        try {
            if (Files.exists(p)) {
                try (Reader r = Files.newBufferedReader(p)) {
                    BestiarioConfig read = GSON.fromJson(r, BestiarioConfig.class);
                    if (read != null) c = read;
                }
            }
            try (Writer w = Files.newBufferedWriter(p)) {
                GSON.toJson(c, w);
            }
        } catch (Exception ignored) {
        }
        return c;
    }
}
